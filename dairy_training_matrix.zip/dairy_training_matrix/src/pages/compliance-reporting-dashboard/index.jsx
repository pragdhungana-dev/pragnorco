import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import RoleBasedSidebar from '../../components/ui/RoleBasedSidebar';
import DashboardHeader from './components/DashboardHeader';
import ComplianceMetricsGrid from './components/ComplianceMetricsGrid';
import ComplianceChartsSection from './components/ComplianceChartsSection';
import ReportTemplatesSidebar from './components/ReportTemplatesSidebar';
import ComplianceAlertsPanel from './components/ComplianceAlertsPanel';

const ComplianceReportingDashboard = () => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [selectedFacility, setSelectedFacility] = useState('all');
  const [dateRange, setDateRange] = useState('current_month');
  const [isLoading, setIsLoading] = useState(true);
  const [isEditMode, setIsEditMode] = useState(false);

  // Mock data for compliance metrics
  const [complianceMetrics, setComplianceMetrics] = useState({
    overallCompliance: 98.5,
    complianceTrend: 2.3,
    overdueTraining: 12,
    overdueTrend: -15.2,
    upcomingDeadlines: 28,
    upcomingTrend: 8.7,
    completionRate: 94.2,
    completionTrend: 5.1,
    criticalGaps: 3,
    criticalTrend: -25.0,
    auditReadiness: 96.8,
    auditTrend: 1.8
  });

  // Mock chart data with editable values
  const [chartData, setChartData] = useState({
    trends: [
      { month: 'Jan', compliance: 95.2, target: 95 },
      { month: 'Feb', compliance: 96.1, target: 95 },
      { month: 'Mar', compliance: 97.3, target: 95 },
      { month: 'Apr', compliance: 96.8, target: 95 },
      { month: 'May', compliance: 97.9, target: 95 },
      { month: 'Jun', compliance: 98.2, target: 95 },
      { month: 'Jul', compliance: 98.5, target: 95 },
      { month: 'Aug', compliance: 98.5, target: 95 }
    ],
    departments: [
      { department: 'Production', compliance: 99.1, id: 'prod' },
      { department: 'Quality Control', compliance: 98.8, id: 'qc' },
      { department: 'Maintenance', compliance: 97.2, id: 'maint' },
      { department: 'Packaging', compliance: 98.5, id: 'pack' },
      { department: 'Laboratory', compliance: 99.3, id: 'lab' },
      { department: 'Safety', compliance: 98.9, id: 'safety' },
      { department: 'Management', compliance: 96.7, id: 'mgmt' }
    ],
    trainingTypes: [
      { name: 'Safety & Hygiene', value: 35, id: 'safety' },
      { name: 'HACCP', value: 25, id: 'haccp' },
      { name: 'Equipment Operation', value: 20, id: 'equipment' },
      { name: 'Quality Control', value: 12, id: 'quality' },
      { name: 'Emergency Response', value: 8, id: 'emergency' }
    ],
    costs: [
      { month: 'Jan', cost: 15420 },
      { month: 'Feb', cost: 18750 },
      { month: 'Mar', cost: 22100 },
      { month: 'Apr', cost: 19800 },
      { month: 'May', cost: 21300 },
      { month: 'Jun', cost: 17900 },
      { month: 'Jul', cost: 20500 },
      { month: 'Aug', cost: 23200 }
    ]
  });

  // Mock alerts data
  const [complianceAlerts, setComplianceAlerts] = useState([
    {
      id: 'alert_001',
      title: 'HACCP Training Overdue',
      description: 'Critical HACCP certification has expired for production team members',
      severity: 'critical',
      affectedEmployees: 8,
      department: 'Production Team',
      createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      dueDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      progress: 25,
      actions: ['acknowledge', 'assign', 'schedule']
    },
    {
      id: 'alert_002',
      title: 'Safety Training Due Soon',
      description: 'Annual safety training expires within 7 days for maintenance staff',
      severity: 'warning',
      affectedEmployees: 12,
      department: 'Maintenance Team',
      createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
      dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      progress: 60,
      actions: ['schedule']
    },
    {
      id: 'alert_003',
      title: 'New FSANZ Guidelines Available',
      description: 'Updated FSANZ dairy safety guidelines require review and acknowledgment',
      severity: 'info',
      affectedEmployees: 45,
      department: 'All Departments',
      createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000),
      dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
      progress: 15,
      actions: ['acknowledge']
    },
    {
      id: 'alert_004',
      title: 'Equipment Training Gap',
      description: 'New packaging equipment requires operator certification',
      severity: 'warning',
      affectedEmployees: 6,
      department: 'Packaging Team',
      createdAt: new Date(Date.now() - 8 * 60 * 60 * 1000),
      dueDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000),
      progress: 0,
      actions: ['assign', 'schedule']
    },
    {
      id: 'alert_005',
      title: 'Quality Control Audit Prep',
      description: 'Upcoming Dept. of Agriculture audit requires updated quality control documentation',
      severity: 'critical',
      affectedEmployees: 15,
      department: 'Quality Control',
      createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000),
      dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
      progress: 75,
      actions: ['acknowledge', 'assign']
    }
  ]);

  useEffect(() => {
    // Simulate data loading
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  const handleSidebarToggle = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const handleMobileMenuToggle = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const handleFacilityChange = (facility) => {
    setSelectedFacility(facility);
    // Simulate data refresh based on facility
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), 800);
  };

  const handleDateRangeChange = (range) => {
    setDateRange(range);
    // Simulate data refresh based on date range
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), 600);
  };

  const handleRefreshData = async () => {
    // Simulate data refresh
    return new Promise(resolve => {
      setTimeout(() => {
        setComplianceMetrics(prev => ({
          ...prev,
          overallCompliance: prev.overallCompliance + (Math.random() - 0.5) * 2,
          overdueTraining: Math.max(0, prev.overdueTraining + Math.floor((Math.random() - 0.5) * 4))
        }));
        resolve();
      }, 1000);
    });
  };

  const handleExportReport = (format) => {
    console.log(`Exporting report in ${format} format`);
    // Simulate export process
    alert(`Report exported successfully in ${format?.toUpperCase()} format`);
  };

  const handleMetricClick = (metricId) => {
    console.log(`Clicked metric: ${metricId}`);
    // Navigate to detailed view or show drill-down data
  };

  const handleTemplateSelect = (template) => {
    console.log('Selected template:', template);
    // Generate report based on template
    alert(`Generating ${template?.name}...`);
  };

  const handleScheduleReport = (report) => {
    console.log('Schedule report:', report);
    // Open scheduling modal
    alert(`Opening schedule settings for ${report?.name}`);
  };

  const handleAlertAction = (alertId, action) => {
    console.log(`Alert ${alertId} action: ${action}`);
    // Handle alert actions
    switch (action) {
      case 'acknowledge': alert('Alert acknowledged');
        break;
      case 'assign': alert('Opening assignment dialog');
        break;
      case 'schedule': alert('Opening scheduling dialog');
        break;
      default:
        break;
    }
  };

  const handleViewAlertDetails = (alert) => {
    console.log('View alert details:', alert);
    // Navigate to detailed alert view
    alert(`Viewing details for: ${alert?.title}`);
  };

  const handleEditModeToggle = () => {
    setIsEditMode(!isEditMode);
  };

  const handleMetricUpdate = (metricId, value) => {
    setComplianceMetrics(prev => ({
      ...prev,
      [metricId]: value
    }));
  };

  const handleAlertUpdate = (alertId, updatedAlert) => {
    setComplianceAlerts(prev => 
      prev?.map(alert => alert?.id === alertId ? { ...alert, ...updatedAlert } : alert)
    );
  };

  const handleAlertDelete = (alertId) => {
    setComplianceAlerts(prev => prev?.filter(alert => alert?.id !== alertId));
  };

  const handleDepartmentComplianceUpdate = (departmentId, newCompliance) => {
    setChartData(prev => ({
      ...prev,
      departments: prev?.departments?.map(dept => 
        dept?.id === departmentId ? { ...dept, compliance: newCompliance } : dept
      )
    }));
  };

  const handleTrainingTypeUpdate = (typeId, newValue) => {
    setChartData(prev => ({
      ...prev,
      trainingTypes: prev?.trainingTypes?.map(type => 
        type?.id === typeId ? { ...type, value: newValue } : type
      )
    }));
  };

  const handleSaveChanges = () => {
    // Simulate save operation
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setIsEditMode(false);
      alert('Changes saved successfully!');
    }, 1000);
  };

  const handleCancelEdit = () => {
    // Reset to original data (in real app, would restore from backup)
    setIsEditMode(false);
    alert('Changes cancelled');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Helmet>
          <title>Loading... - Dairy Training Matrix</title>
        </Helmet>
        <Header onMenuToggle={handleMobileMenuToggle} isMenuOpen={isMobileMenuOpen} />
        <RoleBasedSidebar 
          isCollapsed={isSidebarCollapsed} 
          onToggleCollapse={handleSidebarToggle}
          userRole="training_coordinator"
        />
        <main className={`pt-16 transition-all duration-200 ${isSidebarCollapsed ? 'lg:ml-16' : 'lg:ml-60'}`}>
          <div className="p-6">
            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
                <p className="text-muted-foreground">Loading compliance data...</p>
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>{isEditMode ? 'Editing' : 'Compliance Reporting Dashboard'} - Dairy Training Matrix</title>
        <meta name="description" content="Monitor training compliance metrics and generate regulatory reports for dairy manufacturing operations" />
      </Helmet>

      <Header onMenuToggle={handleMobileMenuToggle} isMenuOpen={isMobileMenuOpen} />
      
      <RoleBasedSidebar 
        isCollapsed={isSidebarCollapsed} 
        onToggleCollapse={handleSidebarToggle}
        userRole="training_coordinator"
      />

      <main className={`pt-16 transition-all duration-200 ${isSidebarCollapsed ? 'lg:ml-16' : 'lg:ml-60'}`}>
        <div className="p-6">
          {/* Dashboard Header */}
          <DashboardHeader
            selectedFacility={selectedFacility}
            onFacilityChange={handleFacilityChange}
            dateRange={dateRange}
            onDateRangeChange={handleDateRangeChange}
            onExportReport={handleExportReport}
            onRefreshData={handleRefreshData}
            isEditMode={isEditMode}
            onEditModeToggle={handleEditModeToggle}
            onSaveChanges={handleSaveChanges}
            onCancelEdit={handleCancelEdit}
          />

          <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
            {/* Main Content Area */}
            <div className="xl:col-span-3 space-y-6">
              {/* Compliance Metrics Grid */}
              <ComplianceMetricsGrid
                metrics={complianceMetrics}
                onMetricClick={handleMetricClick}
                isEditMode={isEditMode}
                onMetricUpdate={handleMetricUpdate}
              />

              {/* Charts Section */}
              <ComplianceChartsSection 
                chartData={chartData} 
                isEditMode={isEditMode}
                onDepartmentComplianceUpdate={handleDepartmentComplianceUpdate}
                onTrainingTypeUpdate={handleTrainingTypeUpdate}
              />

              {/* Compliance Alerts Panel */}
              <ComplianceAlertsPanel
                alerts={complianceAlerts}
                onAlertAction={handleAlertAction}
                onViewDetails={handleViewAlertDetails}
                isEditMode={isEditMode}
                onAlertUpdate={handleAlertUpdate}
                onAlertDelete={handleAlertDelete}
              />
            </div>

            {/* Sidebar */}
            <div className="xl:col-span-1">
              <ReportTemplatesSidebar
                onTemplateSelect={handleTemplateSelect}
                onScheduleReport={handleScheduleReport}
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ComplianceReportingDashboard;