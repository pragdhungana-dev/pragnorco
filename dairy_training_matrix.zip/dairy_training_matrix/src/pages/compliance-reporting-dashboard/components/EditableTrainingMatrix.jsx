import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const EditableTrainingMatrix = ({ 
  isEditMode, 
  onTrainingRequirementUpdate, 
  onEmployeeStatusUpdate,
  onAddTrainingRequirement,
  onRemoveTrainingRequirement 
}) => {
  const [selectedEmployees, setSelectedEmployees] = useState([]);
  const [bulkAction, setBulkAction] = useState('');

  // Mock training matrix data
  const [trainingMatrix, setTrainingMatrix] = useState([
    {
      id: 'tr_001',
      requirement: 'HACCP Certification',
      department: 'Production',
      frequency: 'Annual',
      mandatory: true,
      employees: [
        { id: 'emp_001', name: 'John Smith', status: 'completed', dueDate: '2024-12-15', progress: 100 },
        { id: 'emp_002', name: 'Sarah Johnson', status: 'overdue', dueDate: '2024-08-20', progress: 75 },
        { id: 'emp_003', name: 'Mike Wilson', status: 'in_progress', dueDate: '2024-09-10', progress: 60 }
      ]
    },
    {
      id: 'tr_002',
      requirement: 'Safety Training',
      department: 'All',
      frequency: 'Quarterly',
      mandatory: true,
      employees: [
        { id: 'emp_001', name: 'John Smith', status: 'completed', dueDate: '2024-11-30', progress: 100 },
        { id: 'emp_004', name: 'Lisa Brown', status: 'scheduled', dueDate: '2024-09-15', progress: 0 },
        { id: 'emp_005', name: 'David Lee', status: 'not_started', dueDate: '2024-10-01', progress: 0 }
      ]
    },
    {
      id: 'tr_003',
      requirement: 'Equipment Operation',
      department: 'Packaging',
      frequency: 'Bi-Annual',
      mandatory: false,
      employees: [
        { id: 'emp_006', name: 'Emma Davis', status: 'completed', dueDate: '2025-01-20', progress: 100 },
        { id: 'emp_007', name: 'Tom Anderson', status: 'in_progress', dueDate: '2024-12-01', progress: 40 }
      ]
    }
  ]);

  const [editingRequirement, setEditingRequirement] = useState(null);
  const [editValues, setEditValues] = useState({});

  const statusOptions = [
    { value: 'not_started', label: 'Not Started', color: 'text-muted-foreground' },
    { value: 'scheduled', label: 'Scheduled', color: 'text-accent' },
    { value: 'in_progress', label: 'In Progress', color: 'text-warning' },
    { value: 'completed', label: 'Completed', color: 'text-success' },
    { value: 'overdue', label: 'Overdue', color: 'text-error' }
  ];

  const frequencyOptions = [
    { value: 'Monthly', label: 'Monthly' },
    { value: 'Quarterly', label: 'Quarterly' },
    { value: 'Bi-Annual', label: 'Bi-Annual' },
    { value: 'Annual', label: 'Annual' },
    { value: 'One-Time', label: 'One-Time' }
  ];

  const departmentOptions = [
    { value: 'All', label: 'All Departments' },
    { value: 'Production', label: 'Production' },
    { value: 'Quality Control', label: 'Quality Control' },
    { value: 'Maintenance', label: 'Maintenance' },
    { value: 'Packaging', label: 'Packaging' },
    { value: 'Laboratory', label: 'Laboratory' },
    { value: 'Safety', label: 'Safety' }
  ];

  const bulkActionOptions = [
    { value: 'mark_completed', label: 'Mark as Completed' },
    { value: 'mark_in_progress', label: 'Mark as In Progress' },
    { value: 'schedule_training', label: 'Schedule Training' },
    { value: 'extend_deadline', label: 'Extend Deadline' },
    { value: 'send_reminder', label: 'Send Reminder' }
  ];

  const startEditingRequirement = (requirement) => {
    setEditingRequirement(requirement?.id);
    setEditValues({
      requirement: requirement?.requirement,
      department: requirement?.department,
      frequency: requirement?.frequency,
      mandatory: requirement?.mandatory
    });
  };

  const saveRequirementEdit = () => {
    setTrainingMatrix(prev => 
      prev?.map(item => 
        item?.id === editingRequirement 
          ? { ...item, ...editValues }
          : item
      )
    );
    setEditingRequirement(null);
    setEditValues({});
    onTrainingRequirementUpdate?.(editingRequirement, editValues);
  };

  const cancelRequirementEdit = () => {
    setEditingRequirement(null);
    setEditValues({});
  };

  const updateEmployeeStatus = (requirementId, employeeId, newStatus, newProgress = null) => {
    setTrainingMatrix(prev =>
      prev?.map(requirement =>
        requirement?.id === requirementId
          ? {
              ...requirement,
              employees: requirement?.employees?.map(emp =>
                emp?.id === employeeId
                  ? { 
                      ...emp, 
                      status: newStatus, 
                      progress: newProgress !== null ? newProgress : emp?.progress 
                    }
                  : emp
              )
            }
          : requirement
      )
    );
    onEmployeeStatusUpdate?.(requirementId, employeeId, newStatus, newProgress);
  };

  const getStatusColor = (status) => {
    const statusOption = statusOptions?.find(opt => opt?.value === status);
    return statusOption?.color || 'text-muted-foreground';
  };

  const getStatusBadge = (status) => {
    const colors = {
      not_started: 'bg-muted text-muted-foreground',
      scheduled: 'bg-accent/10 text-accent border border-accent/20',
      in_progress: 'bg-warning/10 text-warning border border-warning/20',
      completed: 'bg-success/10 text-success border border-success/20',
      overdue: 'bg-error/10 text-error border border-error/20'
    };
    return colors?.[status] || colors?.not_started;
  };

  const handleBulkAction = () => {
    if (!bulkAction || selectedEmployees?.length === 0) return;

    selectedEmployees?.forEach(({ requirementId, employeeId }) => {
      switch (bulkAction) {
        case 'mark_completed':
          updateEmployeeStatus(requirementId, employeeId, 'completed', 100);
          break;
        case 'mark_in_progress': updateEmployeeStatus(requirementId, employeeId,'in_progress', 50);
          break;
        case 'schedule_training': updateEmployeeStatus(requirementId, employeeId,'scheduled', 0);
          break;
        default:
          break;
      }
    });

    setSelectedEmployees([]);
    setBulkAction('');
    alert(`Bulk action "${bulkAction}" applied to ${selectedEmployees?.length} employees`);
  };

  const toggleEmployeeSelection = (requirementId, employeeId) => {
    const selectionKey = `${requirementId}_${employeeId}`;
    setSelectedEmployees(prev => {
      const exists = prev?.some(sel => sel?.requirementId === requirementId && sel?.employeeId === employeeId);
      if (exists) {
        return prev?.filter(sel => !(sel?.requirementId === requirementId && sel?.employeeId === employeeId));
      } else {
        return [...prev, { requirementId, employeeId }];
      }
    });
  };

  const isEmployeeSelected = (requirementId, employeeId) => {
    return selectedEmployees?.some(sel => sel?.requirementId === requirementId && sel?.employeeId === employeeId);
  };

  return (
    <div className="bg-card border border-border rounded-lg">
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-foreground flex items-center space-x-2">
            <Icon name="Grid" size={20} />
            <span>Training Requirements Matrix</span>
            {isEditMode && (
              <span className="px-2 py-1 bg-accent/10 text-accent text-xs rounded-full border border-accent/20">
                Edit Mode
              </span>
            )}
          </h2>

          <div className="flex items-center space-x-2">
            {isEditMode && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onAddTrainingRequirement?.()}
                iconName="Plus"
              >
                Add Requirement
              </Button>
            )}
            <Button
              variant="ghost"
              size="sm"
              iconName="Download"
            >
              Export Matrix
            </Button>
          </div>
        </div>

        {/* Bulk Actions */}
        {isEditMode && selectedEmployees?.length > 0 && (
          <div className="flex items-center space-x-3 p-3 bg-accent/5 border border-accent/20 rounded-lg">
            <Icon name="Users" size={16} className="text-accent" />
            <span className="text-sm font-medium text-foreground">
              {selectedEmployees?.length} employees selected
            </span>
            <Select
              options={bulkActionOptions}
              value={bulkAction}
              onChange={setBulkAction}
              placeholder="Choose action..."
              className="w-48"
            />
            <Button
              size="sm"
              onClick={handleBulkAction}
              disabled={!bulkAction}
            >
              Apply
            </Button>
          </div>
        )}
      </div>
      <div className="overflow-x-auto">
        <div className="space-y-6 p-4">
          {trainingMatrix?.map((requirement) => (
            <div key={requirement?.id} className="border border-border rounded-lg">
              {/* Requirement Header */}
              <div className="p-4 bg-muted/50 border-b border-border">
                {editingRequirement === requirement?.id ? (
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <Input
                      label="Requirement Name"
                      value={editValues?.requirement}
                      onChange={(e) => setEditValues(prev => ({ ...prev, requirement: e?.target?.value }))}
                    />
                    <Select
                      label="Department"
                      options={departmentOptions}
                      value={editValues?.department}
                      onChange={(value) => setEditValues(prev => ({ ...prev, department: value }))}
                    />
                    <Select
                      label="Frequency"
                      options={frequencyOptions}
                      value={editValues?.frequency}
                      onChange={(value) => setEditValues(prev => ({ ...prev, frequency: value }))}
                    />
                    <div className="flex items-center space-x-4">
                      <Checkbox
                        checked={editValues?.mandatory}
                        onChange={(checked) => setEditValues(prev => ({ ...prev, mandatory: checked }))}
                        label="Mandatory"
                      />
                      <div className="flex space-x-2">
                        <Button size="sm" onClick={saveRequirementEdit} iconName="Check">Save</Button>
                        <Button size="sm" variant="outline" onClick={cancelRequirementEdit} iconName="X">Cancel</Button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <h3 className="text-lg font-semibold text-foreground">
                        {requirement?.requirement}
                      </h3>
                      <div className="flex items-center space-x-3 text-sm text-muted-foreground">
                        <span className="flex items-center space-x-1">
                          <Icon name="Building" size={14} />
                          <span>{requirement?.department}</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <Icon name="Clock" size={14} />
                          <span>{requirement?.frequency}</span>
                        </span>
                        {requirement?.mandatory && (
                          <span className="px-2 py-1 bg-error/10 text-error text-xs rounded-full border border-error/20">
                            Mandatory
                          </span>
                        )}
                      </div>
                    </div>
                    
                    {isEditMode && (
                      <div className="flex items-center space-x-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => startEditingRequirement(requirement)}
                          iconName="Edit2"
                        >
                          Edit
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => onRemoveTrainingRequirement?.(requirement?.id)}
                          iconName="Trash2"
                          className="text-error hover:text-error"
                        >
                          Remove
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Employee List */}
              <div className="divide-y divide-border">
                {requirement?.employees?.map((employee) => (
                  <div key={employee?.id} className="p-4 hover:bg-muted/30 transition-colors">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        {isEditMode && (
                          <Checkbox
                            checked={isEmployeeSelected(requirement?.id, employee?.id)}
                            onChange={() => toggleEmployeeSelection(requirement?.id, employee?.id)}
                          />
                        )}
                        <div className="flex items-center space-x-3">
                          <Icon name="User" size={16} className="text-muted-foreground" />
                          <span className="font-medium text-foreground">{employee?.name}</span>
                        </div>
                        
                        {isEditMode ? (
                          <Select
                            options={statusOptions?.map(opt => ({ value: opt?.value, label: opt?.label }))}
                            value={employee?.status}
                            onChange={(newStatus) => {
                              const newProgress = newStatus === 'completed' ? 100 : 
                                                newStatus === 'not_started' ? 0 : employee?.progress;
                              updateEmployeeStatus(requirement?.id, employee?.id, newStatus, newProgress);
                            }}
                            className="w-40"
                          />
                        ) : (
                          <span className={`px-2 py-1 text-xs rounded-full ${getStatusBadge(employee?.status)}`}>
                            {statusOptions?.find(opt => opt?.value === employee?.status)?.label}
                          </span>
                        )}
                        
                        <div className="text-sm text-muted-foreground">
                          Due: {employee?.dueDate}
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-4">
                        {/* Progress Bar */}
                        <div className="flex items-center space-x-2 w-32">
                          <div className="flex-1 bg-muted rounded-full h-2">
                            <div
                              className={`h-2 rounded-full transition-all duration-300 ${
                                employee?.progress >= 100 ? 'bg-success' :
                                employee?.progress >= 75 ? 'bg-accent' :
                                employee?.progress >= 50 ? 'bg-warning' : 'bg-error'
                              }`}
                              style={{ width: `${Math.min(employee?.progress, 100)}%` }}
                            />
                          </div>
                          <span className="text-xs text-muted-foreground w-8">
                            {employee?.progress}%
                          </span>
                        </div>
                        
                        {isEditMode && (
                          <Input
                            type="number"
                            min="0"
                            max="100"
                            value={employee?.progress}
                            onChange={(e) => {
                              const newProgress = parseInt(e?.target?.value) || 0;
                              const newStatus = newProgress >= 100 ? 'completed' :
                                              newProgress > 0 ? 'in_progress' : 'not_started';
                              updateEmployeeStatus(requirement?.id, employee?.id, newStatus, newProgress);
                            }}
                            className="w-16 text-center"
                          />
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default EditableTrainingMatrix;