import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ReportTemplatesSidebar = ({ onTemplateSelect, onScheduleReport }) => {
  const [activeSection, setActiveSection] = useState('templates');

  const reportTemplates = [
    {
      id: 'fsanz_compliance',
      name: 'FSANZ Compliance Report',
      description: 'Comprehensive FSANZ regulatory compliance status',
      icon: 'FileText',
      category: 'Regulatory',
      lastGenerated: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      frequency: 'Monthly'
    },
    {
      id: 'dept_agriculture_audit',
      name: 'Dept. of Agriculture Audit Preparation',
      description: 'Australian Department of Agriculture inspection readiness documentation',
      icon: 'Shield',
      category: 'Regulatory',
      lastGenerated: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
      frequency: 'Quarterly'
    },
    {
      id: 'safe_work_australia',
      name: 'Safe Work Australia Training',
      description: 'Workplace safety training compliance report',
      icon: 'HardHat',
      category: 'Safety',
      lastGenerated: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      frequency: 'Monthly'
    },
    {
      id: 'executive_summary',
      name: 'Executive Summary',
      description: 'High-level compliance overview for leadership',
      icon: 'BarChart3',
      category: 'Executive',
      lastGenerated: new Date(Date.now() - 3 * 60 * 60 * 1000),
      frequency: 'Weekly'
    },
    {
      id: 'department_breakdown',
      name: 'Department Breakdown',
      description: 'Detailed compliance by department and role',
      icon: 'Users',
      category: 'Operational',
      lastGenerated: new Date(Date.now() - 6 * 60 * 60 * 1000),
      frequency: 'Bi-weekly'
    },
    {
      id: 'training_costs',
      name: 'Training Cost Analysis',
      description: 'Financial analysis of training investments',
      icon: 'DollarSign',
      category: 'Financial',
      lastGenerated: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      frequency: 'Monthly'
    }
  ];

  const scheduledReports = [
    {
      id: 'auto_fsanz_monthly',
      templateId: 'fsanz_compliance',
      name: 'FSANZ Monthly Report',
      schedule: 'First Monday of each month',
      nextRun: new Date(2024, 8, 2, 9, 0),
      recipients: ['compliance@dairy.com.au', 'manager@dairy.com.au'],
      status: 'active'
    },
    {
      id: 'auto_executive_weekly',
      templateId: 'executive_summary',
      name: 'Weekly Executive Summary',
      schedule: 'Every Monday at 8:00 AM',
      nextRun: new Date(2024, 7, 26, 8, 0),
      recipients: ['ceo@dairy.com.au', 'operations@dairy.com.au'],
      status: 'active'
    },
    {
      id: 'auto_safe_work_monthly',
      templateId: 'safe_work_australia',
      name: 'Safe Work Australia Report',
      schedule: 'Last Friday of each month',
      nextRun: new Date(2024, 7, 30, 10, 0),
      recipients: ['safety@dairy.com.au'],
      status: 'paused'
    }
  ];

  const quickFilters = [
    { id: 'fsanz_only', label: 'FSANZ Requirements Only', icon: 'Filter', active: false },
    { id: 'dept_agriculture_only', label: 'Dept. of Agriculture Requirements Only', icon: 'Filter', active: false },
    { id: 'safe_work_only', label: 'Safe Work Australia Requirements Only', icon: 'Filter', active: false },
    { id: 'overdue_only', label: 'Overdue Training Only', icon: 'AlertTriangle', active: false },
    { id: 'critical_roles', label: 'Critical Roles Only', icon: 'Users', active: false },
    { id: 'this_month', label: 'This Month Only', icon: 'Calendar', active: true }
  ];

  const formatLastGenerated = (date) => {
    const now = new Date();
    const diffMs = now - date;
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffHours / 24);

    if (diffHours < 1) return 'Just now';
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays === 1) return 'Yesterday';
    return `${diffDays} days ago`;
  };

  const formatNextRun = (date) => {
    return date?.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const sidebarSections = [
    { id: 'templates', label: 'Report Templates', icon: 'FileText' },
    { id: 'scheduled', label: 'Scheduled Reports', icon: 'Clock' },
    { id: 'filters', label: 'Quick Filters', icon: 'Filter' }
  ];

  return (
    <div className="w-80 bg-card border border-border rounded-lg h-fit">
      {/* Sidebar Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center space-x-2 mb-4">
          <Icon name="FileStack" size={20} className="text-primary" />
          <h2 className="text-lg font-semibold text-foreground">Reports</h2>
        </div>
        
        <div className="flex space-x-1">
          {sidebarSections?.map((section) => (
            <Button
              key={section?.id}
              variant={activeSection === section?.id ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveSection(section?.id)}
              iconName={section?.icon}
              iconPosition="left"
              className="flex-1"
            >
              {section?.label}
            </Button>
          ))}
        </div>
      </div>
      {/* Sidebar Content */}
      <div className="p-4 max-h-96 overflow-y-auto">
        {activeSection === 'templates' && (
          <div className="space-y-3">
            {reportTemplates?.map((template) => (
              <div
                key={template?.id}
                className="p-3 border border-border rounded-lg hover:bg-muted cursor-pointer transition-colors"
                onClick={() => onTemplateSelect(template)}
              >
                <div className="flex items-start space-x-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <Icon name={template?.icon} size={16} className="text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-sm font-medium text-foreground truncate">
                      {template?.name}
                    </h3>
                    <p className="text-xs text-muted-foreground mt-1">
                      {template?.description}
                    </p>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-xs bg-muted px-2 py-1 rounded">
                        {template?.category}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {formatLastGenerated(template?.lastGenerated)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeSection === 'scheduled' && (
          <div className="space-y-3">
            {scheduledReports?.map((report) => (
              <div
                key={report?.id}
                className="p-3 border border-border rounded-lg"
              >
                <div className="flex items-start justify-between mb-2">
                  <h3 className="text-sm font-medium text-foreground">
                    {report?.name}
                  </h3>
                  <div className={`px-2 py-1 rounded text-xs ${
                    report?.status === 'active' ?'bg-success/10 text-success' :'bg-warning/10 text-warning'
                  }`}>
                    {report?.status}
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mb-2">
                  {report?.schedule}
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">
                    Next: {formatNextRun(report?.nextRun)}
                  </span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onScheduleReport(report)}
                    iconName="Settings"
                  >
                    Edit
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeSection === 'filters' && (
          <div className="space-y-2">
            {quickFilters?.map((filter) => (
              <div
                key={filter?.id}
                className={`flex items-center space-x-3 p-2 rounded-lg cursor-pointer transition-colors ${
                  filter?.active ? 'bg-primary/10 text-primary' : 'hover:bg-muted'
                }`}
              >
                <Icon name={filter?.icon} size={16} />
                <span className="text-sm">{filter?.label}</span>
              </div>
            ))}
          </div>
        )}
      </div>
      {/* Sidebar Footer */}
      <div className="p-4 border-t border-border">
        <Button
          variant="outline"
          size="sm"
          className="w-full"
          iconName="Plus"
          iconPosition="left"
        >
          Create Custom Report
        </Button>
      </div>
    </div>
  );
};

export default ReportTemplatesSidebar;