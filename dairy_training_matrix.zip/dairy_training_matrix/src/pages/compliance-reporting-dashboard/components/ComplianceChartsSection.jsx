import React, { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import EditableTrainingMatrix from './EditableTrainingMatrix';


const ComplianceChartsSection = ({ 
  chartData, 
  isEditMode, 
  onDepartmentComplianceUpdate, 
  onTrainingTypeUpdate 
}) => {
  const [editingChart, setEditingChart] = useState(null);
  const [editingValues, setEditingValues] = useState({});

  const COLORS = ['#22c55e', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#84cc16'];

  const startEditingDepartment = (departmentId, currentValue) => {
    setEditingChart(`dept_${departmentId}`);
    setEditingValues({ [departmentId]: currentValue });
  };

  const startEditingTrainingType = (typeId, currentValue) => {
    setEditingChart(`type_${typeId}`);
    setEditingValues({ [typeId]: currentValue });
  };

  const saveEdit = (type, id) => {
    const newValue = parseFloat(editingValues?.[id]) || 0;
    if (type === 'department') {
      onDepartmentComplianceUpdate(id, newValue);
    } else if (type === 'trainingType') {
      onTrainingTypeUpdate(id, newValue);
    }
    setEditingChart(null);
    setEditingValues({});
  };

  const cancelEdit = () => {
    setEditingChart(null);
    setEditingValues({});
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload?.length) {
      return (
        <div className="bg-popover border border-border rounded-lg shadow-industrial-strong p-3">
          <p className="text-sm font-medium text-foreground">{`${label}`}</p>
          {payload?.map((entry, index) => (
            <p key={index} className="text-sm" style={{ color: entry?.color }}>
              {`${entry?.dataKey}: ${entry?.value}${entry?.dataKey?.includes('compliance') ? '%' : ''}`}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  const PieTooltip = ({ active, payload }) => {
    if (active && payload && payload?.length) {
      return (
        <div className="bg-popover border border-border rounded-lg shadow-industrial-strong p-3">
          <p className="text-sm font-medium text-foreground">{payload?.[0]?.name}</p>
          <p className="text-sm" style={{ color: payload?.[0]?.color }}>
            {`${payload?.[0]?.value}%`}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      {/* Compliance Trends Chart */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-foreground flex items-center space-x-2">
            <Icon name="TrendingUp" size={20} />
            <span>Compliance Trends</span>
          </h3>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" iconName="Download">
              Export Chart
            </Button>
          </div>
        </div>
        
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData?.trends}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis 
                dataKey="month" 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
                domain={['dataMin - 5', 'dataMax + 5']}
              />
              <Tooltip content={<CustomTooltip />} />
              <Line 
                type="monotone" 
                dataKey="compliance" 
                stroke="hsl(var(--success))" 
                strokeWidth={3}
                dot={{ fill: 'hsl(var(--success))', strokeWidth: 2, r: 5 }}
                activeDot={{ r: 7, stroke: 'hsl(var(--success))', strokeWidth: 2 }}
              />
              <Line 
                type="monotone" 
                dataKey="target" 
                stroke="hsl(var(--muted-foreground))" 
                strokeWidth={2}
                strokeDasharray="5 5"
                dot={{ fill: 'hsl(var(--muted-foreground))', strokeWidth: 2, r: 3 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Department Compliance */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-foreground flex items-center space-x-2">
              <Icon name="Building" size={20} />
              <span>Department Compliance</span>
              {isEditMode && (
                <Icon name="Edit2" size={16} className="text-accent" />
              )}
            </h3>
          </div>
          
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData?.departments} layout="horizontal">
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis 
                  type="number" 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                  domain={[85, 100]}
                />
                <YAxis 
                  type="category"
                  dataKey="department" 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                  width={100}
                />
                <Tooltip content={<CustomTooltip />} />
                <Bar 
                  dataKey="compliance" 
                  fill="hsl(var(--primary))"
                  radius={[0, 4, 4, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Editable Department List */}
          {isEditMode && (
            <div className="mt-4 space-y-2 max-h-32 overflow-y-auto">
              <h4 className="text-sm font-medium text-muted-foreground">Edit Values:</h4>
              {chartData?.departments?.map((dept) => (
                <div key={dept?.id} className="flex items-center justify-between text-sm">
                  <span>{dept?.department}:</span>
                  {editingChart === `dept_${dept?.id}` ? (
                    <div className="flex items-center space-x-2">
                      <Input
                        type="number"
                        min="0"
                        max="100"
                        step="0.1"
                        value={editingValues?.[dept?.id]}
                        onChange={(e) => setEditingValues(prev => ({ ...prev, [dept?.id]: e?.target?.value }))}
                        className="w-16 text-xs"
                      />
                      <Button size="xs" onClick={() => saveEdit('department', dept?.id)} iconName="Check" />
                      <Button size="xs" variant="ghost" onClick={cancelEdit} iconName="X" />
                    </div>
                  ) : (
                    <Button
                      size="xs"
                      variant="ghost"
                      onClick={() => startEditingDepartment(dept?.id, dept?.compliance)}
                    >
                      {dept?.compliance}%
                    </Button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Training Types Distribution */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-foreground flex items-center space-x-2">
              <Icon name="PieChart" size={20} />
              <span>Training Types Distribution</span>
              {isEditMode && (
                <Icon name="Edit2" size={16} className="text-accent" />
              )}
            </h3>
          </div>
          
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData?.trainingTypes}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100)?.toFixed(0)}%`}
                  labelLine={false}
                >
                  {chartData?.trainingTypes?.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS?.[index % COLORS?.length]} />
                  ))}
                </Pie>
                <Tooltip content={<PieTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Editable Training Types List */}
          {isEditMode && (
            <div className="mt-4 space-y-2 max-h-32 overflow-y-auto">
              <h4 className="text-sm font-medium text-muted-foreground">Edit Values:</h4>
              {chartData?.trainingTypes?.map((type) => (
                <div key={type?.id} className="flex items-center justify-between text-sm">
                  <span>{type?.name}:</span>
                  {editingChart === `type_${type?.id}` ? (
                    <div className="flex items-center space-x-2">
                      <Input
                        type="number"
                        min="0"
                        max="100"
                        step="1"
                        value={editingValues?.[type?.id]}
                        onChange={(e) => setEditingValues(prev => ({ ...prev, [type?.id]: e?.target?.value }))}
                        className="w-16 text-xs"
                      />
                      <Button size="xs" onClick={() => saveEdit('trainingType', type?.id)} iconName="Check" />
                      <Button size="xs" variant="ghost" onClick={cancelEdit} iconName="X" />
                    </div>
                  ) : (
                    <Button
                      size="xs"
                      variant="ghost"
                      onClick={() => startEditingTrainingType(type?.id, type?.value)}
                    >
                      {type?.value}%
                    </Button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      {/* Training Costs Chart */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-foreground flex items-center space-x-2">
            <Icon name="DollarSign" size={20} />
            <span>Training Costs Trends</span>
          </h3>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" iconName="Download">
              Export Chart
            </Button>
          </div>
        </div>
        
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData?.costs}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis 
                dataKey="month" 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
                tickFormatter={(value) => `$${(value / 1000)?.toFixed(0)}k`}
              />
              <Tooltip 
                formatter={(value) => [`$${value?.toLocaleString()}`, 'Training Cost']}
                labelStyle={{ color: 'hsl(var(--foreground))' }}
                contentStyle={{
                  backgroundColor: 'hsl(var(--popover))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px'
                }}
              />
              <Bar 
                dataKey="cost" 
                fill="hsl(var(--accent))"
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
      {/* Training Matrix Section */}
      {isEditMode && (
        <div className="mt-6">
          <EditableTrainingMatrix 
            isEditMode={isEditMode}
            onTrainingRequirementUpdate={(id, values) => console.log('Update requirement:', id, values)}
            onEmployeeStatusUpdate={(reqId, empId, status, progress) => console.log('Update status:', reqId, empId, status, progress)}
            onAddTrainingRequirement={() => console.log('Add new requirement')}
            onRemoveTrainingRequirement={(id) => console.log('Remove requirement:', id)}
          />
        </div>
      )}
    </div>
  );
};

export default ComplianceChartsSection;