import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';

const ComplianceMetricsGrid = ({ metrics, onMetricClick, isEditMode, onMetricUpdate }) => {
  const [editingMetric, setEditingMetric] = useState(null);
  const [editValues, setEditValues] = useState({});

  const metricCards = [
    {
      id: 'overallCompliance',
      title: 'Overall Compliance',
      value: metrics?.overallCompliance,
      unit: '%',
      trend: metrics?.complianceTrend,
      icon: 'Shield',
      color: metrics?.overallCompliance >= 95 ? 'success' : metrics?.overallCompliance >= 85 ? 'warning' : 'error',
      description: 'Total training compliance across all facilities',
      editable: true
    },
    {
      id: 'overdueTraining',
      title: 'Overdue Training',
      value: metrics?.overdueTraining,
      unit: '',
      trend: metrics?.overdueTrend,
      icon: 'AlertTriangle',
      color: metrics?.overdueTraining === 0 ? 'success' : metrics?.overdueTraining <= 10 ? 'warning' : 'error',
      description: 'Employees with expired training requirements',
      editable: true
    },
    {
      id: 'upcomingDeadlines',
      title: 'Upcoming Deadlines',
      value: metrics?.upcomingDeadlines,
      unit: '',
      trend: metrics?.upcomingTrend,
      icon: 'Clock',
      color: 'accent',
      description: 'Training requirements due within 30 days',
      editable: true
    },
    {
      id: 'completionRate',
      title: 'Monthly Completion Rate',
      value: metrics?.completionRate,
      unit: '%',
      trend: metrics?.completionTrend,
      icon: 'TrendingUp',
      color: metrics?.completionRate >= 90 ? 'success' : metrics?.completionRate >= 75 ? 'warning' : 'error',
      description: 'Training completion rate for current month',
      editable: true
    },
    {
      id: 'criticalGaps',
      title: 'Critical Gaps',
      value: metrics?.criticalGaps,
      unit: '',
      trend: metrics?.criticalTrend,
      icon: 'AlertCircle',
      color: metrics?.criticalGaps === 0 ? 'success' : 'error',
      description: 'High-priority training gaps requiring immediate attention',
      editable: true
    },
    {
      id: 'auditReadiness',
      title: 'Audit Readiness',
      value: metrics?.auditReadiness,
      unit: '%',
      trend: metrics?.auditTrend,
      icon: 'FileCheck',
      color: metrics?.auditReadiness >= 98 ? 'success' : metrics?.auditReadiness >= 90 ? 'warning' : 'error',
      description: 'Percentage of documentation ready for regulatory audit',
      editable: true
    }
  ];

  const startEditing = (metric) => {
    setEditingMetric(metric?.id);
    setEditValues({
      value: metric?.value,
      trend: Math.abs(metric?.trend)
    });
  };

  const saveEdit = (metricId) => {
    if (editValues?.value !== undefined) {
      onMetricUpdate(metricId, parseFloat(editValues?.value) || 0);
    }
    setEditingMetric(null);
    setEditValues({});
  };

  const cancelEdit = () => {
    setEditingMetric(null);
    setEditValues({});
  };

  const handleKeyPress = (e, metricId) => {
    if (e?.key === 'Enter') {
      saveEdit(metricId);
    } else if (e?.key === 'Escape') {
      cancelEdit();
    }
  };

  const getColorClasses = (color) => {
    const colorMap = {
      success: 'bg-success text-success-foreground',
      warning: 'bg-warning text-warning-foreground',
      error: 'bg-error text-error-foreground',
      accent: 'bg-accent text-accent-foreground'
    };
    return colorMap?.[color] || 'bg-muted text-muted-foreground';
  };

  const getTrendIcon = (trend) => {
    if (trend > 0) return 'TrendingUp';
    if (trend < 0) return 'TrendingDown';
    return 'Minus';
  };

  const getTrendColor = (trend, isPositiveGood = true) => {
    if (trend === 0) return 'text-muted-foreground';
    const isGood = isPositiveGood ? trend > 0 : trend < 0;
    return isGood ? 'text-success' : 'text-error';
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {metricCards?.map((metric) => (
        <div
          key={metric?.id}
          className={`bg-card border border-border rounded-lg p-6 transition-all duration-200 ${
            isEditMode && metric?.editable 
              ? 'hover:shadow-industrial-strong hover:border-accent cursor-pointer' 
              : 'hover:shadow-industrial-strong cursor-pointer'
          } ${editingMetric === metric?.id ? 'border-accent shadow-industrial-strong' : ''}`}
          onClick={() => {
            if (isEditMode && metric?.editable && editingMetric !== metric?.id) {
              startEditing(metric);
            } else if (!isEditMode) {
              onMetricClick(metric?.id);
            }
          }}
        >
          <div className="flex items-start justify-between mb-4">
            <div className={`p-3 rounded-lg ${getColorClasses(metric?.color)} relative`}>
              <Icon name={metric?.icon} size={24} />
              {isEditMode && metric?.editable && (
                <Icon 
                  name="Edit2" 
                  size={12} 
                  className="absolute -top-1 -right-1 bg-background rounded-full border border-border p-0.5" 
                />
              )}
            </div>
            <div className="flex items-center space-x-1">
              <Icon 
                name={getTrendIcon(metric?.trend)} 
                size={16} 
                className={getTrendColor(metric?.trend, metric?.id !== 'overdueTraining' && metric?.id !== 'criticalGaps')}
              />
              <span className={`text-sm font-medium ${getTrendColor(metric?.trend, metric?.id !== 'overdueTraining' && metric?.id !== 'criticalGaps')}`}>
                {Math.abs(metric?.trend)}%
              </span>
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="text-sm font-medium text-muted-foreground">
              {metric?.title}
            </h3>
            
            {editingMetric === metric?.id ? (
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Input
                    type="number"
                    value={editValues?.value}
                    onChange={(e) => setEditValues(prev => ({ ...prev, value: e?.target?.value }))}
                    onKeyDown={(e) => handleKeyPress(e, metric?.id)}
                    className="text-2xl font-bold"
                    autoFocus
                  />
                  {metric?.unit && (
                    <span className="text-lg text-muted-foreground">
                      {metric?.unit}
                    </span>
                  )}
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    size="sm"
                    variant="default"
                    onClick={() => saveEdit(metric?.id)}
                    iconName="Check"
                  >
                    Save
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={cancelEdit}
                    iconName="X"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            ) : (
              <div className="flex items-baseline space-x-1">
                <span className="text-3xl font-bold text-foreground">
                  {metric?.value?.toLocaleString()}
                </span>
                {metric?.unit && (
                  <span className="text-lg text-muted-foreground">
                    {metric?.unit}
                  </span>
                )}
              </div>
            )}
            
            <p className="text-xs text-muted-foreground">
              {metric?.description}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ComplianceMetricsGrid;