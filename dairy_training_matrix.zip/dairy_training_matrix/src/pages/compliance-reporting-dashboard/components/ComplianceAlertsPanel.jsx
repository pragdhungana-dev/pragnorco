import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const ComplianceAlertsPanel = ({ 
  alerts, 
  onAlertAction, 
  onViewDetails, 
  isEditMode, 
  onAlertUpdate, 
  onAlertDelete 
}) => {
  const [filter, setFilter] = useState('all');
  const [editingAlert, setEditingAlert] = useState(null);
  const [editValues, setEditValues] = useState({});

  const alertTypes = [
    { id: 'all', label: 'All Alerts', count: alerts?.length },
    { id: 'critical', label: 'Critical', count: alerts?.filter(a => a?.severity === 'critical')?.length },
    { id: 'warning', label: 'Warning', count: alerts?.filter(a => a?.severity === 'warning')?.length },
    { id: 'info', label: 'Info', count: alerts?.filter(a => a?.severity === 'info')?.length }
  ];

  const severityOptions = [
    { value: 'critical', label: 'Critical' },
    { value: 'warning', label: 'Warning' },
    { value: 'info', label: 'Info' }
  ];

  const departmentOptions = [
    { value: 'Production Team', label: 'Production Team' },
    { value: 'Quality Control', label: 'Quality Control' },
    { value: 'Maintenance Team', label: 'Maintenance Team' },
    { value: 'Packaging Team', label: 'Packaging Team' },
    { value: 'Laboratory', label: 'Laboratory' },
    { value: 'Safety Team', label: 'Safety Team' },
    { value: 'All Departments', label: 'All Departments' }
  ];

  const filteredAlerts = filter === 'all' 
    ? alerts 
    : alerts?.filter(alert => alert?.severity === filter);

  const startEditing = (alert) => {
    setEditingAlert(alert?.id);
    setEditValues({
      title: alert?.title,
      description: alert?.description,
      severity: alert?.severity,
      affectedEmployees: alert?.affectedEmployees,
      department: alert?.department,
      progress: alert?.progress
    });
  };

  const saveEdit = (alertId) => {
    onAlertUpdate(alertId, editValues);
    setEditingAlert(null);
    setEditValues({});
  };

  const cancelEdit = () => {
    setEditingAlert(null);
    setEditValues({});
  };

  const handleDelete = (alertId) => {
    if (window.confirm('Are you sure you want to delete this alert?')) {
      onAlertDelete(alertId);
    }
  };

  const getSeverityIcon = (severity) => {
    switch (severity) {
      case 'critical': return 'AlertTriangle';
      case 'warning': return 'AlertCircle';
      case 'info': return 'Info';
      default: return 'Bell';
    }
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'critical': return 'text-error';
      case 'warning': return 'text-warning';
      case 'info': return 'text-accent';
      default: return 'text-muted-foreground';
    }
  };

  const getSeverityBg = (severity) => {
    switch (severity) {
      case 'critical': return 'bg-error/10 border-error/20';
      case 'warning': return 'bg-warning/10 border-warning/20';
      case 'info': return 'bg-accent/10 border-accent/20';
      default: return 'bg-muted/10 border-border';
    }
  };

  const formatTimeAgo = (date) => {
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${diffDays}d ago`;
  };

  const getActionButtons = (alert) => {
    const actions = [];
    
    if (alert?.actions?.includes('acknowledge')) {
      actions?.push(
        <Button
          key="acknowledge"
          variant="ghost"
          size="sm"
          onClick={() => onAlertAction(alert?.id, 'acknowledge')}
          iconName="Check"
        >
          Acknowledge
        </Button>
      );
    }
    
    if (alert?.actions?.includes('assign')) {
      actions?.push(
        <Button
          key="assign"
          variant="ghost"
          size="sm"
          onClick={() => onAlertAction(alert?.id, 'assign')}
          iconName="UserPlus"
        >
          Assign
        </Button>
      );
    }
    
    if (alert?.actions?.includes('schedule')) {
      actions?.push(
        <Button
          key="schedule"
          variant="ghost"
          size="sm"
          onClick={() => onAlertAction(alert?.id, 'schedule')}
          iconName="Calendar"
        >
          Schedule
        </Button>
      );
    }

    return actions;
  };

  return (
    <div className="bg-card border border-border rounded-lg">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-foreground flex items-center space-x-2">
            <Icon name="Bell" size={20} />
            <span>Compliance Alerts</span>
            {isEditMode && (
              <Icon name="Edit2" size={16} className="text-accent" />
            )}
          </h2>
          <div className="flex items-center space-x-2">
            {isEditMode && (
              <Button
                variant="outline"
                size="sm"
                iconName="Plus"
              >
                Add Alert
              </Button>
            )}
            <Button
              variant="ghost"
              size="sm"
              iconName="Settings"
            >
              Configure
            </Button>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex space-x-1">
          {alertTypes?.map((type) => (
            <Button
              key={type?.id}
              variant={filter === type?.id ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setFilter(type?.id)}
              className="relative"
            >
              {type?.label}
              {type?.count > 0 && (
                <span className="ml-2 px-2 py-0.5 bg-muted rounded-full text-xs">
                  {type?.count}
                </span>
              )}
            </Button>
          ))}
        </div>
      </div>
      {/* Alerts List */}
      <div className="max-h-96 overflow-y-auto">
        {filteredAlerts?.length === 0 ? (
          <div className="p-8 text-center">
            <Icon name="CheckCircle" size={48} className="text-success mx-auto mb-4" />
            <h3 className="text-lg font-medium text-foreground mb-2">
              No {filter !== 'all' ? filter : ''} alerts
            </h3>
            <p className="text-muted-foreground">
              All compliance requirements are up to date.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-border">
            {filteredAlerts?.map((alert) => (
              <div
                key={alert?.id}
                className={`p-4 border-l-4 ${getSeverityBg(alert?.severity)} ${
                  isEditMode ? 'hover:bg-muted/50' : ''
                }`}
              >
                {editingAlert === alert?.id ? (
                  /* Edit Mode UI */
                  (<div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Input
                        label="Alert Title"
                        value={editValues?.title}
                        onChange={(e) => setEditValues(prev => ({ ...prev, title: e?.target?.value }))}
                      />
                      <Select
                        label="Severity"
                        options={severityOptions}
                        value={editValues?.severity}
                        onChange={(value) => setEditValues(prev => ({ ...prev, severity: value }))}
                      />
                    </div>
                    <Input
                      label="Description"
                      value={editValues?.description}
                      onChange={(e) => setEditValues(prev => ({ ...prev, description: e?.target?.value }))}
                      multiline
                    />
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <Input
                        label="Affected Employees"
                        type="number"
                        value={editValues?.affectedEmployees}
                        onChange={(e) => setEditValues(prev => ({ ...prev, affectedEmployees: parseInt(e?.target?.value) || 0 }))}
                      />
                      <Select
                        label="Department"
                        options={departmentOptions}
                        value={editValues?.department}
                        onChange={(value) => setEditValues(prev => ({ ...prev, department: value }))}
                      />
                      <Input
                        label="Progress (%)"
                        type="number"
                        min="0"
                        max="100"
                        value={editValues?.progress}
                        onChange={(e) => setEditValues(prev => ({ ...prev, progress: parseInt(e?.target?.value) || 0 }))}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Button
                          size="sm"
                          variant="default"
                          onClick={() => saveEdit(alert?.id)}
                          iconName="Check"
                        >
                          Save Changes
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={cancelEdit}
                          iconName="X"
                        >
                          Cancel
                        </Button>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDelete(alert?.id)}
                        iconName="Trash2"
                        className="text-error hover:text-error"
                      >
                        Delete
                      </Button>
                    </div>
                  </div>)
                ) : (
                  /* Display Mode UI */
                  (<div className="flex items-start space-x-3">
                    <Icon 
                      name={getSeverityIcon(alert?.severity)} 
                      size={20} 
                      className={`mt-0.5 ${getSeverityColor(alert?.severity)}`}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="text-sm font-medium text-foreground">
                            {alert?.title}
                          </h3>
                          <p className="text-sm text-muted-foreground mt-1">
                            {alert?.description}
                          </p>
                          
                          {/* Alert Details */}
                          <div className="flex items-center space-x-4 mt-2 text-xs text-muted-foreground">
                            <span className="flex items-center space-x-1">
                              <Icon name="User" size={12} />
                              <span>{alert?.affectedEmployees} employees</span>
                            </span>
                            <span className="flex items-center space-x-1">
                              <Icon name="Building" size={12} />
                              <span>{alert?.department}</span>
                            </span>
                            <span className="flex items-center space-x-1">
                              <Icon name="Clock" size={12} />
                              <span>{formatTimeAgo(alert?.createdAt)}</span>
                            </span>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          {isEditMode && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => startEditing(alert)}
                              iconName="Edit2"
                            >
                              Edit
                            </Button>
                          )}
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onViewDetails(alert)}
                            iconName="ExternalLink"
                          >
                            Details
                          </Button>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      {!isEditMode && alert?.actions?.length > 0 && (
                        <div className="flex items-center space-x-2 mt-3">
                          {getActionButtons(alert)}
                        </div>
                      )}

                      {/* Progress Bar for Overdue Items */}
                      {alert?.dueDate && (
                        <div className="mt-3">
                          <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
                            <span>Due: {alert?.dueDate?.toLocaleDateString()}</span>
                            <span>{alert?.progress}% complete</span>
                          </div>
                          <div className="w-full bg-muted rounded-full h-2">
                            <div 
                              className={`h-2 rounded-full transition-all duration-300 ${
                                alert?.progress >= 100 ? 'bg-success' :
                                alert?.progress >= 75 ? 'bg-accent' :
                                alert?.progress >= 50 ? 'bg-warning' : 'bg-error'
                              }`}
                              style={{ width: `${Math.min(alert?.progress, 100)}%` }}
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  </div>)
                )}
              </div>
            ))}
          </div>
        )}
      </div>
      {/* Footer */}
      {filteredAlerts?.length > 0 && (
        <div className="p-4 border-t border-border">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">
              Showing {filteredAlerts?.length} of {alerts?.length} alerts
            </span>
            <Button
              variant="outline"
              size="sm"
              iconName="Archive"
            >
              Archive All
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ComplianceAlertsPanel;