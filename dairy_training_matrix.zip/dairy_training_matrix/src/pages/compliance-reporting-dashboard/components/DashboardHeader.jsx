import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import Input from '../../../components/ui/Input';

const DashboardHeader = ({ 
  selectedFacility, 
  onFacilityChange, 
  dateRange, 
  onDateRangeChange,
  onExportReport,
  onRefreshData,
  isEditMode,
  onEditModeToggle,
  onSaveChanges,
  onCancelEdit
}) => {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [editableTitle, setEditableTitle] = useState('Compliance Reporting Dashboard');
  const [editableDescription, setEditableDescription] = useState('Monitor training compliance metrics and generate regulatory reports');

  const facilityOptions = [
    { value: 'all', label: 'All Facilities' },
    { value: 'facility_1', label: 'Main Processing Plant' },
    { value: 'facility_2', label: 'Packaging Facility' },
    { value: 'facility_3', label: 'Quality Control Lab' },
    { value: 'facility_4', label: 'Distribution Center' }
  ];

  const dateRangeOptions = [
    { value: 'last_7_days', label: 'Last 7 Days' },
    { value: 'last_30_days', label: 'Last 30 Days' },
    { value: 'last_90_days', label: 'Last 90 Days' },
    { value: 'current_month', label: 'Current Month' },
    { value: 'current_quarter', label: 'Current Quarter' },
    { value: 'current_year', label: 'Current Year' },
    { value: 'custom', label: 'Custom Range' }
  ];

  const exportOptions = [
    { value: 'pdf', label: 'Export as PDF', icon: 'FileText' },
    { value: 'excel', label: 'Export as Excel', icon: 'FileSpreadsheet' },
    { value: 'csv', label: 'Export as CSV', icon: 'Download' }
  ];

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await onRefreshData();
    setTimeout(() => setIsRefreshing(false), 1000);
  };

  const handleExport = (format) => {
    onExportReport(format);
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 mb-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
        {/* Left Section - Title and Breadcrumb */}
        <div className="space-y-2 flex-1">
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <Icon name="Home" size={16} />
            <span>Dashboard</span>
            <Icon name="ChevronRight" size={14} />
            <span className="text-foreground font-medium">Compliance Reporting</span>
          </div>
          
          {isEditMode ? (
            <div className="space-y-3">
              <Input
                value={editableTitle}
                onChange={(e) => setEditableTitle(e?.target?.value)}
                className="text-2xl font-bold bg-transparent border-dashed"
                placeholder="Dashboard title..."
              />
              <Input
                value={editableDescription}
                onChange={(e) => setEditableDescription(e?.target?.value)}
                className="text-base bg-transparent border-dashed"
                placeholder="Dashboard description..."
              />
            </div>
          ) : (
            <>
              <h1 className="text-2xl font-bold text-foreground">
                {editableTitle}
              </h1>
              <p className="text-muted-foreground">
                {editableDescription}
              </p>
            </>
          )}
        </div>

        {/* Right Section - Controls */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center space-y-3 sm:space-y-0 sm:space-x-3">
          {!isEditMode ? (
            <>
              {/* Facility Selector */}
              <Select
                options={facilityOptions}
                value={selectedFacility}
                onChange={onFacilityChange}
                placeholder="Select facility"
                className="w-full sm:w-48"
              />

              {/* Date Range Selector */}
              <Select
                options={dateRangeOptions}
                value={dateRange}
                onChange={onDateRangeChange}
                placeholder="Select date range"
                className="w-full sm:w-48"
              />

              {/* Action Buttons */}
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleRefresh}
                  loading={isRefreshing}
                  iconName="RefreshCw"
                  iconPosition="left"
                >
                  Refresh
                </Button>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={onEditModeToggle}
                  iconName="Edit"
                  iconPosition="left"
                >
                  Edit Mode
                </Button>

                {/* Export Dropdown */}
                <div className="relative group">
                  <Button
                    variant="default"
                    size="sm"
                    iconName="Download"
                    iconPosition="left"
                  >
                    Export
                  </Button>
                  
                  {/* Export Menu */}
                  <div className="absolute right-0 top-full mt-1 w-48 bg-popover border border-border rounded-lg shadow-industrial-strong opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
                    <div className="py-2">
                      {exportOptions?.map((option) => (
                        <button
                          key={option?.value}
                          onClick={() => handleExport(option?.value)}
                          className="w-full flex items-center px-4 py-2 text-sm text-foreground hover:bg-muted transition-colors"
                        >
                          <Icon name={option?.icon} size={16} className="mr-3" />
                          {option?.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </>
          ) : (
            /* Edit Mode Controls */
            (<div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={onCancelEdit}
                iconName="X"
                iconPosition="left"
              >
                Cancel
              </Button>
              <Button
                variant="default"
                size="sm"
                onClick={onSaveChanges}
                iconName="Check"
                iconPosition="left"
              >
                Save Changes
              </Button>
            </div>)
          )}
        </div>
      </div>
      {/* Quick Stats Bar */}
      <div className="mt-6 pt-4 border-t border-border">
        {isEditMode && (
          <div className="mb-4 p-3 bg-accent/10 border border-accent/20 rounded-lg">
            <div className="flex items-center space-x-2 text-accent">
              <Icon name="Edit" size={16} />
              <span className="text-sm font-medium">Edit Mode Active</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Click on metrics, charts, or alerts to edit them directly
            </p>
          </div>
        )}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-success">98.5%</div>
            <div className="text-xs text-muted-foreground">Overall Compliance</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-warning">12</div>
            <div className="text-xs text-muted-foreground">Overdue Items</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-accent">28</div>
            <div className="text-xs text-muted-foreground">Due This Week</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-foreground">245</div>
            <div className="text-xs text-muted-foreground">Total Employees</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardHeader;