import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Checkbox } from '../../../components/ui/Checkbox';

const PermissionMatrix = ({ 
  selectedUser, 
  onPermissionChange,
  className = '' 
}) => {
  const [activeTab, setActiveTab] = useState('permissions');

  const systemModules = [
    {
      id: 'training_management',
      name: 'Training Management',
      icon: 'GraduationCap',
      permissions: [
        { id: 'view_training', name: 'View Training Records', description: 'Access to view training data' },
        { id: 'manage_training', name: 'Manage Training', description: 'Create and edit training records' },
        { id: 'approve_training', name: 'Approve Training', description: 'Approve training completions' },
        { id: 'delete_training', name: 'Delete Training', description: 'Remove training records' }
      ]
    },
    {
      id: 'user_management',
      name: 'User Management',
      icon: 'Users',
      permissions: [
        { id: 'view_users', name: 'View Users', description: 'Access to view user profiles' },
        { id: 'manage_users', name: 'Manage Users', description: 'Create and edit user accounts' },
        { id: 'assign_roles', name: 'Assign Roles', description: 'Assign roles to users' },
        { id: 'deactivate_users', name: 'Deactivate Users', description: 'Deactivate user accounts' }
      ]
    },
    {
      id: 'compliance_reporting',
      name: 'Compliance & Reporting',
      icon: 'FileText',
      permissions: [
        { id: 'view_reports', name: 'View Reports', description: 'Access to compliance reports' },
        { id: 'generate_reports', name: 'Generate Reports', description: 'Create custom reports' },
        { id: 'export_data', name: 'Export Data', description: 'Export system data' },
        { id: 'audit_logs', name: 'Audit Logs', description: 'Access system audit logs' }
      ]
    },
    {
      id: 'system_administration',
      name: 'System Administration',
      icon: 'Settings',
      permissions: [
        { id: 'system_config', name: 'System Configuration', description: 'Modify system settings' },
        { id: 'backup_restore', name: 'Backup & Restore', description: 'Manage system backups' },
        { id: 'integration_management', name: 'Integration Management', description: 'Manage external integrations' },
        { id: 'system_monitoring', name: 'System Monitoring', description: 'Monitor system performance' }
      ]
    },
    {
      id: 'quality_safety',
      name: 'Quality & Safety',
      icon: 'Shield',
      permissions: [
        { id: 'view_safety', name: 'View Safety Records', description: 'Access safety training data' },
        { id: 'manage_safety', name: 'Manage Safety', description: 'Manage safety protocols' },
        { id: 'audit_compliance', name: 'Audit Compliance', description: 'Conduct compliance audits' },
        { id: 'incident_reporting', name: 'Incident Reporting', description: 'Report safety incidents' }
      ]
    }
  ];

  const roleTemplates = [
    {
      id: 'production_supervisor',
      name: 'Production Supervisor',
      description: 'Standard permissions for production supervisors',
      permissions: ['view_training', 'manage_training', 'approve_training', 'view_users', 'view_reports', 'view_safety']
    },
    {
      id: 'training_coordinator',
      name: 'Training Coordinator',
      description: 'Full training management permissions',
      permissions: ['view_training', 'manage_training', 'approve_training', 'delete_training', 'view_users', 'manage_users', 'view_reports', 'generate_reports']
    },
    {
      id: 'safety_officer',
      name: 'Safety Officer',
      description: 'Safety and compliance focused permissions',
      permissions: ['view_training', 'approve_training', 'view_users', 'view_reports', 'view_safety', 'manage_safety', 'audit_compliance', 'incident_reporting']
    },
    {
      id: 'system_admin',
      name: 'System Administrator',
      description: 'Full system access and administration',
      permissions: ['view_training', 'manage_training', 'approve_training', 'delete_training', 'view_users', 'manage_users', 'assign_roles', 'deactivate_users', 'view_reports', 'generate_reports', 'export_data', 'audit_logs', 'system_config', 'backup_restore', 'integration_management', 'system_monitoring']
    }
  ];

  const getUserPermissions = () => {
    if (!selectedUser) return [];
    return selectedUser?.permissions || [];
  };

  const hasPermission = (permissionId) => {
    return getUserPermissions()?.includes(permissionId);
  };

  const handlePermissionToggle = (permissionId, checked) => {
    if (!selectedUser) return;
    
    const currentPermissions = getUserPermissions();
    let newPermissions;
    
    if (checked) {
      newPermissions = [...currentPermissions, permissionId];
    } else {
      newPermissions = currentPermissions?.filter(p => p !== permissionId);
    }
    
    onPermissionChange(selectedUser?.id, newPermissions);
  };

  const applyRoleTemplate = (template) => {
    if (!selectedUser) return;
    onPermissionChange(selectedUser?.id, template?.permissions);
  };

  const getModulePermissionCount = (module) => {
    const userPermissions = getUserPermissions();
    const modulePermissions = module.permissions?.map(p => p?.id);
    const grantedCount = modulePermissions?.filter(p => userPermissions?.includes(p))?.length;
    return `${grantedCount}/${modulePermissions?.length}`;
  };

  if (!selectedUser) {
    return (
      <div className={`bg-card border border-border rounded-lg p-4 h-full flex items-center justify-center ${className}`}>
        <div className="text-center">
          <Icon name="UserCog" size={48} className="text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-2">Select a User</h3>
          <p className="text-muted-foreground">
            Choose a user from the list to view and manage their permissions
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-card border border-border rounded-lg p-4 h-full ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center overflow-hidden">
            <img 
              src={selectedUser?.avatar} 
              alt={selectedUser?.name}
              className="w-full h-full object-cover"
              onError={(e) => {
                e.target.style.display = 'none';
                e.target.nextSibling.style.display = 'flex';
              }}
            />
            <Icon name="User" size={20} className="text-primary hidden" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">{selectedUser?.name}</h3>
            <p className="text-sm text-muted-foreground">{selectedUser?.role}</p>
          </div>
        </div>
        <Button variant="outline" size="sm" iconName="Save" iconPosition="left">
          Save Changes
        </Button>
      </div>
      {/* Tabs */}
      <div className="flex space-x-1 mb-4 bg-muted p-1 rounded-lg">
        <button
          onClick={() => setActiveTab('permissions')}
          className={`flex-1 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
            activeTab === 'permissions' ?'bg-background text-foreground shadow-sm' :'text-muted-foreground hover:text-foreground'
          }`}
        >
          Permissions
        </button>
        <button
          onClick={() => setActiveTab('templates')}
          className={`flex-1 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
            activeTab === 'templates' ?'bg-background text-foreground shadow-sm' :'text-muted-foreground hover:text-foreground'
          }`}
        >
          Role Templates
        </button>
        <button
          onClick={() => setActiveTab('audit')}
          className={`flex-1 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
            activeTab === 'audit' ?'bg-background text-foreground shadow-sm' :'text-muted-foreground hover:text-foreground'
          }`}
        >
          Audit Log
        </button>
      </div>
      {/* Content */}
      <div className="overflow-y-auto max-h-[calc(100vh-300px)]">
        {activeTab === 'permissions' && (
          <div className="space-y-4">
            {systemModules?.map((module) => (
              <div key={module.id} className="border border-border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-2">
                    <Icon name={module.icon} size={16} className="text-primary" />
                    <h4 className="font-medium text-foreground">{module.name}</h4>
                  </div>
                  <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded">
                    {getModulePermissionCount(module)}
                  </span>
                </div>
                
                <div className="grid grid-cols-1 gap-2">
                  {module.permissions?.map((permission) => (
                    <div key={permission?.id} className="flex items-start space-x-3 p-2 hover:bg-muted/50 rounded">
                      <Checkbox
                        checked={hasPermission(permission?.id)}
                        onChange={(e) => handlePermissionToggle(permission?.id, e?.target?.checked)}
                        className="mt-0.5"
                      />
                      <div className="flex-1">
                        <div className="font-medium text-sm text-foreground">{permission?.name}</div>
                        <div className="text-xs text-muted-foreground">{permission?.description}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'templates' && (
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground mb-4">
              Apply a role template to quickly assign common permission sets
            </p>
            {roleTemplates?.map((template) => (
              <div key={template?.id} className="border border-border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium text-foreground">{template?.name}</h4>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => applyRoleTemplate(template)}
                  >
                    Apply Template
                  </Button>
                </div>
                <p className="text-sm text-muted-foreground mb-3">{template?.description}</p>
                <div className="flex flex-wrap gap-1">
                  {template?.permissions?.slice(0, 6)?.map((permissionId) => {
                    const permission = systemModules?.flatMap(m => m?.permissions)?.find(p => p?.id === permissionId);
                    return permission ? (
                      <span key={permissionId} className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">
                        {permission?.name}
                      </span>
                    ) : null;
                  })}
                  {template?.permissions?.length > 6 && (
                    <span className="text-xs bg-muted text-muted-foreground px-2 py-1 rounded">
                      +{template?.permissions?.length - 6} more
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'audit' && (
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground mb-4">
              Recent permission changes for {selectedUser?.name}
            </p>
            <div className="space-y-2">
              {[
                {
                  id: 1,
                  action: 'Permission Added',
                  permission: 'Manage Training',
                  timestamp: new Date('2024-08-24T14:30:00'),
                  changedBy: 'Lisa Anderson'
                },
                {
                  id: 2,
                  action: 'Permission Removed',
                  permission: 'Delete Training',
                  timestamp: new Date('2024-08-23T09:15:00'),
                  changedBy: 'System Admin'
                },
                {
                  id: 3,
                  action: 'Role Template Applied',
                  permission: 'Production Supervisor Template',
                  timestamp: new Date('2024-08-22T16:45:00'),
                  changedBy: 'Lisa Anderson'
                }
              ]?.map((log) => (
                <div key={log?.id} className="flex items-center space-x-3 p-3 bg-muted/50 rounded-lg">
                  <Icon 
                    name={log?.action?.includes('Added') ? 'Plus' : log?.action?.includes('Removed') ? 'Minus' : 'Settings'} 
                    size={14} 
                    className={`${
                      log?.action?.includes('Added') ? 'text-success' : 
                      log?.action?.includes('Removed') ? 'text-error' : 'text-primary'
                    }`}
                  />
                  <div className="flex-1">
                    <div className="text-sm font-medium text-foreground">{log?.action}</div>
                    <div className="text-xs text-muted-foreground">{log?.permission}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-muted-foreground">
                      {log?.timestamp?.toLocaleDateString()}
                    </div>
                    <div className="text-xs text-muted-foreground">by {log?.changedBy}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PermissionMatrix;