import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const OrganizationalHierarchy = ({ 
  onDepartmentSelect, 
  selectedDepartment,
  className = '' 
}) => {
  const [expandedNodes, setExpandedNodes] = useState({
    'dairy-operations': true,
    'production': true,
    'quality-control': true
  });

  const organizationTree = [
    {
      id: 'dairy-operations',
      name: 'Dairy Operations',
      type: 'division',
      icon: 'Building2',
      userCount: 245,
      children: [
        {
          id: 'production',
          name: 'Production Department',
          type: 'department',
          icon: 'Factory',
          userCount: 89,
          children: [
            { id: 'production-team', name: 'Production Team', type: 'team', icon: 'Users', userCount: 45 },
            { id: 'machine-operators', name: 'Machine Operators', type: 'team', icon: 'Settings', userCount: 28 },
            { id: 'packaging-team', name: 'Packaging Team', type: 'team', icon: 'Package', userCount: 16 }
          ]
        },
        {
          id: 'quality-control',
          name: 'Quality Control',
          type: 'department',
          icon: 'Shield',
          userCount: 34,
          children: [
            { id: 'lab-staff', name: 'Laboratory Staff', type: 'team', icon: 'FlaskConical', userCount: 18 },
            { id: 'quality-inspectors', name: 'Quality Inspectors', type: 'team', icon: 'Search', userCount: 16 }
          ]
        },
        {
          id: 'maintenance',
          name: 'Maintenance Team',
          type: 'department',
          icon: 'Wrench',
          userCount: 22,
          children: [
            { id: 'mechanical', name: 'Mechanical', type: 'team', icon: 'Cog', userCount: 14 },
            { id: 'electrical', name: 'Electrical', type: 'team', icon: 'Zap', userCount: 8 }
          ]
        },
        {
          id: 'safety',
          name: 'Safety & Compliance',
          type: 'department',
          icon: 'ShieldCheck',
          userCount: 15,
          children: [
            { id: 'safety-officers', name: 'Safety Officers', type: 'team', icon: 'HardHat', userCount: 8 },
            { id: 'emergency-response', name: 'Emergency Response', type: 'team', icon: 'Siren', userCount: 7 }
          ]
        },
        {
          id: 'logistics',
          name: 'Logistics & Transport',
          type: 'department',
          icon: 'Truck',
          userCount: 28,
          children: [
            { id: 'forklift-operators', name: 'Forklift Operators', type: 'team', icon: 'Forklift', userCount: 12 },
            { id: 'delivery-drivers', name: 'Delivery Drivers', type: 'team', icon: 'Car', userCount: 16 }
          ]
        },
        {
          id: 'management',
          name: 'Management',
          type: 'department',
          icon: 'Crown',
          userCount: 18,
          children: [
            { id: 'supervisors', name: 'Supervisors', type: 'team', icon: 'UserCheck', userCount: 12 },
            { id: 'plant-managers', name: 'Plant Managers', type: 'team', icon: 'Building', userCount: 6 }
          ]
        },
        {
          id: 'support',
          name: 'Support Services',
          type: 'department',
          icon: 'HeadphonesIcon',
          userCount: 39,
          children: [
            { id: 'hr-personnel', name: 'HR Personnel', type: 'team', icon: 'Users2', userCount: 8 },
            { id: 'training-coordinators', name: 'Training Coordinators', type: 'team', icon: 'GraduationCap', userCount: 5 },
            { id: 'admin-staff', name: 'Administrative Staff', type: 'team', icon: 'FileText', userCount: 26 }
          ]
        }
      ]
    }
  ];

  const toggleNode = (nodeId) => {
    setExpandedNodes(prev => ({
      ...prev,
      [nodeId]: !prev?.[nodeId]
    }));
  };

  const handleNodeSelect = (node) => {
    onDepartmentSelect(node);
  };

  const renderNode = (node, level = 0) => {
    const isExpanded = expandedNodes?.[node?.id];
    const hasChildren = node?.children && node?.children?.length > 0;
    const isSelected = selectedDepartment?.id === node?.id;

    return (
      <div key={node?.id} className="space-y-1">
        <div
          className={`
            flex items-center space-x-2 p-2 rounded-lg cursor-pointer transition-colors
            ${isSelected ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'}
          `}
          style={{ paddingLeft: `${level * 16 + 8}px` }}
          onClick={() => handleNodeSelect(node)}
        >
          {hasChildren && (
            <Button
              variant="ghost"
              size="icon"
              className="h-4 w-4 p-0"
              onClick={(e) => {
                e?.stopPropagation();
                toggleNode(node?.id);
              }}
            >
              <Icon 
                name={isExpanded ? 'ChevronDown' : 'ChevronRight'} 
                size={12} 
              />
            </Button>
          )}
          {!hasChildren && <div className="w-4" />}
          
          <Icon 
            name={node?.icon} 
            size={14} 
            className={isSelected ? 'text-primary-foreground' : 'text-muted-foreground'}
          />
          
          <span className={`text-sm font-medium flex-1 ${isSelected ? 'text-primary-foreground' : 'text-foreground'}`}>
            {node?.name}
          </span>
          
          <span className={`text-xs px-2 py-1 rounded-full ${
            isSelected 
              ? 'bg-primary-foreground/20 text-primary-foreground' 
              : 'bg-muted text-muted-foreground'
          }`}>
            {node?.userCount}
          </span>
        </div>
        {hasChildren && isExpanded && (
          <div className="space-y-1">
            {node?.children?.map(child => renderNode(child, level + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className={`bg-card border border-border rounded-lg p-4 h-full ${className}`}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Icon name="Sitemap" size={18} className="text-primary" />
          <h3 className="text-lg font-semibold text-foreground">Organization</h3>
        </div>
        <Button
          variant="ghost"
          size="icon"
          title="Refresh hierarchy"
        >
          <Icon name="RefreshCw" size={16} />
        </Button>
      </div>
      <div className="space-y-2 overflow-y-auto max-h-[calc(100vh-200px)]">
        {organizationTree?.map(node => renderNode(node))}
      </div>
      <div className="mt-4 pt-4 border-t border-border">
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <span>Total Users</span>
          <span className="font-medium text-foreground">245</span>
        </div>
        <div className="flex items-center justify-between text-sm text-muted-foreground mt-1">
          <span>Active Sessions</span>
          <span className="font-medium text-success">187</span>
        </div>
      </div>
    </div>
  );
};

export default OrganizationalHierarchy;