import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const UserListGrid = ({ 
  selectedDepartment, 
  onUserSelect, 
  selectedUsers,
  className = '' 
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [roleFilter, setRoleFilter] = useState('all');
  const [sortBy, setSortBy] = useState('name');
  const [sortOrder, setSortOrder] = useState('asc');

  const mockUsers = [
    {
      id: 'usr_001',
      name: 'Sarah Johnson',
      email: 'sarah.johnson@dairyops.com',
      employeeId: 'EMP-2024-001',
      department: 'Production Department',
      team: 'Production Team',
      role: 'Production Supervisor',
      status: 'active',
      lastLogin: new Date('2024-08-24T14:30:00'),
      permissions: ['view_training', 'manage_team', 'approve_training'],
      avatar: 'https://randomuser.me/api/portraits/women/1.jpg',
      joinDate: new Date('2023-03-15'),
      ssoEnabled: true,
      mfaEnabled: true
    },
    {
      id: 'usr_002',
      name: 'Michael Rodriguez',
      email: 'michael.rodriguez@dairyops.com',
      employeeId: 'EMP-2024-002',
      department: 'Quality Control',
      team: 'Laboratory Staff',
      role: 'Quality Analyst',
      status: 'active',
      lastLogin: new Date('2024-08-24T16:45:00'),
      permissions: ['view_training', 'manage_quality'],
      avatar: 'https://randomuser.me/api/portraits/men/2.jpg',
      joinDate: new Date('2023-07-22'),
      ssoEnabled: true,
      mfaEnabled: false
    },
    {
      id: 'usr_003',
      name: 'Emily Chen',
      email: 'emily.chen@dairyops.com',
      employeeId: 'EMP-2024-003',
      department: 'Safety & Compliance',
      team: 'Safety Officers',
      role: 'Safety Officer',
      status: 'active',
      lastLogin: new Date('2024-08-24T09:15:00'),
      permissions: ['view_training', 'manage_safety', 'audit_compliance'],
      avatar: 'https://randomuser.me/api/portraits/women/3.jpg',
      joinDate: new Date('2022-11-08'),
      ssoEnabled: true,
      mfaEnabled: true
    },
    {
      id: 'usr_004',
      name: 'David Thompson',
      email: 'david.thompson@dairyops.com',
      employeeId: 'EMP-2024-004',
      department: 'Maintenance Team',
      team: 'Mechanical',
      role: 'Maintenance Technician',
      status: 'inactive',
      lastLogin: new Date('2024-08-20T11:30:00'),
      permissions: ['view_training'],
      avatar: 'https://randomuser.me/api/portraits/men/4.jpg',
      joinDate: new Date('2023-01-12'),
      ssoEnabled: false,
      mfaEnabled: false
    },
    {
      id: 'usr_005',
      name: 'Lisa Anderson',
      email: 'lisa.anderson@dairyops.com',
      employeeId: 'EMP-2024-005',
      department: 'Support Services',
      team: 'Training Coordinators',
      role: 'Training Coordinator',
      status: 'active',
      lastLogin: new Date('2024-08-24T18:20:00'),
      permissions: ['view_training', 'manage_training', 'manage_users', 'system_admin'],
      avatar: 'https://randomuser.me/api/portraits/women/5.jpg',
      joinDate: new Date('2022-05-03'),
      ssoEnabled: true,
      mfaEnabled: true
    }
  ];

  const roleOptions = [
    { value: 'all', label: 'All Roles' },
    { value: 'Production Supervisor', label: 'Production Supervisor' },
    { value: 'Quality Analyst', label: 'Quality Analyst' },
    { value: 'Safety Officer', label: 'Safety Officer' },
    { value: 'Maintenance Technician', label: 'Maintenance Technician' },
    { value: 'Training Coordinator', label: 'Training Coordinator' }
  ];

  const statusOptions = [
    { value: 'all', label: 'All Status' },
    { value: 'active', label: 'Active' },
    { value: 'inactive', label: 'Inactive' },
    { value: 'pending', label: 'Pending' }
  ];

  const filteredUsers = mockUsers?.filter(user => {
    const matchesSearch = user?.name?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
                         user?.email?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
                         user?.employeeId?.toLowerCase()?.includes(searchTerm?.toLowerCase());
    const matchesStatus = statusFilter === 'all' || user?.status === statusFilter;
    const matchesRole = roleFilter === 'all' || user?.role === roleFilter;
    const matchesDepartment = !selectedDepartment || user?.department === selectedDepartment?.name;
    
    return matchesSearch && matchesStatus && matchesRole && matchesDepartment;
  });

  const sortedUsers = [...filteredUsers]?.sort((a, b) => {
    let aValue = a?.[sortBy];
    let bValue = b?.[sortBy];
    
    if (sortBy === 'lastLogin') {
      aValue = new Date(aValue);
      bValue = new Date(bValue);
    }
    
    if (sortOrder === 'asc') {
      return aValue > bValue ? 1 : -1;
    } else {
      return aValue < bValue ? 1 : -1;
    }
  });

  const handleUserSelect = (user) => {
    onUserSelect(user);
  };

  const handleSelectAll = (checked) => {
    if (checked) {
      const allUserIds = sortedUsers?.map(user => user?.id);
      onUserSelect(allUserIds, 'bulk');
    } else {
      onUserSelect([], 'bulk');
    }
  };

  const handleIndividualSelect = (userId, checked) => {
    if (checked) {
      onUserSelect([...selectedUsers, userId], 'bulk');
    } else {
      onUserSelect(selectedUsers?.filter(id => id !== userId), 'bulk');
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'text-success';
      case 'inactive': return 'text-error';
      case 'pending': return 'text-warning';
      default: return 'text-muted-foreground';
    }
  };

  const formatLastLogin = (date) => {
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays}d ago`;
  };

  return (
    <div className={`bg-card border border-border rounded-lg p-4 h-full ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Icon name="Users" size={18} className="text-primary" />
          <h3 className="text-lg font-semibold text-foreground">
            Users {selectedDepartment && `- ${selectedDepartment?.name}`}
          </h3>
          <span className="text-sm text-muted-foreground">
            ({sortedUsers?.length} users)
          </span>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm" iconName="Download" iconPosition="left">
            Export
          </Button>
          <Button variant="default" size="sm" iconName="Plus" iconPosition="left">
            Add User
          </Button>
        </div>
      </div>
      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
        <Input
          type="search"
          placeholder="Search users..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e?.target?.value)}
        />
        <Select
          options={statusOptions}
          value={statusFilter}
          onChange={setStatusFilter}
          placeholder="Filter by status"
        />
        <Select
          options={roleOptions}
          value={roleFilter}
          onChange={setRoleFilter}
          placeholder="Filter by role"
        />
        <Select
          options={[
            { value: 'name', label: 'Sort by Name' },
            { value: 'role', label: 'Sort by Role' },
            { value: 'lastLogin', label: 'Sort by Last Login' },
            { value: 'status', label: 'Sort by Status' }
          ]}
          value={sortBy}
          onChange={setSortBy}
        />
      </div>
      {/* Bulk Actions */}
      {selectedUsers?.length > 0 && (
        <div className="flex items-center justify-between p-3 bg-accent/10 border border-accent/20 rounded-lg mb-4">
          <span className="text-sm font-medium text-foreground">
            {selectedUsers?.length} user{selectedUsers?.length > 1 ? 's' : ''} selected
          </span>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" iconName="UserCheck" iconPosition="left">
              Assign Role
            </Button>
            <Button variant="outline" size="sm" iconName="Settings" iconPosition="left">
              Manage Permissions
            </Button>
            <Button variant="destructive" size="sm" iconName="UserX" iconPosition="left">
              Deactivate
            </Button>
          </div>
        </div>
      )}
      {/* User Grid */}
      <div className="overflow-y-auto max-h-[calc(100vh-300px)]">
        <div className="space-y-2">
          {/* Header Row */}
          <div className="grid grid-cols-12 gap-4 p-3 bg-muted rounded-lg text-sm font-medium text-muted-foreground">
            <div className="col-span-1 flex items-center">
              <Checkbox
                checked={selectedUsers?.length === sortedUsers?.length && sortedUsers?.length > 0}
                onChange={(e) => handleSelectAll(e?.target?.checked)}
              />
            </div>
            <div className="col-span-3">User</div>
            <div className="col-span-2">Role</div>
            <div className="col-span-2">Department</div>
            <div className="col-span-1">Status</div>
            <div className="col-span-2">Last Login</div>
            <div className="col-span-1">Actions</div>
          </div>

          {/* User Rows */}
          {sortedUsers?.map((user) => (
            <div
              key={user?.id}
              className="grid grid-cols-12 gap-4 p-3 bg-background border border-border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer"
              onClick={() => handleUserSelect(user)}
            >
              <div className="col-span-1 flex items-center">
                <Checkbox
                  checked={selectedUsers?.includes(user?.id)}
                  onChange={(e) => {
                    e?.stopPropagation();
                    handleIndividualSelect(user?.id, e?.target?.checked);
                  }}
                />
              </div>
              
              <div className="col-span-3 flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center overflow-hidden">
                  <img 
                    src={user?.avatar} 
                    alt={user?.name}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.target.style.display = 'none';
                      e.target.nextSibling.style.display = 'flex';
                    }}
                  />
                  <Icon name="User" size={16} className="text-primary hidden" />
                </div>
                <div>
                  <div className="font-medium text-foreground">{user?.name}</div>
                  <div className="text-xs text-muted-foreground">{user?.email}</div>
                  <div className="text-xs text-muted-foreground">{user?.employeeId}</div>
                </div>
              </div>
              
              <div className="col-span-2 flex items-center">
                <div>
                  <div className="font-medium text-foreground">{user?.role}</div>
                  <div className="text-xs text-muted-foreground">{user?.team}</div>
                </div>
              </div>
              
              <div className="col-span-2 flex items-center">
                <span className="text-sm text-foreground">{user?.department}</span>
              </div>
              
              <div className="col-span-1 flex items-center">
                <div className="flex items-center space-x-1">
                  <div className={`w-2 h-2 rounded-full ${
                    user?.status === 'active' ? 'bg-success' : 
                    user?.status === 'inactive' ? 'bg-error' : 'bg-warning'
                  }`} />
                  <span className={`text-sm capitalize ${getStatusColor(user?.status)}`}>
                    {user?.status}
                  </span>
                </div>
              </div>
              
              <div className="col-span-2 flex items-center">
                <div>
                  <div className="text-sm text-foreground">{formatLastLogin(user?.lastLogin)}</div>
                  <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                    {user?.ssoEnabled && <Icon name="Shield" size={10} title="SSO Enabled" />}
                    {user?.mfaEnabled && <Icon name="Smartphone" size={10} title="MFA Enabled" />}
                  </div>
                </div>
              </div>
              
              <div className="col-span-1 flex items-center">
                <div className="flex items-center space-x-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6"
                    onClick={(e) => {
                      e?.stopPropagation();
                      // Handle edit action
                    }}
                    title="Edit user"
                  >
                    <Icon name="Edit2" size={12} />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6"
                    onClick={(e) => {
                      e?.stopPropagation();
                      // Handle more actions
                    }}
                    title="More actions"
                  >
                    <Icon name="MoreHorizontal" size={12} />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {sortedUsers?.length === 0 && (
          <div className="text-center py-12">
            <Icon name="Users" size={48} className="text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium text-foreground mb-2">No users found</h3>
            <p className="text-muted-foreground mb-4">
              {selectedDepartment 
                ? `No users match your search criteria in ${selectedDepartment?.name}`
                : 'No users match your search criteria'
              }
            </p>
            <Button variant="outline" onClick={() => setSearchTerm('')}>
              Clear filters
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default UserListGrid;