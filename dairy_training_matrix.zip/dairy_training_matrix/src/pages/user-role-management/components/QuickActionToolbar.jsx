import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

import Select from '../../../components/ui/Select';

const QuickActionToolbar = ({ 
  selectedUsers, 
  onBulkAction,
  onImportUsers,
  onExportUsers,
  className = '' 
}) => {
  const [showBulkActions, setShowBulkActions] = useState(false);
  const [bulkRole, setBulkRole] = useState('');
  const [bulkStatus, setBulkStatus] = useState('');

  const roleOptions = [
    { value: '', label: 'Select Role' },
    { value: 'Production Supervisor', label: 'Production Supervisor' },
    { value: 'Quality Analyst', label: 'Quality Analyst' },
    { value: 'Safety Officer', label: 'Safety Officer' },
    { value: 'Maintenance Technician', label: 'Maintenance Technician' },
    { value: 'Training Coordinator', label: 'Training Coordinator' },
    { value: 'Machine Operator', label: 'Machine Operator' },
    { value: 'Laboratory Staff', label: 'Laboratory Staff' }
  ];

  const statusOptions = [
    { value: '', label: 'Select Status' },
    { value: 'active', label: 'Active' },
    { value: 'inactive', label: 'Inactive' },
    { value: 'pending', label: 'Pending Activation' }
  ];

  const quickActions = [
    {
      id: 'assign_role',
      label: 'Assign Role',
      icon: 'UserCheck',
      description: 'Assign roles to selected users',
      requiresSelection: true
    },
    {
      id: 'reset_password',
      label: 'Reset Password',
      icon: 'Key',
      description: 'Send password reset emails',
      requiresSelection: true
    },
    {
      id: 'enable_mfa',
      label: 'Enable MFA',
      icon: 'Smartphone',
      description: 'Enable multi-factor authentication',
      requiresSelection: true
    },
    {
      id: 'sync_ldap',
      label: 'Sync LDAP',
      icon: 'RefreshCw',
      description: 'Synchronize with LDAP directory',
      requiresSelection: false
    },
    {
      id: 'audit_report',
      label: 'Audit Report',
      icon: 'FileText',
      description: 'Generate user audit report',
      requiresSelection: false
    },
    {
      id: 'permission_template',
      label: 'Permission Templates',
      icon: 'Template',
      description: 'Manage role templates',
      requiresSelection: false
    }
  ];

  const handleQuickAction = (actionId) => {
    switch (actionId) {
      case 'assign_role':
        setShowBulkActions(true);
        break;
      case 'reset_password': onBulkAction('reset_password', selectedUsers);
        break;
      case 'enable_mfa': onBulkAction('enable_mfa', selectedUsers);
        break;
      case 'sync_ldap': onBulkAction('sync_ldap', []);
        break;
      case 'audit_report': onBulkAction('audit_report', []);
        break;
      case 'permission_template': onBulkAction('permission_template', []);
        break;
      default:
        break;
    }
  };

  const handleBulkRoleAssignment = () => {
    if (bulkRole && selectedUsers?.length > 0) {
      onBulkAction('assign_role', selectedUsers, { role: bulkRole });
      setBulkRole('');
      setShowBulkActions(false);
    }
  };

  const handleBulkStatusChange = () => {
    if (bulkStatus && selectedUsers?.length > 0) {
      onBulkAction('change_status', selectedUsers, { status: bulkStatus });
      setBulkStatus('');
      setShowBulkActions(false);
    }
  };

  const handleFileImport = (event) => {
    const file = event?.target?.files?.[0];
    if (file) {
      onImportUsers(file);
    }
  };

  return (
    <div className={`bg-card border border-border rounded-lg p-4 ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Icon name="Zap" size={18} className="text-primary" />
          <h3 className="text-lg font-semibold text-foreground">Quick Actions</h3>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowBulkActions(!showBulkActions)}
            iconName={showBulkActions ? 'ChevronUp' : 'ChevronDown'}
            iconPosition="right"
          >
            Bulk Operations
          </Button>
        </div>
      </div>
      {/* Selection Info */}
      {selectedUsers?.length > 0 && (
        <div className="flex items-center justify-between p-3 bg-primary/10 border border-primary/20 rounded-lg mb-4">
          <div className="flex items-center space-x-2">
            <Icon name="Users" size={16} className="text-primary" />
            <span className="text-sm font-medium text-primary">
              {selectedUsers?.length} user{selectedUsers?.length > 1 ? 's' : ''} selected
            </span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onBulkAction('clear_selection', [])}
            iconName="X"
            iconPosition="left"
          >
            Clear Selection
          </Button>
        </div>
      )}
      {/* Bulk Actions Panel */}
      {showBulkActions && (
        <div className="space-y-4 p-4 bg-muted/50 border border-border rounded-lg mb-4">
          <h4 className="font-medium text-foreground">Bulk Operations</h4>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Bulk Role Assignment */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Assign Role</label>
              <div className="flex space-x-2">
                <Select
                  options={roleOptions}
                  value={bulkRole}
                  onChange={setBulkRole}
                  placeholder="Select role"
                  className="flex-1"
                />
                <Button
                  variant="default"
                  size="sm"
                  onClick={handleBulkRoleAssignment}
                  disabled={!bulkRole || selectedUsers?.length === 0}
                  iconName="UserCheck"
                >
                  Apply
                </Button>
              </div>
            </div>

            {/* Bulk Status Change */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Change Status</label>
              <div className="flex space-x-2">
                <Select
                  options={statusOptions}
                  value={bulkStatus}
                  onChange={setBulkStatus}
                  placeholder="Select status"
                  className="flex-1"
                />
                <Button
                  variant="default"
                  size="sm"
                  onClick={handleBulkStatusChange}
                  disabled={!bulkStatus || selectedUsers?.length === 0}
                  iconName="Settings"
                >
                  Apply
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
      {/* Import/Export Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div className="space-y-2">
          <label className="text-sm font-medium text-foreground">Import Users</label>
          <div className="flex space-x-2">
            <input
              type="file"
              accept=".csv,.xlsx"
              onChange={handleFileImport}
              className="hidden"
              id="user-import"
            />
            <Button
              variant="outline"
              size="sm"
              onClick={() => document.getElementById('user-import')?.click()}
              iconName="Upload"
              iconPosition="left"
              className="flex-1"
            >
              Import CSV/Excel
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onBulkAction('download_template', [])}
              iconName="Download"
              title="Download import template"
            >
              Template
            </Button>
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium text-foreground">Export Users</label>
          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onExportUsers('csv')}
              iconName="FileText"
              iconPosition="left"
              className="flex-1"
            >
              Export CSV
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onExportUsers('excel')}
              iconName="FileSpreadsheet"
              iconPosition="left"
              className="flex-1"
            >
              Export Excel
            </Button>
          </div>
        </div>
      </div>
      {/* Quick Action Buttons */}
      <div className="space-y-2">
        <h4 className="text-sm font-medium text-foreground">Quick Actions</h4>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {quickActions?.map((action) => (
            <Button
              key={action?.id}
              variant="outline"
              size="sm"
              onClick={() => handleQuickAction(action?.id)}
              disabled={action?.requiresSelection && selectedUsers?.length === 0}
              iconName={action?.icon}
              iconPosition="left"
              title={action?.description}
              className="justify-start"
            >
              {action?.label}
            </Button>
          ))}
        </div>
      </div>
      {/* System Status */}
      <div className="mt-4 pt-4 border-t border-border">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          <div>
            <div className="text-lg font-semibold text-foreground">245</div>
            <div className="text-xs text-muted-foreground">Total Users</div>
          </div>
          <div>
            <div className="text-lg font-semibold text-success">187</div>
            <div className="text-xs text-muted-foreground">Active</div>
          </div>
          <div>
            <div className="text-lg font-semibold text-warning">12</div>
            <div className="text-xs text-muted-foreground">Pending</div>
          </div>
          <div>
            <div className="text-lg font-semibold text-error">8</div>
            <div className="text-xs text-muted-foreground">Inactive</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuickActionToolbar;