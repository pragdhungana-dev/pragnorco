import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import RoleBasedSidebar from '../../components/ui/RoleBasedSidebar';
import OrganizationalHierarchy from './components/OrganizationalHierarchy';
import UserListGrid from './components/UserListGrid';
import PermissionMatrix from './components/PermissionMatrix';
import QuickActionToolbar from './components/QuickActionToolbar';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const UserRoleManagement = () => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [selectedDepartment, setSelectedDepartment] = useState(null);
  const [selectedUser, setSelectedUser] = useState(null);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [showQuickActions, setShowQuickActions] = useState(true);

  // Mock current user role for demonstration
  const currentUserRole = 'training_coordinator';

  useEffect(() => {
    // Auto-select first department on load
    const defaultDepartment = {
      id: 'production',
      name: 'Production Department',
      type: 'department',
      icon: 'Factory',
      userCount: 89
    };
    setSelectedDepartment(defaultDepartment);
  }, []);

  const handleSidebarToggle = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const handleMobileMenuToggle = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const handleDepartmentSelect = (department) => {
    setSelectedDepartment(department);
    setSelectedUser(null);
    setSelectedUsers([]);
  };

  const handleUserSelect = (user, type = 'single') => {
    if (type === 'bulk') {
      setSelectedUsers(user);
    } else {
      setSelectedUser(user);
      setSelectedUsers([]);
    }
  };

  const handlePermissionChange = (userId, newPermissions) => {
    // In a real application, this would make an API call
    console.log(`Updating permissions for user ${userId}:`, newPermissions);
    
    // Update the selected user's permissions locally
    if (selectedUser && selectedUser?.id === userId) {
      setSelectedUser({
        ...selectedUser,
        permissions: newPermissions
      });
    }
  };

  const handleBulkAction = (action, userIds, options = {}) => {
    console.log(`Performing bulk action: ${action}`, { userIds, options });
    
    switch (action) {
      case 'assign_role':
        // Handle role assignment
        break;
      case 'change_status':
        // Handle status change
        break;
      case 'reset_password':
        // Handle password reset
        break;
      case 'enable_mfa':
        // Handle MFA enablement
        break;
      case 'sync_ldap':
        // Handle LDAP sync
        break;
      case 'audit_report':
        // Generate audit report
        break;
      case 'permission_template':
        // Open permission template manager
        break;
      case 'clear_selection':
        setSelectedUsers([]);
        break;
      case 'download_template':
        // Download import template
        break;
      default:
        break;
    }
  };

  const handleImportUsers = (file) => {
    console.log('Importing users from file:', file?.name);
    // Handle file import logic
  };

  const handleExportUsers = (format) => {
    console.log(`Exporting users in ${format} format`);
    // Handle export logic
  };

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>User & Role Management - Dairy Training Matrix</title>
        <meta name="description" content="Comprehensive access control and permission administration for the training management system" />
      </Helmet>

      {/* Header */}
      <Header 
        onMenuToggle={handleMobileMenuToggle}
        isMenuOpen={isMobileMenuOpen}
      />

      {/* Sidebar */}
      <RoleBasedSidebar
        isCollapsed={isSidebarCollapsed}
        onToggleCollapse={handleSidebarToggle}
        userRole={currentUserRole}
        className="lg:block hidden"
      />

      {/* Main Content */}
      <main 
        className={`
          pt-16 transition-all duration-200
          ${isSidebarCollapsed ? 'lg:ml-16' : 'lg:ml-60'}
        `}
      >
        <div className="p-6">
          {/* Page Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Icon name="UserCog" size={20} color="white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">User & Role Management</h1>
                <p className="text-muted-foreground">
                  Manage user accounts, roles, and permissions across the organization
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowQuickActions(!showQuickActions)}
                iconName={showQuickActions ? 'EyeOff' : 'Eye'}
                iconPosition="left"
              >
                {showQuickActions ? 'Hide' : 'Show'} Quick Actions
              </Button>
              <Button
                variant="default"
                size="sm"
                iconName="Plus"
                iconPosition="left"
              >
                Add User
              </Button>
            </div>
          </div>

          {/* Quick Actions Toolbar */}
          {showQuickActions && (
            <div className="mb-6">
              <QuickActionToolbar
                selectedUsers={selectedUsers}
                onBulkAction={handleBulkAction}
                onImportUsers={handleImportUsers}
                onExportUsers={handleExportUsers}
              />
            </div>
          )}

          {/* Three-Panel Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-[calc(100vh-200px)]">
            {/* Organizational Hierarchy - 25% */}
            <div className="lg:col-span-3">
              <OrganizationalHierarchy
                onDepartmentSelect={handleDepartmentSelect}
                selectedDepartment={selectedDepartment}
              />
            </div>

            {/* User List Grid - 50% */}
            <div className="lg:col-span-6">
              <UserListGrid
                selectedDepartment={selectedDepartment}
                onUserSelect={handleUserSelect}
                selectedUsers={selectedUsers}
              />
            </div>

            {/* Permission Matrix - 25% */}
            <div className="lg:col-span-3">
              <PermissionMatrix
                selectedUser={selectedUser}
                onPermissionChange={handlePermissionChange}
              />
            </div>
          </div>

          {/* Mobile Layout Adjustments */}
          <div className="lg:hidden mt-6">
            {selectedUser && (
              <div className="bg-card border border-border rounded-lg p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-foreground">Selected User</h3>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setSelectedUser(null)}
                    iconName="X"
                  >
                    Close
                  </Button>
                </div>
                <PermissionMatrix
                  selectedUser={selectedUser}
                  onPermissionChange={handlePermissionChange}
                />
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Mobile Sidebar Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="lg:hidden fixed inset-0 bg-background/80 backdrop-blur-sm z-50"
          onClick={handleMobileMenuToggle}
        >
          <RoleBasedSidebar
            isCollapsed={false}
            onToggleCollapse={() => {}}
            userRole={currentUserRole}
            className="w-64"
          />
        </div>
      )}

      {/* Keyboard Shortcuts Help */}
      <div className="fixed bottom-4 right-4 z-50">
        <Button
          variant="outline"
          size="sm"
          iconName="Keyboard"
          title="Keyboard shortcuts: Ctrl+F (Search), Ctrl+A (Select All), Ctrl+E (Export)"
        >
          Shortcuts
        </Button>
      </div>
    </div>
  );
};

export default UserRoleManagement;