import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import Input from '../../../components/ui/Input';

const CertificateGrid = ({ 
  selectedEmployee, 
  onCertificateSelect, 
  selectedCertificate,
  onBulkAction,
  className = '' 
}) => {
  const [certificates, setCertificates] = useState([]);
  const [sortBy, setSortBy] = useState('issueDate');
  const [sortOrder, setSortOrder] = useState('desc');
  const [filterBy, setFilterBy] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCertificates, setSelectedCertificates] = useState([]);
  const [showBulkActions, setShowBulkActions] = useState(false);

  // Mock certificate data
  const mockCertificates = [
    {
      id: 'CERT001',
      employeeId: 'EMP001',
      employeeName: 'Sarah Johnson',
      trainingType: 'HACCP Certification',
      category: 'Food Safety',
      issueDate: new Date('2024-01-15'),
      expiryDate: new Date('2025-01-15'),
      issuingAuthority: 'National Food Safety Institute',
      certificateNumber: 'HACCP-2024-001',
      status: 'valid',
      verificationStatus: 'verified',
      documentUrl: '/certificates/cert001.pdf',
      uploadDate: new Date('2024-01-16'),
      uploadedBy: 'Training Coordinator'
    },
    {
      id: 'CERT002',
      employeeId: 'EMP001',
      employeeName: 'Sarah Johnson',
      trainingType: 'Forklift Operation',
      category: 'Equipment Operation',
      issueDate: new Date('2023-06-10'),
      expiryDate: new Date('2025-06-10'),
      issuingAuthority: 'Industrial Safety Council',
      certificateNumber: 'FLT-2023-045',
      status: 'valid',
      verificationStatus: 'verified',
      documentUrl: '/certificates/cert002.pdf',
      uploadDate: new Date('2023-06-12'),
      uploadedBy: 'Safety Officer'
    },
    {
      id: 'CERT003',
      employeeId: 'EMP002',
      employeeName: 'Michael Rodriguez',
      trainingType: 'Quality Control Procedures',
      category: 'Quality Control',
      issueDate: new Date('2024-03-20'),
      expiryDate: new Date('2025-03-20'),
      issuingAuthority: 'Dairy Quality Institute',
      certificateNumber: 'QCP-2024-078',
      status: 'valid',
      verificationStatus: 'pending',
      documentUrl: '/certificates/cert003.pdf',
      uploadDate: new Date('2024-03-22'),
      uploadedBy: 'QC Manager'
    },
    {
      id: 'CERT004',
      employeeId: 'EMP001',
      employeeName: 'Sarah Johnson',
      trainingType: 'First Aid & CPR',
      category: 'Emergency Response',
      issueDate: new Date('2023-08-15'),
      expiryDate: new Date('2024-08-15'),
      issuingAuthority: 'American Red Cross',
      certificateNumber: 'CPR-2023-156',
      status: 'expired',
      verificationStatus: 'verified',
      documentUrl: '/certificates/cert004.pdf',
      uploadDate: new Date('2023-08-17'),
      uploadedBy: 'Safety Officer'
    },
    {
      id: 'CERT005',
      employeeId: 'EMP003',
      employeeName: 'Emily Chen',
      trainingType: 'Laboratory Safety',
      category: 'Safety',
      issueDate: new Date('2024-02-10'),
      expiryDate: new Date('2025-12-10'),
      issuingAuthority: 'Laboratory Safety Board',
      certificateNumber: 'LAB-2024-023',
      status: 'expiring',
      verificationStatus: 'verified',
      documentUrl: '/certificates/cert005.pdf',
      uploadDate: new Date('2024-02-12'),
      uploadedBy: 'Lab Manager'
    }
  ];

  const sortOptions = [
    { value: 'issueDate', label: 'Issue Date' },
    { value: 'expiryDate', label: 'Expiry Date' },
    { value: 'trainingType', label: 'Training Type' },
    { value: 'status', label: 'Status' },
    { value: 'verificationStatus', label: 'Verification Status' }
  ];

  const filterOptions = [
    { value: '', label: 'All Certificates' },
    { value: 'valid', label: 'Valid' },
    { value: 'expiring', label: 'Expiring Soon' },
    { value: 'expired', label: 'Expired' },
    { value: 'verified', label: 'Verified' },
    { value: 'pending', label: 'Pending Verification' }
  ];

  useEffect(() => {
    let filtered = mockCertificates;

    // Filter by selected employee
    if (selectedEmployee) {
      filtered = filtered?.filter(cert => cert?.employeeId === selectedEmployee?.id);
    }

    // Filter by search term
    if (searchTerm) {
      filtered = filtered?.filter(cert =>
        cert?.trainingType?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
        cert?.category?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
        cert?.issuingAuthority?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
        cert?.certificateNumber?.toLowerCase()?.includes(searchTerm?.toLowerCase())
      );
    }

    // Filter by status
    if (filterBy) {
      filtered = filtered?.filter(cert => 
        cert?.status === filterBy || cert?.verificationStatus === filterBy
      );
    }

    // Sort certificates
    filtered?.sort((a, b) => {
      let aValue = a?.[sortBy];
      let bValue = b?.[sortBy];

      if (sortBy === 'issueDate' || sortBy === 'expiryDate') {
        aValue = new Date(aValue);
        bValue = new Date(bValue);
      }

      if (sortOrder === 'asc') {
        return aValue > bValue ? 1 : -1;
      } else {
        return aValue < bValue ? 1 : -1;
      }
    });

    setCertificates(filtered);
  }, [selectedEmployee, searchTerm, filterBy, sortBy, sortOrder]);

  const getStatusColor = (status) => {
    switch (status) {
      case 'valid': return 'text-success';
      case 'expiring': return 'text-warning';
      case 'expired': return 'text-error';
      default: return 'text-muted-foreground';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'valid': return 'CheckCircle';
      case 'expiring': return 'Clock';
      case 'expired': return 'XCircle';
      default: return 'Circle';
    }
  };

  const getVerificationColor = (status) => {
    switch (status) {
      case 'verified': return 'text-success';
      case 'pending': return 'text-warning';
      case 'failed': return 'text-error';
      default: return 'text-muted-foreground';
    }
  };

  const formatDate = (date) => {
    return new Date(date)?.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getDaysUntilExpiry = (expiryDate) => {
    const today = new Date();
    const expiry = new Date(expiryDate);
    const diffTime = expiry - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const handleSelectCertificate = (certificateId) => {
    setSelectedCertificates(prev => {
      if (prev?.includes(certificateId)) {
        return prev?.filter(id => id !== certificateId);
      } else {
        return [...prev, certificateId];
      }
    });
  };

  const handleSelectAll = () => {
    if (selectedCertificates?.length === certificates?.length) {
      setSelectedCertificates([]);
    } else {
      setSelectedCertificates(certificates?.map(cert => cert?.id));
    }
  };

  useEffect(() => {
    setShowBulkActions(selectedCertificates?.length > 0);
  }, [selectedCertificates]);

  const handleBulkAction = (action) => {
    onBulkAction?.(action, selectedCertificates);
    setSelectedCertificates([]);
  };

  return (
    <div className={`bg-card border border-border rounded-lg shadow-industrial h-full flex flex-col ${className}`}>
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">
            Certificates
            {selectedEmployee && (
              <span className="text-sm font-normal text-muted-foreground ml-2">
                for {selectedEmployee?.name}
              </span>
            )}
          </h3>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              iconName="Upload"
              iconPosition="left"
            >
              Upload
            </Button>
            <Button
              variant="outline"
              size="sm"
              iconName="Download"
              iconPosition="left"
            >
              Export
            </Button>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
          <Input
            type="search"
            placeholder="Search certificates..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e?.target?.value)}
          />
          
          <Select
            options={sortOptions}
            value={sortBy}
            onChange={setSortBy}
            placeholder="Sort by"
          />
          
          <Select
            options={filterOptions}
            value={filterBy}
            onChange={setFilterBy}
            placeholder="Filter by status"
          />
        </div>

        {/* Sort Order Toggle */}
        <div className="flex items-center justify-between">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
            iconName={sortOrder === 'asc' ? 'ArrowUp' : 'ArrowDown'}
            iconPosition="left"
          >
            {sortOrder === 'asc' ? 'Ascending' : 'Descending'}
          </Button>

          <div className="text-sm text-muted-foreground">
            {certificates?.length} certificates
          </div>
        </div>

        {/* Bulk Actions */}
        {showBulkActions && (
          <div className="mt-3 p-3 bg-primary/5 border border-primary/20 rounded-lg">
            <div className="flex items-center justify-between">
              <span className="text-sm text-primary font-medium">
                {selectedCertificates?.length} certificates selected
              </span>
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleBulkAction('verify')}
                >
                  Verify
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleBulkAction('download')}
                >
                  Download
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleBulkAction('delete')}
                >
                  Delete
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
      {/* Certificate List */}
      <div className="flex-1 overflow-y-auto">
        {certificates?.length > 0 ? (
          <div className="divide-y divide-border">
            {/* Header Row */}
            <div className="p-3 bg-muted/50 grid grid-cols-12 gap-3 text-sm font-medium text-muted-foreground">
              <div className="col-span-1 flex items-center">
                <input
                  type="checkbox"
                  checked={selectedCertificates?.length === certificates?.length && certificates?.length > 0}
                  onChange={handleSelectAll}
                  className="rounded border-border"
                />
              </div>
              <div className="col-span-3">Training Type</div>
              <div className="col-span-2">Issue Date</div>
              <div className="col-span-2">Expiry Date</div>
              <div className="col-span-2">Status</div>
              <div className="col-span-1">Verified</div>
              <div className="col-span-1">Actions</div>
            </div>

            {/* Certificate Rows */}
            {certificates?.map((certificate) => {
              const daysUntilExpiry = getDaysUntilExpiry(certificate?.expiryDate);
              const isSelected = selectedCertificates?.includes(certificate?.id);
              
              return (
                <div
                  key={certificate?.id}
                  onClick={() => onCertificateSelect(certificate)}
                  className={`
                    p-3 grid grid-cols-12 gap-3 cursor-pointer transition-all hover:bg-muted/30
                    ${selectedCertificate?.id === certificate?.id ? 'bg-primary/5 border-l-4 border-l-primary' : ''}
                    ${isSelected ? 'bg-accent/5' : ''}
                  `}
                >
                  <div className="col-span-1 flex items-center">
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={(e) => {
                        e?.stopPropagation();
                        handleSelectCertificate(certificate?.id);
                      }}
                      className="rounded border-border"
                    />
                  </div>
                  <div className="col-span-3">
                    <div className="font-medium text-foreground">
                      {certificate?.trainingType}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {certificate?.category}
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {certificate?.certificateNumber}
                    </div>
                  </div>
                  <div className="col-span-2 text-sm">
                    {formatDate(certificate?.issueDate)}
                  </div>
                  <div className="col-span-2 text-sm">
                    <div>{formatDate(certificate?.expiryDate)}</div>
                    {daysUntilExpiry > 0 && daysUntilExpiry <= 30 && (
                      <div className="text-xs text-warning">
                        {daysUntilExpiry} days left
                      </div>
                    )}
                    {daysUntilExpiry < 0 && (
                      <div className="text-xs text-error">
                        {Math.abs(daysUntilExpiry)} days overdue
                      </div>
                    )}
                  </div>
                  <div className="col-span-2">
                    <div className={`flex items-center space-x-1 ${getStatusColor(certificate?.status)}`}>
                      <Icon name={getStatusIcon(certificate?.status)} size={14} />
                      <span className="text-sm capitalize">{certificate?.status}</span>
                    </div>
                  </div>
                  <div className="col-span-1">
                    <Icon 
                      name={certificate?.verificationStatus === 'verified' ? 'CheckCircle' : 'Clock'} 
                      size={16} 
                      className={getVerificationColor(certificate?.verificationStatus)}
                    />
                  </div>
                  <div className="col-span-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={(e) => {
                        e?.stopPropagation();
                        window.open(certificate?.documentUrl, '_blank');
                      }}
                      title="View Certificate"
                    >
                      <Icon name="Eye" size={14} />
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="flex-1 flex items-center justify-center py-12">
            <div className="text-center">
              <Icon name="Award" size={48} className="text-muted-foreground mx-auto mb-3" />
              <p className="text-muted-foreground">
                {selectedEmployee ? 'No certificates found for this employee' : 'Select an employee to view certificates'}
              </p>
              {selectedEmployee && (
                <Button
                  variant="outline"
                  size="sm"
                  className="mt-3"
                  iconName="Upload"
                  iconPosition="left"
                >
                  Upload Certificate
                </Button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CertificateGrid;