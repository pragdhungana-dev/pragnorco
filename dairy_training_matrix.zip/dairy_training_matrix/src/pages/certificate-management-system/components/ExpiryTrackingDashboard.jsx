import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ExpiryTrackingDashboard = ({ 
  onEmployeeSelect,
  onCertificateSelect,
  className = '' 
}) => {
  const [expiryData, setExpiryData] = useState({
    expiredCount: 0,
    expiringIn7Days: 0,
    expiringIn30Days: 0,
    expiringIn90Days: 0,
    upcomingRenewals: []
  });

  // Mock expiry tracking data
  const mockExpiryData = {
    expiredCount: 8,
    expiringIn7Days: 3,
    expiringIn30Days: 12,
    expiringIn90Days: 28,
    upcomingRenewals: [
      {
        id: 'REN001',
        employeeId: 'EMP001',
        employeeName: 'Sarah Johnson',
        department: 'Production Team',
        certificateType: 'First Aid & CPR',
        expiryDate: new Date('2024-08-30'),
        daysUntilExpiry: 6,
        priority: 'critical',
        renewalStatus: 'pending',
        lastNotified: new Date('2024-08-20')
      },
      {
        id: 'REN002',
        employeeId: 'EMP004',
        employeeName: 'David Thompson',
        department: 'Maintenance Team',
        certificateType: 'Equipment Safety',
        expiryDate: new Date('2024-09-05'),
        daysUntilExpiry: 12,
        priority: 'high',
        renewalStatus: 'scheduled',
        lastNotified: new Date('2024-08-18')
      },
      {
        id: 'REN003',
        employeeId: 'EMP002',
        employeeName: 'Michael Rodriguez',
        department: 'Quality Control',
        certificateType: 'HACCP Certification',
        expiryDate: new Date('2024-09-15'),
        daysUntilExpiry: 22,
        priority: 'medium',
        renewalStatus: 'in_progress',
        lastNotified: new Date('2024-08-15')
      },
      {
        id: 'REN004',
        employeeId: 'EMP006',
        employeeName: 'Robert Martinez',
        department: 'Machine Operators',
        certificateType: 'Forklift Operation',
        expiryDate: new Date('2024-10-01'),
        daysUntilExpiry: 38,
        priority: 'medium',
        renewalStatus: 'pending',
        lastNotified: new Date('2024-08-10')
      },
      {
        id: 'REN005',
        employeeId: 'EMP003',
        employeeName: 'Emily Chen',
        department: 'Laboratory Staff',
        certificateType: 'Laboratory Safety',
        expiryDate: new Date('2024-10-20'),
        daysUntilExpiry: 57,
        priority: 'low',
        renewalStatus: 'not_started',
        lastNotified: null
      }
    ]
  };

  useEffect(() => {
    setExpiryData(mockExpiryData);
  }, []);

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'critical': return 'text-error';
      case 'high': return 'text-warning';
      case 'medium': return 'text-accent';
      case 'low': return 'text-muted-foreground';
      default: return 'text-muted-foreground';
    }
  };

  const getPriorityBgColor = (priority) => {
    switch (priority) {
      case 'critical': return 'bg-error/10 border-error/20';
      case 'high': return 'bg-warning/10 border-warning/20';
      case 'medium': return 'bg-accent/10 border-accent/20';
      case 'low': return 'bg-muted/10 border-muted/20';
      default: return 'bg-muted/10 border-muted/20';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'text-success';
      case 'in_progress': return 'text-accent';
      case 'scheduled': return 'text-warning';
      case 'pending': return 'text-muted-foreground';
      case 'not_started': return 'text-muted-foreground';
      default: return 'text-muted-foreground';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed': return 'CheckCircle';
      case 'in_progress': return 'Clock';
      case 'scheduled': return 'Calendar';
      case 'pending': return 'AlertCircle';
      case 'not_started': return 'Circle';
      default: return 'Circle';
    }
  };

  const formatDate = (date) => {
    return new Date(date)?.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const handleSendReminder = (renewal) => {
    // Mock reminder functionality
    console.log('Sending reminder for:', renewal);
  };

  const handleScheduleRenewal = (renewal) => {
    // Mock scheduling functionality
    console.log('Scheduling renewal for:', renewal);
  };

  return (
    <div className={`bg-card border border-border rounded-lg shadow-industrial ${className}`}>
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-foreground">Expiry Tracking Dashboard</h3>
          <Button
            variant="outline"
            size="sm"
            iconName="RefreshCw"
            iconPosition="left"
          >
            Refresh
          </Button>
        </div>
      </div>
      {/* Summary Cards */}
      <div className="p-4 border-b border-border">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-3 bg-error/10 border border-error/20 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Expired</p>
                <p className="text-2xl font-bold text-error">{expiryData?.expiredCount}</p>
              </div>
              <Icon name="XCircle" size={24} className="text-error" />
            </div>
          </div>

          <div className="p-3 bg-warning/10 border border-warning/20 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">7 Days</p>
                <p className="text-2xl font-bold text-warning">{expiryData?.expiringIn7Days}</p>
              </div>
              <Icon name="AlertTriangle" size={24} className="text-warning" />
            </div>
          </div>

          <div className="p-3 bg-accent/10 border border-accent/20 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">30 Days</p>
                <p className="text-2xl font-bold text-accent">{expiryData?.expiringIn30Days}</p>
              </div>
              <Icon name="Clock" size={24} className="text-accent" />
            </div>
          </div>

          <div className="p-3 bg-muted/10 border border-muted/20 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">90 Days</p>
                <p className="text-2xl font-bold text-muted-foreground">{expiryData?.expiringIn90Days}</p>
              </div>
              <Icon name="Calendar" size={24} className="text-muted-foreground" />
            </div>
          </div>
        </div>
      </div>
      {/* Upcoming Renewals */}
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h4 className="font-medium text-foreground">Upcoming Renewals</h4>
          <Button
            variant="outline"
            size="sm"
            iconName="Plus"
            iconPosition="left"
          >
            Schedule Renewal
          </Button>
        </div>

        <div className="space-y-3 max-h-96 overflow-y-auto">
          {expiryData?.upcomingRenewals?.map((renewal) => (
            <div
              key={renewal?.id}
              className={`p-4 border rounded-lg ${getPriorityBgColor(renewal?.priority)}`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-1">
                    <h5 className="font-medium text-foreground">{renewal?.employeeName}</h5>
                    <span className={`text-xs px-2 py-1 rounded-full bg-background ${getPriorityColor(renewal?.priority)}`}>
                      {renewal?.priority?.toUpperCase()}
                    </span>
                  </div>
                  
                  <p className="text-sm text-muted-foreground mb-1">
                    {renewal?.department} • {renewal?.certificateType}
                  </p>
                  
                  <div className="flex items-center space-x-4 text-sm">
                    <div className="flex items-center space-x-1">
                      <Icon name="Calendar" size={14} className="text-muted-foreground" />
                      <span className="text-muted-foreground">
                        Expires: {formatDate(renewal?.expiryDate)}
                      </span>
                    </div>
                    
                    <div className={`flex items-center space-x-1 ${getPriorityColor(renewal?.priority)}`}>
                      <Icon name="Clock" size={14} />
                      <span className="font-medium">
                        {renewal?.daysUntilExpiry} days left
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <div className={`flex items-center space-x-1 ${getStatusColor(renewal?.renewalStatus)}`}>
                    <Icon name={getStatusIcon(renewal?.renewalStatus)} size={14} />
                    <span className="text-xs capitalize">
                      {renewal?.renewalStatus?.replace('_', ' ')}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="text-xs text-muted-foreground">
                  {renewal?.lastNotified ? (
                    `Last notified: ${formatDate(renewal?.lastNotified)}`
                  ) : (
                    'No notifications sent'
                  )}
                </div>

                <div className="flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onEmployeeSelect?.({ id: renewal?.employeeId, name: renewal?.employeeName })}
                    title="View Employee"
                  >
                    <Icon name="User" size={14} />
                  </Button>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleSendReminder(renewal)}
                    title="Send Reminder"
                  >
                    <Icon name="Mail" size={14} />
                  </Button>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleScheduleRenewal(renewal)}
                    title="Schedule Renewal"
                  >
                    <Icon name="Calendar" size={14} />
                  </Button>
                </div>
              </div>
            </div>
          ))}

          {expiryData?.upcomingRenewals?.length === 0 && (
            <div className="text-center py-8">
              <Icon name="CheckCircle" size={48} className="text-success mx-auto mb-3" />
              <p className="text-muted-foreground">No upcoming renewals</p>
              <p className="text-sm text-muted-foreground mt-1">
                All certificates are up to date
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ExpiryTrackingDashboard;