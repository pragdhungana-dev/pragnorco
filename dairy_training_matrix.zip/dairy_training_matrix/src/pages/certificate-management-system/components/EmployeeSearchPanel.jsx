import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';

const EmployeeSearchPanel = ({ 
  onEmployeeSelect, 
  selectedEmployee, 
  onFiltersChange,
  className = '' 
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [employees, setEmployees] = useState([]);
  const [filteredEmployees, setFilteredEmployees] = useState([]);

  // Mock employee data
  const mockEmployees = [
    {
      id: 'EMP001',
      name: 'Sarah Johnson',
      department: 'Production Team',
      position: 'Line Supervisor',
      email: 'sarah.johnson@dairyco.com',
      certificateCount: 12,
      expiringCount: 2,
      overdueCount: 0,
      status: 'compliant',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face'
    },
    {
      id: 'EMP002',
      name: 'Michael Rodriguez',
      department: 'Quality Control',
      position: 'QC Analyst',
      email: 'michael.rodriguez@dairyco.com',
      certificateCount: 8,
      expiringCount: 1,
      overdueCount: 1,
      status: 'warning',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face'
    },
    {
      id: 'EMP003',
      name: 'Emily Chen',
      department: 'Laboratory Staff',
      position: 'Lab Technician',
      email: 'emily.chen@dairyco.com',
      certificateCount: 15,
      expiringCount: 0,
      overdueCount: 0,
      status: 'compliant',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face'
    },
    {
      id: 'EMP004',
      name: 'David Thompson',
      department: 'Maintenance Team',
      position: 'Equipment Technician',
      email: 'david.thompson@dairyco.com',
      certificateCount: 6,
      expiringCount: 3,
      overdueCount: 2,
      status: 'critical',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face'
    },
    {
      id: 'EMP005',
      name: 'Lisa Wang',
      department: 'Safety Officers',
      position: 'Safety Coordinator',
      email: 'lisa.wang@dairyco.com',
      certificateCount: 18,
      expiringCount: 1,
      overdueCount: 0,
      status: 'compliant',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop&crop=face'
    },
    {
      id: 'EMP006',
      name: 'Robert Martinez',
      department: 'Machine Operators',
      position: 'Senior Operator',
      email: 'robert.martinez@dairyco.com',
      certificateCount: 9,
      expiringCount: 4,
      overdueCount: 1,
      status: 'warning',
      avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150&h=150&fit=crop&crop=face'
    }
  ];

  const departmentOptions = [
    { value: '', label: 'All Departments' },
    { value: 'Production Team', label: 'Production Team' },
    { value: 'Quality Control', label: 'Quality Control' },
    { value: 'Laboratory Staff', label: 'Laboratory Staff' },
    { value: 'Maintenance Team', label: 'Maintenance Team' },
    { value: 'Safety Officers', label: 'Safety Officers' },
    { value: 'Machine Operators', label: 'Machine Operators' },
    { value: 'Packaging Team', label: 'Packaging Team' },
    { value: 'Management', label: 'Management' }
  ];

  const statusOptions = [
    { value: '', label: 'All Status' },
    { value: 'compliant', label: 'Compliant' },
    { value: 'warning', label: 'Warning' },
    { value: 'critical', label: 'Critical' }
  ];

  useEffect(() => {
    setEmployees(mockEmployees);
    setFilteredEmployees(mockEmployees);
  }, []);

  useEffect(() => {
    let filtered = employees?.filter(employee => {
      const matchesSearch = employee?.name?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
                           employee?.id?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
                           employee?.email?.toLowerCase()?.includes(searchTerm?.toLowerCase());
      const matchesDepartment = !departmentFilter || employee?.department === departmentFilter;
      const matchesStatus = !statusFilter || employee?.status === statusFilter;
      
      return matchesSearch && matchesDepartment && matchesStatus;
    });

    setFilteredEmployees(filtered);
    onFiltersChange?.({
      searchTerm,
      departmentFilter,
      statusFilter,
      resultCount: filtered?.length
    });
  }, [searchTerm, departmentFilter, statusFilter, employees]);

  const getStatusColor = (status) => {
    switch (status) {
      case 'compliant': return 'text-success';
      case 'warning': return 'text-warning';
      case 'critical': return 'text-error';
      default: return 'text-muted-foreground';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'compliant': return 'CheckCircle';
      case 'warning': return 'AlertTriangle';
      case 'critical': return 'XCircle';
      default: return 'Circle';
    }
  };

  const handleClearFilters = () => {
    setSearchTerm('');
    setDepartmentFilter('');
    setStatusFilter('');
  };

  return (
    <div className={`bg-card border border-border rounded-lg shadow-industrial h-full flex flex-col ${className}`}>
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">Employee Search</h3>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleClearFilters}
            iconName="RotateCcw"
            iconPosition="left"
            className="text-muted-foreground"
          >
            Clear
          </Button>
        </div>

        {/* Search Input */}
        <Input
          type="search"
          placeholder="Search by name, ID, or email..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e?.target?.value)}
          className="mb-3"
        />

        {/* Filters */}
        <div className="space-y-3">
          <Select
            label="Department"
            options={departmentOptions}
            value={departmentFilter}
            onChange={setDepartmentFilter}
            placeholder="Select department"
          />

          <Select
            label="Compliance Status"
            options={statusOptions}
            value={statusFilter}
            onChange={setStatusFilter}
            placeholder="Select status"
          />
        </div>

        {/* Results Count */}
        <div className="mt-3 text-sm text-muted-foreground">
          {filteredEmployees?.length} of {employees?.length} employees
        </div>
      </div>
      {/* Employee List */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-2 space-y-2">
          {filteredEmployees?.map((employee) => (
            <div
              key={employee?.id}
              onClick={() => onEmployeeSelect(employee)}
              className={`
                p-3 rounded-lg border cursor-pointer transition-all hover:shadow-md
                ${selectedEmployee?.id === employee?.id 
                  ? 'border-primary bg-primary/5 shadow-md' 
                  : 'border-border hover:border-primary/50'
                }
              `}
            >
              <div className="flex items-start space-x-3">
                {/* Avatar */}
                <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center overflow-hidden flex-shrink-0">
                  {employee?.avatar ? (
                    <img 
                      src={employee?.avatar} 
                      alt={employee?.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <Icon name="User" size={20} className="text-muted-foreground" />
                  )}
                </div>

                {/* Employee Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="font-medium text-foreground truncate">
                      {employee?.name}
                    </h4>
                    <Icon 
                      name={getStatusIcon(employee?.status)} 
                      size={14} 
                      className={getStatusColor(employee?.status)}
                    />
                  </div>
                  
                  <p className="text-sm text-muted-foreground truncate mb-1">
                    {employee?.position}
                  </p>
                  
                  <p className="text-xs text-muted-foreground truncate mb-2">
                    {employee?.department}
                  </p>

                  {/* Certificate Stats */}
                  <div className="flex items-center space-x-3 text-xs">
                    <div className="flex items-center space-x-1">
                      <Icon name="Award" size={12} className="text-success" />
                      <span className="text-success font-medium">{employee?.certificateCount}</span>
                    </div>
                    
                    {employee?.expiringCount > 0 && (
                      <div className="flex items-center space-x-1">
                        <Icon name="Clock" size={12} className="text-warning" />
                        <span className="text-warning font-medium">{employee?.expiringCount}</span>
                      </div>
                    )}
                    
                    {employee?.overdueCount > 0 && (
                      <div className="flex items-center space-x-1">
                        <Icon name="AlertCircle" size={12} className="text-error" />
                        <span className="text-error font-medium">{employee?.overdueCount}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}

          {filteredEmployees?.length === 0 && (
            <div className="text-center py-8">
              <Icon name="Search" size={48} className="text-muted-foreground mx-auto mb-3" />
              <p className="text-muted-foreground">No employees found</p>
              <p className="text-sm text-muted-foreground mt-1">
                Try adjusting your search criteria
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default EmployeeSearchPanel;