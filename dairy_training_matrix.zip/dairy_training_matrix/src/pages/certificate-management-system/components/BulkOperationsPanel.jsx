import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import Input from '../../../components/ui/Input';

const BulkOperationsPanel = ({ 
  selectedCertificates = [],
  onBulkAction,
  onClearSelection,
  className = '' 
}) => {
  const [bulkAction, setBulkAction] = useState('');
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [dragOver, setDragOver] = useState(false);

  const bulkActionOptions = [
    { value: '', label: 'Select Action' },
    { value: 'verify', label: 'Verify Certificates' },
    { value: 'update_status', label: 'Update Status' },
    { value: 'update_expiry', label: 'Update Expiry Dates' },
    { value: 'download', label: 'Download Certificates' },
    { value: 'send_reminders', label: 'Send Renewal Reminders' },
    { value: 'archive', label: 'Archive Certificates' },
    { value: 'delete', label: 'Delete Certificates' }
  ];

  const statusOptions = [
    { value: 'valid', label: 'Valid' },
    { value: 'expiring', label: 'Expiring Soon' },
    { value: 'expired', label: 'Expired' },
    { value: 'revoked', label: 'Revoked' }
  ];

  const handleBulkAction = async () => {
    if (!bulkAction || selectedCertificates?.length === 0) return;

    setIsProcessing(true);
    
    // Simulate processing
    for (let i = 0; i <= 100; i += 10) {
      setUploadProgress(i);
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    onBulkAction?.(bulkAction, selectedCertificates);
    setBulkAction('');
    setUploadProgress(0);
    setIsProcessing(false);
  };

  const handleDragOver = (e) => {
    e?.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = (e) => {
    e?.preventDefault();
    setDragOver(false);
  };

  const handleDrop = (e) => {
    e?.preventDefault();
    setDragOver(false);
    
    const files = Array.from(e?.dataTransfer?.files);
    handleFileUpload(files);
  };

  const handleFileUpload = async (files) => {
    setIsProcessing(true);
    
    // Simulate file upload
    for (let i = 0; i <= 100; i += 5) {
      setUploadProgress(i);
      await new Promise(resolve => setTimeout(resolve, 50));
    }

    console.log('Uploading files:', files);
    setUploadProgress(0);
    setIsProcessing(false);
  };

  const handleFileInputChange = (e) => {
    const files = Array.from(e?.target?.files);
    if (files?.length > 0) {
      handleFileUpload(files);
    }
  };

  return (
    <div className={`bg-card border border-border rounded-lg shadow-industrial ${className}`}>
      {/* Header */}
      <div className="p-4 border-b border-border">
        <h3 className="text-lg font-semibold text-foreground">Bulk Operations</h3>
      </div>
      <div className="p-4 space-y-6">
        {/* File Upload Section */}
        <div>
          <h4 className="font-medium text-foreground mb-3">Upload Certificates</h4>
          
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`
              border-2 border-dashed rounded-lg p-6 text-center transition-colors
              ${dragOver 
                ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50'
              }
            `}
          >
            <Icon name="Upload" size={32} className="text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground mb-2">
              Drag and drop certificate files here, or click to browse
            </p>
            <p className="text-sm text-muted-foreground mb-4">
              Supports PDF, JPG, PNG files up to 10MB each
            </p>
            
            <input
              type="file"
              multiple
              accept=".pdf,.jpg,.jpeg,.png"
              onChange={handleFileInputChange}
              className="hidden"
              id="certificate-upload"
            />
            
            <Button
              variant="outline"
              onClick={() => document.getElementById('certificate-upload')?.click()}
              iconName="FolderOpen"
              iconPosition="left"
            >
              Browse Files
            </Button>
          </div>

          {/* Upload Progress */}
          {isProcessing && uploadProgress > 0 && (
            <div className="mt-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Uploading...</span>
                <span className="text-sm text-muted-foreground">{uploadProgress}%</span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div 
                  className="bg-primary h-2 rounded-full transition-all duration-300"
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Bulk Actions Section */}
        {selectedCertificates?.length > 0 && (
          <div>
            <h4 className="font-medium text-foreground mb-3">
              Bulk Actions ({selectedCertificates?.length} selected)
            </h4>
            
            <div className="space-y-3">
              <Select
                label="Action"
                options={bulkActionOptions}
                value={bulkAction}
                onChange={setBulkAction}
                placeholder="Select bulk action"
              />

              {bulkAction === 'update_status' && (
                <Select
                  label="New Status"
                  options={statusOptions}
                  placeholder="Select new status"
                />
              )}

              {bulkAction === 'update_expiry' && (
                <Input
                  label="New Expiry Date"
                  type="date"
                  placeholder="Select new expiry date"
                />
              )}

              <div className="flex items-center space-x-2">
                <Button
                  variant="default"
                  onClick={handleBulkAction}
                  disabled={!bulkAction || isProcessing}
                  loading={isProcessing}
                  iconName="Play"
                  iconPosition="left"
                  className="flex-1"
                >
                  Execute Action
                </Button>
                
                <Button
                  variant="outline"
                  onClick={onClearSelection}
                  iconName="X"
                  iconPosition="left"
                >
                  Clear Selection
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Quick Actions */}
        <div>
          <h4 className="font-medium text-foreground mb-3">Quick Actions</h4>
          
          <div className="grid grid-cols-1 gap-2">
            <Button
              variant="outline"
              iconName="Download"
              iconPosition="left"
              className="justify-start"
            >
              Export All Certificates
            </Button>
            
            <Button
              variant="outline"
              iconName="FileText"
              iconPosition="left"
              className="justify-start"
            >
              Generate Compliance Report
            </Button>
            
            <Button
              variant="outline"
              iconName="Mail"
              iconPosition="left"
              className="justify-start"
            >
              Send Expiry Notifications
            </Button>
            
            <Button
              variant="outline"
              iconName="RefreshCw"
              iconPosition="left"
              className="justify-start"
            >
              Verify All Certificates
            </Button>
          </div>
        </div>

        {/* Recent Operations */}
        <div>
          <h4 className="font-medium text-foreground mb-3">Recent Operations</h4>
          
          <div className="space-y-2 text-sm">
            <div className="flex items-center justify-between p-2 bg-muted/30 rounded">
              <div className="flex items-center space-x-2">
                <Icon name="CheckCircle" size={14} className="text-success" />
                <span>Verified 15 certificates</span>
              </div>
              <span className="text-muted-foreground">2 min ago</span>
            </div>
            
            <div className="flex items-center justify-between p-2 bg-muted/30 rounded">
              <div className="flex items-center space-x-2">
                <Icon name="Upload" size={14} className="text-accent" />
                <span>Uploaded 8 certificates</span>
              </div>
              <span className="text-muted-foreground">1 hour ago</span>
            </div>
            
            <div className="flex items-center justify-between p-2 bg-muted/30 rounded">
              <div className="flex items-center space-x-2">
                <Icon name="Mail" size={14} className="text-warning" />
                <span>Sent 23 renewal reminders</span>
              </div>
              <span className="text-muted-foreground">3 hours ago</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BulkOperationsPanel;