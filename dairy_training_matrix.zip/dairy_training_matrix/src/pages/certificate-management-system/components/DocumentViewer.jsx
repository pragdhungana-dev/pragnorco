import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const DocumentViewer = ({ 
  selectedCertificate, 
  onCertificateUpdate,
  className = '' 
}) => {
  const [viewMode, setViewMode] = useState('preview');
  const [zoomLevel, setZoomLevel] = useState(100);
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({});
  const [verificationNotes, setVerificationNotes] = useState('');

  const viewModeOptions = [
    { value: 'preview', label: 'Preview' },
    { value: 'details', label: 'Details' },
    { value: 'history', label: 'History' }
  ];

  const statusOptions = [
    { value: 'valid', label: 'Valid' },
    { value: 'expiring', label: 'Expiring Soon' },
    { value: 'expired', label: 'Expired' },
    { value: 'revoked', label: 'Revoked' }
  ];

  const verificationOptions = [
    { value: 'verified', label: 'Verified' },
    { value: 'pending', label: 'Pending' },
    { value: 'failed', label: 'Failed' }
  ];

  // Mock audit history
  const auditHistory = [
    {
      id: 1,
      action: 'Certificate Uploaded',
      user: 'Training Coordinator',
      timestamp: new Date('2024-01-16T10:30:00'),
      details: 'Initial certificate upload'
    },
    {
      id: 2,
      action: 'Verification Completed',
      user: 'Safety Officer',
      timestamp: new Date('2024-01-16T14:15:00'),
      details: 'Certificate verified against issuing authority database'
    },
    {
      id: 3,
      action: 'Status Updated',
      user: 'System',
      timestamp: new Date('2024-08-20T09:00:00'),
      details: 'Status automatically updated to "expiring" - 30 days until expiry'
    }
  ];

  useEffect(() => {
    if (selectedCertificate) {
      setEditData({
        trainingType: selectedCertificate?.trainingType,
        category: selectedCertificate?.category,
        issueDate: selectedCertificate?.issueDate?.toISOString()?.split('T')?.[0],
        expiryDate: selectedCertificate?.expiryDate?.toISOString()?.split('T')?.[0],
        issuingAuthority: selectedCertificate?.issuingAuthority,
        certificateNumber: selectedCertificate?.certificateNumber,
        status: selectedCertificate?.status,
        verificationStatus: selectedCertificate?.verificationStatus
      });
      setVerificationNotes('');
      setIsEditing(false);
      setViewMode('preview');
    }
  }, [selectedCertificate]);

  const handleSave = () => {
    if (onCertificateUpdate) {
      onCertificateUpdate({
        ...selectedCertificate,
        ...editData,
        issueDate: new Date(editData.issueDate),
        expiryDate: new Date(editData.expiryDate),
        verificationNotes: verificationNotes
      });
    }
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditData({
      trainingType: selectedCertificate?.trainingType,
      category: selectedCertificate?.category,
      issueDate: selectedCertificate?.issueDate?.toISOString()?.split('T')?.[0],
      expiryDate: selectedCertificate?.expiryDate?.toISOString()?.split('T')?.[0],
      issuingAuthority: selectedCertificate?.issuingAuthority,
      certificateNumber: selectedCertificate?.certificateNumber,
      status: selectedCertificate?.status,
      verificationStatus: selectedCertificate?.verificationStatus
    });
    setVerificationNotes('');
    setIsEditing(false);
  };

  const formatDate = (date) => {
    return new Date(date)?.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatDateTime = (date) => {
    return new Date(date)?.toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'valid': return 'text-success';
      case 'expiring': return 'text-warning';
      case 'expired': return 'text-error';
      case 'revoked': return 'text-error';
      default: return 'text-muted-foreground';
    }
  };

  const getVerificationColor = (status) => {
    switch (status) {
      case 'verified': return 'text-success';
      case 'pending': return 'text-warning';
      case 'failed': return 'text-error';
      default: return 'text-muted-foreground';
    }
  };

  if (!selectedCertificate) {
    return (
      <div className={`bg-card border border-border rounded-lg shadow-industrial h-full flex items-center justify-center ${className}`}>
        <div className="text-center">
          <Icon name="FileText" size={48} className="text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">Select a certificate to view details</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-card border border-border rounded-lg shadow-industrial h-full flex flex-col ${className}`}>
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">Certificate Details</h3>
          
          <div className="flex items-center space-x-2">
            <Select
              options={viewModeOptions}
              value={viewMode}
              onChange={setViewMode}
              className="w-32"
            />
            
            {!isEditing ? (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsEditing(true)}
                iconName="Edit"
                iconPosition="left"
              >
                Edit
              </Button>
            ) : (
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleCancel}
                >
                  Cancel
                </Button>
                <Button
                  variant="default"
                  size="sm"
                  onClick={handleSave}
                  iconName="Save"
                  iconPosition="left"
                >
                  Save
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* Certificate Title */}
        <div className="flex items-start justify-between">
          <div>
            <h4 className="font-medium text-foreground">{selectedCertificate?.trainingType}</h4>
            <p className="text-sm text-muted-foreground">{selectedCertificate?.employeeName}</p>
          </div>
          
          <div className="text-right">
            <div className={`text-sm font-medium ${getStatusColor(selectedCertificate?.status)}`}>
              {selectedCertificate?.status?.charAt(0)?.toUpperCase() + selectedCertificate?.status?.slice(1)}
            </div>
            <div className={`text-xs ${getVerificationColor(selectedCertificate?.verificationStatus)}`}>
              {selectedCertificate?.verificationStatus?.charAt(0)?.toUpperCase() + selectedCertificate?.verificationStatus?.slice(1)}
            </div>
          </div>
        </div>
      </div>
      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4">
        {viewMode === 'preview' && (
          <div className="space-y-6">
            {/* Document Preview */}
            <div className="bg-muted/30 border border-border rounded-lg p-4 text-center">
              <Icon name="FileText" size={64} className="text-muted-foreground mx-auto mb-3" />
              <p className="text-muted-foreground mb-3">Certificate Document Preview</p>
              <div className="flex items-center justify-center space-x-2 mb-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setZoomLevel(Math.max(50, zoomLevel - 25))}
                  iconName="ZoomOut"
                />
                <span className="text-sm text-muted-foreground">{zoomLevel}%</span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setZoomLevel(Math.min(200, zoomLevel + 25))}
                  iconName="ZoomIn"
                />
              </div>
              <div className="flex justify-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  iconName="Download"
                  iconPosition="left"
                >
                  Download
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  iconName="Printer"
                  iconPosition="left"
                >
                  Print
                </Button>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-2 gap-3">
              <Button
                variant="outline"
                iconName="Shield"
                iconPosition="left"
                className="justify-start"
              >
                Verify Certificate
              </Button>
              <Button
                variant="outline"
                iconName="RefreshCw"
                iconPosition="left"
                className="justify-start"
              >
                Renew Certificate
              </Button>
            </div>
          </div>
        )}

        {viewMode === 'details' && (
          <div className="space-y-6">
            {/* Basic Information */}
            <div>
              <h5 className="font-medium text-foreground mb-3">Certificate Information</h5>
              <div className="grid grid-cols-1 gap-4">
                {isEditing ? (
                  <>
                    <Input
                      label="Training Type"
                      value={editData?.trainingType}
                      onChange={(e) => setEditData({...editData, trainingType: e?.target?.value})}
                    />
                    <Input
                      label="Category"
                      value={editData?.category}
                      onChange={(e) => setEditData({...editData, category: e?.target?.value})}
                    />
                    <Input
                      label="Certificate Number"
                      value={editData?.certificateNumber}
                      onChange={(e) => setEditData({...editData, certificateNumber: e?.target?.value})}
                    />
                    <Input
                      label="Issuing Authority"
                      value={editData?.issuingAuthority}
                      onChange={(e) => setEditData({...editData, issuingAuthority: e?.target?.value})}
                    />
                    <Input
                      label="Issue Date"
                      type="date"
                      value={editData?.issueDate}
                      onChange={(e) => setEditData({...editData, issueDate: e?.target?.value})}
                    />
                    <Input
                      label="Expiry Date"
                      type="date"
                      value={editData?.expiryDate}
                      onChange={(e) => setEditData({...editData, expiryDate: e?.target?.value})}
                    />
                    <Select
                      label="Status"
                      options={statusOptions}
                      value={editData?.status}
                      onChange={(value) => setEditData({...editData, status: value})}
                    />
                    <Select
                      label="Verification Status"
                      options={verificationOptions}
                      value={editData?.verificationStatus}
                      onChange={(value) => setEditData({...editData, verificationStatus: value})}
                    />
                  </>
                ) : (
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Certificate Number:</span>
                      <span className="text-sm font-medium">{selectedCertificate?.certificateNumber}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Issuing Authority:</span>
                      <span className="text-sm font-medium">{selectedCertificate?.issuingAuthority}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Issue Date:</span>
                      <span className="text-sm font-medium">{formatDate(selectedCertificate?.issueDate)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Expiry Date:</span>
                      <span className="text-sm font-medium">{formatDate(selectedCertificate?.expiryDate)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Upload Date:</span>
                      <span className="text-sm font-medium">{formatDate(selectedCertificate?.uploadDate)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Uploaded By:</span>
                      <span className="text-sm font-medium">{selectedCertificate?.uploadedBy}</span>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Verification Notes */}
            {isEditing && (
              <div>
                <h5 className="font-medium text-foreground mb-3">Verification Notes</h5>
                <textarea
                  value={verificationNotes}
                  onChange={(e) => setVerificationNotes(e?.target?.value)}
                  placeholder="Add verification notes..."
                  className="w-full h-24 p-3 border border-border rounded-lg resize-none"
                />
              </div>
            )}

            {/* Status Indicators */}
            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 bg-muted/30 rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <Icon name="Shield" size={16} className={getStatusColor(selectedCertificate?.status)} />
                  <span className="text-sm font-medium">Certificate Status</span>
                </div>
                <span className={`text-sm ${getStatusColor(selectedCertificate?.status)}`}>
                  {selectedCertificate?.status?.charAt(0)?.toUpperCase() + selectedCertificate?.status?.slice(1)}
                </span>
              </div>
              
              <div className="p-3 bg-muted/30 rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <Icon name="CheckCircle" size={16} className={getVerificationColor(selectedCertificate?.verificationStatus)} />
                  <span className="text-sm font-medium">Verification</span>
                </div>
                <span className={`text-sm ${getVerificationColor(selectedCertificate?.verificationStatus)}`}>
                  {selectedCertificate?.verificationStatus?.charAt(0)?.toUpperCase() + selectedCertificate?.verificationStatus?.slice(1)}
                </span>
              </div>
            </div>
          </div>
        )}

        {viewMode === 'history' && (
          <div className="space-y-4">
            <h5 className="font-medium text-foreground">Audit History</h5>
            
            <div className="space-y-3">
              {auditHistory?.map((entry) => (
                <div key={entry?.id} className="p-3 border border-border rounded-lg">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <Icon name="Clock" size={14} className="text-muted-foreground" />
                      <span className="text-sm font-medium text-foreground">{entry?.action}</span>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {formatDateTime(entry?.timestamp)}
                    </span>
                  </div>
                  
                  <p className="text-sm text-muted-foreground mb-1">{entry?.details}</p>
                  <p className="text-xs text-muted-foreground">by {entry?.user}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DocumentViewer;