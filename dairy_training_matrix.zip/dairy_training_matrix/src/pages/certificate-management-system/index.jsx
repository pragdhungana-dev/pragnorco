import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import RoleBasedSidebar from '../../components/ui/RoleBasedSidebar';
import EmployeeSearchPanel from './components/EmployeeSearchPanel';
import CertificateGrid from './components/CertificateGrid';
import DocumentViewer from './components/DocumentViewer';
import ExpiryTrackingDashboard from './components/ExpiryTrackingDashboard';
import BulkOperationsPanel from './components/BulkOperationsPanel';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const CertificateManagementSystem = () => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [selectedCertificate, setSelectedCertificate] = useState(null);
  const [selectedCertificates, setSelectedCertificates] = useState([]);
  const [viewMode, setViewMode] = useState('grid'); // 'grid', 'dashboard', 'bulk'
  const [searchFilters, setSearchFilters] = useState({});

  // Mock user role - in real app, this would come from authentication
  const userRole = 'training_coordinator';

  useEffect(() => {
    // Set page title
    document.title = 'Certificate Management System - Dairy Training Matrix';
  }, []);

  const handleEmployeeSelect = (employee) => {
    setSelectedEmployee(employee);
    setSelectedCertificate(null);
  };

  const handleCertificateSelect = (certificate) => {
    setSelectedCertificate(certificate);
  };

  const handleCertificateUpdate = (updatedCertificate) => {
    console.log('Certificate updated:', updatedCertificate);
    // In real app, this would update the certificate in the backend
  };

  const handleBulkAction = (action, certificateIds) => {
    console.log('Bulk action:', action, 'on certificates:', certificateIds);
    setSelectedCertificates([]);
    // In real app, this would perform the bulk action
  };

  const handleFiltersChange = (filters) => {
    setSearchFilters(filters);
  };

  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const viewModeOptions = [
    { id: 'grid', label: 'Certificate Grid', icon: 'Grid3X3' },
    { id: 'dashboard', label: 'Expiry Dashboard', icon: 'BarChart3' },
    { id: 'bulk', label: 'Bulk Operations', icon: 'Settings' }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Certificate Management System - Dairy Training Matrix</title>
        <meta name="description" content="Centralized training certificate storage, validation, and lifecycle management for dairy facility operations" />
      </Helmet>
      {/* Header */}
      <Header 
        onMenuToggle={toggleMobileMenu}
        isMenuOpen={isMobileMenuOpen}
      />
      {/* Sidebar */}
      <RoleBasedSidebar
        isCollapsed={isSidebarCollapsed}
        onToggleCollapse={toggleSidebar}
        userRole={userRole}
        className="hidden lg:block"
      />
      {/* Main Content */}
      <main 
        className={`
          pt-16 transition-all duration-200
          ${isSidebarCollapsed ? 'lg:ml-16' : 'lg:ml-60'}
        `}
      >
        <div className="p-4 lg:p-6">
          {/* Page Header */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h1 className="text-2xl font-bold text-foreground">Certificate Management System</h1>
                <p className="text-muted-foreground">
                  Centralized certificate storage, validation, and lifecycle management
                </p>
              </div>

              {/* View Mode Toggle */}
              <div className="flex items-center space-x-2">
                {viewModeOptions?.map((option) => (
                  <Button
                    key={option?.id}
                    variant={viewMode === option?.id ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setViewMode(option?.id)}
                    iconName={option?.icon}
                    iconPosition="left"
                    className="hidden md:flex"
                  >
                    {option?.label}
                  </Button>
                ))}

                {/* Mobile View Mode Selector */}
                <div className="md:hidden">
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="MoreHorizontal"
                  >
                    View
                  </Button>
                </div>
              </div>
            </div>

            {/* Stats Summary */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-3 bg-card border border-border rounded-lg">
                <div className="flex items-center space-x-2">
                  <Icon name="Award" size={16} className="text-success" />
                  <span className="text-sm text-muted-foreground">Total Certificates</span>
                </div>
                <p className="text-xl font-bold text-foreground mt-1">1,247</p>
              </div>

              <div className="p-3 bg-card border border-border rounded-lg">
                <div className="flex items-center space-x-2">
                  <Icon name="CheckCircle" size={16} className="text-success" />
                  <span className="text-sm text-muted-foreground">Valid</span>
                </div>
                <p className="text-xl font-bold text-success mt-1">1,156</p>
              </div>

              <div className="p-3 bg-card border border-border rounded-lg">
                <div className="flex items-center space-x-2">
                  <Icon name="Clock" size={16} className="text-warning" />
                  <span className="text-sm text-muted-foreground">Expiring Soon</span>
                </div>
                <p className="text-xl font-bold text-warning mt-1">83</p>
              </div>

              <div className="p-3 bg-card border border-border rounded-lg">
                <div className="flex items-center space-x-2">
                  <Icon name="XCircle" size={16} className="text-error" />
                  <span className="text-sm text-muted-foreground">Expired</span>
                </div>
                <p className="text-xl font-bold text-error mt-1">8</p>
              </div>
            </div>
          </div>

          {/* Content Layout */}
          {viewMode === 'grid' && (
            <div className="grid grid-cols-12 gap-6 h-[calc(100vh-280px)]">
              {/* Employee Search Panel - 20% */}
              <div className="col-span-12 lg:col-span-3">
                <EmployeeSearchPanel
                  onEmployeeSelect={handleEmployeeSelect}
                  selectedEmployee={selectedEmployee}
                  onFiltersChange={handleFiltersChange}
                  className="h-full"
                />
              </div>

              {/* Certificate Grid - 50% */}
              <div className="col-span-12 lg:col-span-5">
                <CertificateGrid
                  selectedEmployee={selectedEmployee}
                  onCertificateSelect={handleCertificateSelect}
                  selectedCertificate={selectedCertificate}
                  onBulkAction={handleBulkAction}
                  className="h-full"
                />
              </div>

              {/* Document Viewer - 30% */}
              <div className="col-span-12 lg:col-span-4">
                <DocumentViewer
                  selectedCertificate={selectedCertificate}
                  onCertificateUpdate={handleCertificateUpdate}
                  className="h-full"
                />
              </div>
            </div>
          )}

          {viewMode === 'dashboard' && (
            <div className="grid grid-cols-12 gap-6 h-[calc(100vh-280px)]">
              {/* Expiry Tracking Dashboard - Full Width */}
              <div className="col-span-12">
                <ExpiryTrackingDashboard
                  onEmployeeSelect={handleEmployeeSelect}
                  onCertificateSelect={handleCertificateSelect}
                  className="h-full"
                />
              </div>
            </div>
          )}

          {viewMode === 'bulk' && (
            <div className="grid grid-cols-12 gap-6 h-[calc(100vh-280px)]">
              {/* Bulk Operations Panel - Left Side */}
              <div className="col-span-12 lg:col-span-4">
                <BulkOperationsPanel
                  selectedCertificates={selectedCertificates}
                  onBulkAction={handleBulkAction}
                  onClearSelection={() => setSelectedCertificates([])}
                  className="h-full"
                />
              </div>

              {/* Certificate Grid - Right Side */}
              <div className="col-span-12 lg:col-span-8">
                <CertificateGrid
                  selectedEmployee={selectedEmployee}
                  onCertificateSelect={handleCertificateSelect}
                  selectedCertificate={selectedCertificate}
                  onBulkAction={handleBulkAction}
                  className="h-full"
                />
              </div>
            </div>
          )}
        </div>
      </main>
      {/* Mobile Sidebar Overlay */}
      {isMobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-50 bg-background/80 backdrop-blur-sm">
          <RoleBasedSidebar
            isCollapsed={false}
            onToggleCollapse={() => setIsMobileMenuOpen(false)}
            userRole={userRole}
            className="w-64"
          />
        </div>
      )}
    </div>
  );
};

export default CertificateManagementSystem;