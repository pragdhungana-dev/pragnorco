import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import RoleBasedSidebar from '../../components/ui/RoleBasedSidebar';
import CourseCatalogTree from './components/CourseCatalogTree';
import CourseGrid from './components/CourseGrid';
import BulkEditModal from './components/BulkEditModal';
import CourseFilters from './components/CourseFilters';
import ProviderSyncStatus from './components/ProviderSyncStatus';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const TrainingCourseManagement = () => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [selectedCourses, setSelectedCourses] = useState([]);
  const [expandedCategories, setExpandedCategories] = useState(['safety', 'haccp']);
  const [bulkEditModal, setBulkEditModal] = useState({ isOpen: false, action: 'edit' });
  const [sortConfig, setSortConfig] = useState({ key: 'title', direction: 'asc' });
  const [filters, setFilters] = useState({});
  const [courses, setCourses] = useState([]);
  const [categories, setCategories] = useState([]);

  // Mock data
  useEffect(() => {
    const mockCategories = [
      {
        id: 'safety',
        name: 'Dairy Safety & Hygiene',
        type: 'safety',
        hasUpdates: true,
        syncStatus: 'connected',
        courses: [
          {
            id: 'safety-001',
            title: 'Personal Hygiene in Dairy Processing',
            duration: '2 hours',
            cost: 150,
            isRequired: true,
            hasPrerequisites: false,
            expiresIn30Days: false
          },
          {
            id: 'safety-002',
            title: 'Sanitation Standard Operating Procedures',
            duration: '4 hours',
            cost: 250,
            isRequired: true,
            hasPrerequisites: true,
            expiresIn30Days: true
          }
        ]
      },
      {
        id: 'haccp',
        name: 'HACCP & Food Safety',
        type: 'haccp',
        hasUpdates: false,
        syncStatus: 'connected',
        courses: [
          {
            id: 'haccp-001',
            title: 'HACCP Principles and Implementation',
            duration: '8 hours',
            cost: 450,
            isRequired: true,
            hasPrerequisites: false,
            expiresIn30Days: false
          },
          {
            id: 'haccp-002',
            title: 'Critical Control Points Management',
            duration: '6 hours',
            cost: 350,
            isRequired: true,
            hasPrerequisites: true,
            expiresIn30Days: false
          }
        ]
      },
      {
        id: 'equipment',
        name: 'Equipment Operation & Maintenance',
        type: 'equipment',
        hasUpdates: false,
        syncStatus: 'warning',
        courses: [
          {
            id: 'equipment-001',
            title: 'Pasteurization Equipment Operation',
            duration: '6 hours',
            cost: 400,
            isRequired: true,
            hasPrerequisites: true,
            expiresIn30Days: false
          },
          {
            id: 'equipment-002',
            title: 'Packaging Line Maintenance',
            duration: '4 hours',
            cost: 300,
            isRequired: false,
            hasPrerequisites: false,
            expiresIn30Days: true
          }
        ]
      },
      {
        id: 'quality',
        name: 'Quality Control Procedures',
        type: 'quality',
        hasUpdates: true,
        syncStatus: 'connected',
        courses: [
          {
            id: 'quality-001',
            title: 'Microbiological Testing Procedures',
            duration: '5 hours',
            cost: 380,
            isRequired: true,
            hasPrerequisites: false,
            expiresIn30Days: false
          }
        ]
      },
      {
        id: 'emergency',
        name: 'Emergency Response & First Aid',
        type: 'emergency',
        hasUpdates: false,
        syncStatus: 'error',
        courses: [
          {
            id: 'emergency-001',
            title: 'Emergency Response Procedures',
            duration: '3 hours',
            cost: 200,
            isRequired: true,
            hasPrerequisites: false,
            expiresIn30Days: true
          }
        ]
      }
    ];

    const mockCourses = [
      {
        id: 'safety-001',
        title: 'Personal Hygiene in Dairy Processing',
        description: 'Comprehensive training on personal hygiene standards required for dairy processing environments, covering hand washing, protective clothing, and contamination prevention.',
        provider: 'dairy_safety_institute',
        providerName: 'Dairy Safety Institute',
        duration: '2 hours',
        cost: 150,
        validityPeriod: '12 months',
        compliance: 'fda',
        complianceLabel: 'FDA Required',
        isActive: true,
        category: 'safety',
        lastSync: new Date(Date.now() - 10 * 60 * 1000),
        createdAt: new Date('2024-01-15'),
        updatedAt: new Date('2024-08-20')
      },
      {
        id: 'safety-002',
        title: 'Sanitation Standard Operating Procedures',
        description: 'Detailed training on sanitation SOPs including cleaning schedules, chemical handling, and verification procedures for dairy processing facilities.',
        provider: 'dairy_safety_institute',
        providerName: 'Dairy Safety Institute',
        duration: '4 hours',
        cost: 250,
        validityPeriod: '12 months',
        compliance: 'fda',
        complianceLabel: 'FDA Required',
        isActive: true,
        category: 'safety',
        lastSync: new Date(Date.now() - 5 * 60 * 1000),
        createdAt: new Date('2024-02-01'),
        updatedAt: new Date('2024-08-22')
      },
      {
        id: 'haccp-001',
        title: 'HACCP Principles and Implementation',
        description: 'Comprehensive course covering the seven HACCP principles and their practical implementation in dairy manufacturing operations.',
        provider: 'haccp_training_corp',
        providerName: 'HACCP Training Corp',
        duration: '8 hours',
        cost: 450,
        validityPeriod: '24 months',
        compliance: 'haccp',
        complianceLabel: 'HACCP Certified',
        isActive: true,
        category: 'haccp',
        lastSync: new Date(Date.now() - 15 * 60 * 1000),
        createdAt: new Date('2024-01-10'),
        updatedAt: new Date('2024-08-18')
      },
      {
        id: 'haccp-002',
        title: 'Critical Control Points Management',
        description: 'Advanced training on identifying, monitoring, and managing critical control points in dairy processing operations.',
        provider: 'haccp_training_corp',
        providerName: 'HACCP Training Corp',
        duration: '6 hours',
        cost: 350,
        validityPeriod: '18 months',
        compliance: 'haccp',
        complianceLabel: 'HACCP Certified',
        isActive: true,
        category: 'haccp',
        lastSync: new Date(Date.now() - 20 * 60 * 1000),
        createdAt: new Date('2024-02-15'),
        updatedAt: new Date('2024-08-19')
      },
      {
        id: 'equipment-001',
        title: 'Pasteurization Equipment Operation',
        description: 'Specialized training on operating and monitoring pasteurization equipment, including temperature controls and safety procedures.',
        provider: 'equipment_masters',
        providerName: 'Equipment Masters',
        duration: '6 hours',
        cost: 400,
        validityPeriod: '12 months',
        compliance: 'internal',
        complianceLabel: 'Internal Policy',
        isActive: true,
        category: 'equipment',
        lastSync: new Date(Date.now() - 30 * 60 * 1000),
        createdAt: new Date('2024-03-01'),
        updatedAt: new Date('2024-08-21')
      },
      {
        id: 'equipment-002',
        title: 'Packaging Line Maintenance',
        description: 'Training on routine maintenance procedures for packaging equipment, including troubleshooting and preventive maintenance.',
        provider: 'equipment_masters',
        providerName: 'Equipment Masters',
        duration: '4 hours',
        cost: 300,
        validityPeriod: '12 months',
        compliance: 'internal',
        complianceLabel: 'Internal Policy',
        isActive: false,
        category: 'equipment',
        lastSync: new Date(Date.now() - 45 * 60 * 1000),
        createdAt: new Date('2024-03-15'),
        updatedAt: new Date('2024-08-10')
      },
      {
        id: 'quality-001',
        title: 'Microbiological Testing Procedures',
        description: 'Laboratory training on microbiological testing methods, sample collection, and result interpretation for dairy products.',
        provider: 'quality_assurance_academy',
        providerName: 'Quality Assurance Academy',
        duration: '5 hours',
        cost: 380,
        validityPeriod: '18 months',
        compliance: 'usda',
        complianceLabel: 'USDA Required',
        isActive: true,
        category: 'quality',
        lastSync: new Date(Date.now() - 8 * 60 * 1000),
        createdAt: new Date('2024-04-01'),
        updatedAt: new Date('2024-08-23')
      },
      {
        id: 'emergency-001',
        title: 'Emergency Response Procedures',
        description: 'Training on emergency response protocols, evacuation procedures, and first aid specific to dairy processing environments.',
        provider: 'safety_first_training',
        providerName: 'Safety First Training',
        duration: '3 hours',
        cost: 200,
        validityPeriod: '12 months',
        compliance: 'osha',
        complianceLabel: 'OSHA Required',
        isActive: true,
        category: 'emergency',
        lastSync: new Date(Date.now() - 2 * 60 * 60 * 1000),
        createdAt: new Date('2024-05-01'),
        updatedAt: new Date('2024-08-15')
      }
    ];

    setCategories(mockCategories);
    setCourses(mockCourses);
    setSelectedCategory(mockCategories?.[0]);
  }, []);

  const handleCategorySelect = (category, course = null) => {
    setSelectedCategory(category);
    if (course) {
      // Focus on specific course if provided
      setSelectedCourses([course?.id]);
    }
  };

  const handleCategoryToggle = (categoryId) => {
    setExpandedCategories(prev => 
      prev?.includes(categoryId) 
        ? prev?.filter(id => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  const handleCourseEdit = (courseId, updates) => {
    setCourses(prev => prev?.map(course => 
      course?.id === courseId ? { ...course, ...updates } : course
    ));
  };

  const handleBulkAction = (action, courseIds = selectedCourses) => {
    switch (action) {
      case 'edit':
        setBulkEditModal({ isOpen: true, action: 'edit' });
        break;
      case 'duplicate':
        setBulkEditModal({ isOpen: true, action: 'duplicate' });
        break;
      case 'delete':
        setBulkEditModal({ isOpen: true, action: 'delete' });
        break;
      case 'add':
        // Handle add new course
        console.log('Add new course');
        break;
      case 'import':
        // Handle import courses
        console.log('Import courses');
        break;
      case 'export':
        // Handle export courses
        console.log('Export courses');
        break;
      case 'refresh':
        // Handle refresh/sync
        console.log('Refresh all courses');
        break;
      default:
        break;
    }
  };

  const handleSort = (key) => {
    setSortConfig(prev => ({
      key,
      direction: prev?.key === key && prev?.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const handleBulkEditSave = (courseIds, updates) => {
    setCourses(prev => prev?.map(course => 
      courseIds?.includes(course?.id) ? { ...course, ...updates } : course
    ));
    setSelectedCourses([]);
  };

  // Filter and sort courses
  const filteredCourses = courses?.filter(course => {
    if (selectedCategory && course?.category !== selectedCategory?.id) return false;
    
    // Apply filters
    if (filters?.search && !course?.title?.toLowerCase()?.includes(filters?.search?.toLowerCase()) &&
        !course?.description?.toLowerCase()?.includes(filters?.search?.toLowerCase()) &&
        !course?.providerName?.toLowerCase()?.includes(filters?.search?.toLowerCase())) {
      return false;
    }
    
    if (filters?.provider && course?.provider !== filters?.provider) return false;
    if (filters?.compliance && course?.compliance !== filters?.compliance) return false;
    if (filters?.category && course?.category !== filters?.category) return false;
    
    return true;
  });

  const sortedCourses = [...filteredCourses]?.sort((a, b) => {
    const aValue = a?.[sortConfig?.key];
    const bValue = b?.[sortConfig?.key];
    
    if (sortConfig?.direction === 'asc') {
      return aValue > bValue ? 1 : -1;
    } else {
      return aValue < bValue ? 1 : -1;
    }
  });

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Training Course Management - Dairy Training Matrix</title>
        <meta name="description" content="Manage training courses, providers, and course catalog for dairy manufacturing facilities" />
      </Helmet>
      <Header 
        onMenuToggle={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        isMenuOpen={isMobileMenuOpen}
      />
      <RoleBasedSidebar 
        isCollapsed={isSidebarCollapsed}
        onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
        userRole="training_coordinator"
        className="hidden lg:block"
      />
      <main className={`
        pt-16 transition-all duration-200
        ${isSidebarCollapsed ? 'lg:ml-16' : 'lg:ml-60'}
      `}>
        <div className="h-[calc(100vh-4rem)] flex">
          {/* Left Panel - Course Catalog Tree */}
          <div className="w-1/4 border-r border-border bg-card">
            <CourseCatalogTree
              categories={categories}
              selectedCategory={selectedCategory}
              onCategorySelect={handleCategorySelect}
              onCategoryToggle={handleCategoryToggle}
              expandedCategories={expandedCategories}
            />
          </div>

          {/* Right Panel - Main Content */}
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Content Header */}
            <div className="p-6 border-b border-border bg-card">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h1 className="text-2xl font-bold text-foreground">Training Course Management</h1>
                  <p className="text-muted-foreground">
                    Manage course catalog, providers, and training content across all facilities
                  </p>
                </div>
                
                <div className="flex items-center space-x-3">
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="Download"
                    iconPosition="left"
                  >
                    Export Catalog
                  </Button>
                  <Button
                    variant="default"
                    size="sm"
                    iconName="Plus"
                    iconPosition="left"
                    onClick={() => handleBulkAction('add')}
                  >
                    Add Course
                  </Button>
                </div>
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-4 gap-4">
                <div className="bg-muted/30 rounded-lg p-3">
                  <div className="flex items-center space-x-2">
                    <Icon name="BookOpen" size={16} className="text-primary" />
                    <span className="text-sm font-medium text-foreground">Total Courses</span>
                  </div>
                  <div className="text-2xl font-bold text-foreground mt-1">{courses?.length}</div>
                </div>
                
                <div className="bg-muted/30 rounded-lg p-3">
                  <div className="flex items-center space-x-2">
                    <Icon name="Users" size={16} className="text-accent" />
                    <span className="text-sm font-medium text-foreground">Active Providers</span>
                  </div>
                  <div className="text-2xl font-bold text-foreground mt-1">
                    {new Set(courses.map(c => c.provider))?.size}
                  </div>
                </div>
                
                <div className="bg-muted/30 rounded-lg p-3">
                  <div className="flex items-center space-x-2">
                    <Icon name="DollarSign" size={16} className="text-success" />
                    <span className="text-sm font-medium text-foreground">Total Value</span>
                  </div>
                  <div className="text-2xl font-bold text-foreground mt-1">
                    ${courses?.reduce((sum, c) => sum + c?.cost, 0)?.toLocaleString()}
                  </div>
                </div>
                
                <div className="bg-muted/30 rounded-lg p-3">
                  <div className="flex items-center space-x-2">
                    <Icon name="AlertTriangle" size={16} className="text-warning" />
                    <span className="text-sm font-medium text-foreground">Sync Issues</span>
                  </div>
                  <div className="text-2xl font-bold text-foreground mt-1">2</div>
                </div>
              </div>
            </div>

            {/* Filters */}
            <div className="p-6 border-b border-border">
              <CourseFilters
                filters={filters}
                onFiltersChange={setFilters}
                onReset={() => setFilters({})}
                totalCourses={courses?.length}
                filteredCount={filteredCourses?.length}
              />
            </div>

            {/* Main Content Area */}
            <div className="flex-1 overflow-hidden">
              <div className="h-full flex">
                {/* Course Grid */}
                <div className="flex-1 p-6 overflow-y-auto">
                  <CourseGrid
                    courses={sortedCourses}
                    selectedCourses={selectedCourses}
                    onCourseSelect={setSelectedCourses}
                    onCourseEdit={handleCourseEdit}
                    onBulkAction={handleBulkAction}
                    sortConfig={sortConfig}
                    onSort={handleSort}
                  />
                </div>

                {/* Provider Sync Status */}
                <div className="w-80 p-6 border-l border-border overflow-y-auto">
                  <ProviderSyncStatus />
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      {/* Bulk Edit Modal */}
      <BulkEditModal
        isOpen={bulkEditModal?.isOpen}
        onClose={() => setBulkEditModal({ isOpen: false, action: 'edit' })}
        selectedCourses={selectedCourses}
        onSave={handleBulkEditSave}
        action={bulkEditModal?.action}
      />
    </div>
  );
};

export default TrainingCourseManagement;