import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const BulkEditModal = ({ 
  isOpen, 
  onClose, 
  selectedCourses, 
  onSave,
  action = 'edit' 
}) => {
  const [bulkForm, setBulkForm] = useState({
    provider: '',
    cost: '',
    validityPeriod: '',
    compliance: '',
    isActive: '',
    category: ''
  });

  const [fieldsToUpdate, setFieldsToUpdate] = useState({
    provider: false,
    cost: false,
    validityPeriod: false,
    compliance: false,
    isActive: false,
    category: false
  });

  const providerOptions = [
    { value: 'dairy_safety_institute', label: 'Dairy Safety Institute' },
    { value: 'haccp_training_corp', label: 'HACCP Training Corp' },
    { value: 'equipment_masters', label: 'Equipment Masters' },
    { value: 'safety_first_training', label: 'Safety First Training' },
    { value: 'quality_assurance_academy', label: 'Quality Assurance Academy' }
  ];

  const complianceOptions = [
    { value: 'fda', label: 'FDA Required' },
    { value: 'usda', label: 'USDA Required' },
    { value: 'osha', label: 'OSHA Required' },
    { value: 'haccp', label: 'HACCP Certified' },
    { value: 'internal', label: 'Internal Policy' }
  ];

  const statusOptions = [
    { value: 'true', label: 'Active' },
    { value: 'false', label: 'Inactive' }
  ];

  const categoryOptions = [
    { value: 'safety', label: 'Dairy Safety & Hygiene' },
    { value: 'haccp', label: 'HACCP & Food Safety' },
    { value: 'equipment', label: 'Equipment Operation' },
    { value: 'quality', label: 'Quality Control' },
    { value: 'emergency', label: 'Emergency Response' },
    { value: 'compliance', label: 'Regulatory Compliance' },
    { value: 'driver', label: 'Driver Training' },
    { value: 'induction', label: 'New Employee Induction' }
  ];

  const handleFieldToggle = (field) => {
    setFieldsToUpdate(prev => ({
      ...prev,
      [field]: !prev?.[field]
    }));
  };

  const handleSave = () => {
    const updates = {};
    Object.keys(fieldsToUpdate)?.forEach(field => {
      if (fieldsToUpdate?.[field] && bulkForm?.[field] !== '') {
        updates[field] = bulkForm?.[field];
      }
    });

    onSave(selectedCourses, updates);
    onClose();
  };

  const getActionTitle = () => {
    switch (action) {
      case 'edit': return 'Bulk Edit Courses';
      case 'duplicate': return 'Duplicate Courses';
      case 'delete': return 'Delete Courses';
      default: return 'Bulk Action';
    }
  };

  const getActionDescription = () => {
    switch (action) {
      case 'edit': return `Update ${selectedCourses?.length} selected courses`;
      case 'duplicate': return `Create copies of ${selectedCourses?.length} selected courses`;
      case 'delete': return `Permanently delete ${selectedCourses?.length} selected courses`;
      default: return '';
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-200 flex items-center justify-center">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-background/80 backdrop-blur-sm"
        onClick={onClose}
      />
      {/* Modal */}
      <div className="relative bg-card border border-border rounded-lg shadow-industrial-strong w-full max-w-2xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div>
            <h2 className="text-xl font-semibold text-foreground">{getActionTitle()}</h2>
            <p className="text-sm text-muted-foreground mt-1">{getActionDescription()}</p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
          >
            <Icon name="X" size={20} />
          </Button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[60vh]">
          {action === 'delete' ? (
            <div className="text-center py-8">
              <Icon name="AlertTriangle" size={48} className="mx-auto text-error mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">Confirm Deletion</h3>
              <p className="text-muted-foreground mb-6">
                This action cannot be undone. The selected courses and all associated data will be permanently deleted.
              </p>
              <div className="bg-error/10 border border-error/20 rounded-lg p-4 mb-6">
                <p className="text-sm text-error font-medium">
                  {selectedCourses?.length} courses will be deleted
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Provider Update */}
              <div className="flex items-start space-x-3">
                <input
                  type="checkbox"
                  checked={fieldsToUpdate?.provider}
                  onChange={() => handleFieldToggle('provider')}
                  className="mt-2 rounded border-border"
                />
                <div className="flex-1">
                  <Select
                    label="Training Provider"
                    options={providerOptions}
                    value={bulkForm?.provider}
                    onChange={(value) => setBulkForm({...bulkForm, provider: value})}
                    disabled={!fieldsToUpdate?.provider}
                    placeholder="Select provider..."
                  />
                </div>
              </div>

              {/* Cost Update */}
              <div className="flex items-start space-x-3">
                <input
                  type="checkbox"
                  checked={fieldsToUpdate?.cost}
                  onChange={() => handleFieldToggle('cost')}
                  className="mt-2 rounded border-border"
                />
                <div className="flex-1">
                  <Input
                    label="Course Cost ($)"
                    type="number"
                    value={bulkForm?.cost}
                    onChange={(e) => setBulkForm({...bulkForm, cost: e?.target?.value})}
                    disabled={!fieldsToUpdate?.cost}
                    placeholder="0.00"
                  />
                </div>
              </div>

              {/* Validity Period Update */}
              <div className="flex items-start space-x-3">
                <input
                  type="checkbox"
                  checked={fieldsToUpdate?.validityPeriod}
                  onChange={() => handleFieldToggle('validityPeriod')}
                  className="mt-2 rounded border-border"
                />
                <div className="flex-1">
                  <Input
                    label="Validity Period"
                    type="text"
                    value={bulkForm?.validityPeriod}
                    onChange={(e) => setBulkForm({...bulkForm, validityPeriod: e?.target?.value})}
                    disabled={!fieldsToUpdate?.validityPeriod}
                    placeholder="e.g., 12 months, 2 years"
                  />
                </div>
              </div>

              {/* Compliance Update */}
              <div className="flex items-start space-x-3">
                <input
                  type="checkbox"
                  checked={fieldsToUpdate?.compliance}
                  onChange={() => handleFieldToggle('compliance')}
                  className="mt-2 rounded border-border"
                />
                <div className="flex-1">
                  <Select
                    label="Compliance Type"
                    options={complianceOptions}
                    value={bulkForm?.compliance}
                    onChange={(value) => setBulkForm({...bulkForm, compliance: value})}
                    disabled={!fieldsToUpdate?.compliance}
                    placeholder="Select compliance type..."
                  />
                </div>
              </div>

              {/* Category Update */}
              <div className="flex items-start space-x-3">
                <input
                  type="checkbox"
                  checked={fieldsToUpdate?.category}
                  onChange={() => handleFieldToggle('category')}
                  className="mt-2 rounded border-border"
                />
                <div className="flex-1">
                  <Select
                    label="Course Category"
                    options={categoryOptions}
                    value={bulkForm?.category}
                    onChange={(value) => setBulkForm({...bulkForm, category: value})}
                    disabled={!fieldsToUpdate?.category}
                    placeholder="Select category..."
                  />
                </div>
              </div>

              {/* Status Update */}
              <div className="flex items-start space-x-3">
                <input
                  type="checkbox"
                  checked={fieldsToUpdate?.isActive}
                  onChange={() => handleFieldToggle('isActive')}
                  className="mt-2 rounded border-border"
                />
                <div className="flex-1">
                  <Select
                    label="Course Status"
                    options={statusOptions}
                    value={bulkForm?.isActive}
                    onChange={(value) => setBulkForm({...bulkForm, isActive: value})}
                    disabled={!fieldsToUpdate?.isActive}
                    placeholder="Select status..."
                  />
                </div>
              </div>

              {/* Update Summary */}
              <div className="bg-muted/30 border border-border rounded-lg p-4">
                <h4 className="text-sm font-medium text-foreground mb-2">Update Summary</h4>
                <div className="space-y-1 text-xs text-muted-foreground">
                  <p>Selected courses: <span className="font-medium text-foreground">{selectedCourses?.length}</span></p>
                  <p>Fields to update: <span className="font-medium text-foreground">
                    {Object.values(fieldsToUpdate)?.filter(Boolean)?.length}
                  </span></p>
                  {Object.values(fieldsToUpdate)?.filter(Boolean)?.length === 0 && (
                    <p className="text-warning">No fields selected for update</p>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end space-x-3 p-6 border-t border-border bg-muted/30">
          <Button
            variant="outline"
            onClick={onClose}
          >
            Cancel
          </Button>
          <Button
            variant={action === 'delete' ? 'destructive' : 'default'}
            onClick={handleSave}
            disabled={action === 'edit' && Object.values(fieldsToUpdate)?.filter(Boolean)?.length === 0}
            iconName={action === 'delete' ? 'Trash2' : 'Save'}
            iconPosition="left"
          >
            {action === 'delete' ? 'Delete Courses' : 'Apply Changes'}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default BulkEditModal;