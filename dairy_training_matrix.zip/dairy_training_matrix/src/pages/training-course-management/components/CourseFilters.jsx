import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

import Select from '../../../components/ui/Select';

const CourseFilters = ({ 
  filters, 
  onFiltersChange, 
  onReset,
  totalCourses,
  filteredCount,
  className = '' 
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [searchTerm, setSearchTerm] = useState(filters?.search || '');

  const providerOptions = [
    { value: '', label: 'All Providers' },
    { value: 'dairy_safety_institute', label: 'Dairy Safety Institute' },
    { value: 'haccp_training_corp', label: 'HACCP Training Corp' },
    { value: 'equipment_masters', label: 'Equipment Masters' },
    { value: 'safety_first_training', label: 'Safety First Training' },
    { value: 'quality_assurance_academy', label: 'Quality Assurance Academy' }
  ];

  const complianceOptions = [
    { value: '', label: 'All Compliance Types' },
    { value: 'fda', label: 'FDA Required' },
    { value: 'usda', label: 'USDA Required' },
    { value: 'osha', label: 'OSHA Required' },
    { value: 'haccp', label: 'HACCP Certified' },
    { value: 'internal', label: 'Internal Policy' }
  ];

  const categoryOptions = [
    { value: '', label: 'All Categories' },
    { value: 'safety', label: 'Dairy Safety & Hygiene' },
    { value: 'haccp', label: 'HACCP & Food Safety' },
    { value: 'equipment', label: 'Equipment Operation' },
    { value: 'quality', label: 'Quality Control' },
    { value: 'emergency', label: 'Emergency Response' },
    { value: 'compliance', label: 'Regulatory Compliance' },
    { value: 'driver', label: 'Driver Training' },
    { value: 'induction', label: 'New Employee Induction' }
  ];

  const statusOptions = [
    { value: '', label: 'All Statuses' },
    { value: 'active', label: 'Active' },
    { value: 'inactive', label: 'Inactive' },
    { value: 'pending', label: 'Pending Review' },
    { value: 'expired', label: 'Expired' }
  ];

  const costRangeOptions = [
    { value: '', label: 'Any Cost' },
    { value: '0-100', label: '$0 - $100' },
    { value: '100-500', label: '$100 - $500' },
    { value: '500-1000', label: '$500 - $1,000' },
    { value: '1000+', label: '$1,000+' }
  ];

  const durationOptions = [
    { value: '', label: 'Any Duration' },
    { value: '0-2', label: '0-2 hours' },
    { value: '2-8', label: '2-8 hours' },
    { value: '8-24', label: '1-3 days' },
    { value: '24+', label: '3+ days' }
  ];

  const handleSearchChange = (e) => {
    const value = e?.target?.value;
    setSearchTerm(value);
    
    // Debounce search
    clearTimeout(window.searchTimeout);
    window.searchTimeout = setTimeout(() => {
      onFiltersChange({ ...filters, search: value });
    }, 300);
  };

  const handleFilterChange = (key, value) => {
    onFiltersChange({ ...filters, [key]: value });
  };

  const getActiveFiltersCount = () => {
    return Object.values(filters)?.filter(value => value && value !== '')?.length;
  };

  const hasActiveFilters = getActiveFiltersCount() > 0;

  return (
    <div className={`bg-card border border-border rounded-lg ${className}`}>
      {/* Filter Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <Icon name="Filter" size={16} className="text-muted-foreground" />
            <h3 className="font-medium text-foreground">Filters</h3>
            {hasActiveFilters && (
              <span className="inline-flex items-center px-2 py-1 text-xs font-medium bg-primary/10 text-primary rounded-full">
                {getActiveFiltersCount()}
              </span>
            )}
          </div>
          
          <div className="text-sm text-muted-foreground">
            Showing {filteredCount} of {totalCourses} courses
          </div>
        </div>

        <div className="flex items-center space-x-2">
          {hasActiveFilters && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onReset}
              iconName="X"
              iconPosition="left"
            >
              Clear All
            </Button>
          )}
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
            iconName={isExpanded ? 'ChevronUp' : 'ChevronDown'}
            iconPosition="right"
          >
            {isExpanded ? 'Less' : 'More'} Filters
          </Button>
        </div>
      </div>
      {/* Search Bar */}
      <div className="p-4 border-b border-border">
        <div className="relative">
          <Icon 
            name="Search" 
            size={16} 
            className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" 
          />
          <input
            type="text"
            placeholder="Search courses, providers, descriptions..."
            value={searchTerm}
            onChange={handleSearchChange}
            className="w-full pl-10 pr-4 py-2 text-sm border border-border rounded-lg bg-input focus:outline-none focus:ring-2 focus:ring-ring"
          />
          {searchTerm && (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => {
                setSearchTerm('');
                onFiltersChange({ ...filters, search: '' });
              }}
              className="absolute right-2 top-1/2 transform -translate-y-1/2 h-6 w-6"
            >
              <Icon name="X" size={12} />
            </Button>
          )}
        </div>
      </div>
      {/* Basic Filters */}
      <div className="p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Select
          label="Provider"
          options={providerOptions}
          value={filters?.provider || ''}
          onChange={(value) => handleFilterChange('provider', value)}
        />
        
        <Select
          label="Category"
          options={categoryOptions}
          value={filters?.category || ''}
          onChange={(value) => handleFilterChange('category', value)}
        />
        
        <Select
          label="Compliance"
          options={complianceOptions}
          value={filters?.compliance || ''}
          onChange={(value) => handleFilterChange('compliance', value)}
        />
        
        <Select
          label="Status"
          options={statusOptions}
          value={filters?.status || ''}
          onChange={(value) => handleFilterChange('status', value)}
        />
      </div>
      {/* Advanced Filters */}
      {isExpanded && (
        <div className="p-4 pt-0 border-t border-border">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Select
              label="Cost Range"
              options={costRangeOptions}
              value={filters?.costRange || ''}
              onChange={(value) => handleFilterChange('costRange', value)}
            />
            
            <Select
              label="Duration"
              options={durationOptions}
              value={filters?.duration || ''}
              onChange={(value) => handleFilterChange('duration', value)}
            />
            
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Created After
              </label>
              <input
                type="date"
                value={filters?.createdAfter || ''}
                onChange={(e) => handleFilterChange('createdAfter', e?.target?.value)}
                className="w-full px-3 py-2 text-sm border border-border rounded-lg bg-input focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Updated After
              </label>
              <input
                type="date"
                value={filters?.updatedAfter || ''}
                onChange={(e) => handleFilterChange('updatedAfter', e?.target?.value)}
                className="w-full px-3 py-2 text-sm border border-border rounded-lg bg-input focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
          </div>

          {/* Additional Options */}
          <div className="mt-4 pt-4 border-t border-border">
            <div className="flex flex-wrap gap-4">
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={filters?.hasPrerequisites || false}
                  onChange={(e) => handleFilterChange('hasPrerequisites', e?.target?.checked)}
                  className="rounded border-border"
                />
                <span className="text-sm text-foreground">Has Prerequisites</span>
              </label>
              
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={filters?.isRequired || false}
                  onChange={(e) => handleFilterChange('isRequired', e?.target?.checked)}
                  className="rounded border-border"
                />
                <span className="text-sm text-foreground">Required Training</span>
              </label>
              
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={filters?.expiresIn30Days || false}
                  onChange={(e) => handleFilterChange('expiresIn30Days', e?.target?.checked)}
                  className="rounded border-border"
                />
                <span className="text-sm text-foreground">Expires in 30 Days</span>
              </label>
              
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={filters?.syncIssues || false}
                  onChange={(e) => handleFilterChange('syncIssues', e?.target?.checked)}
                  className="rounded border-border"
                />
                <span className="text-sm text-foreground">Sync Issues</span>
              </label>
            </div>
          </div>
        </div>
      )}
      {/* Quick Filter Tags */}
      {hasActiveFilters && (
        <div className="p-4 pt-0">
          <div className="flex flex-wrap gap-2">
            {Object.entries(filters)?.map(([key, value]) => {
              if (!value || value === '') return null;
              
              const getFilterLabel = (key, value) => {
                switch (key) {
                  case 'search': return `Search: "${value}"`;
                  case 'provider': return `Provider: ${providerOptions?.find(o => o?.value === value)?.label || value}`;
                  case 'category': return `Category: ${categoryOptions?.find(o => o?.value === value)?.label || value}`;
                  case 'compliance': return `Compliance: ${complianceOptions?.find(o => o?.value === value)?.label || value}`;
                  case 'status': return `Status: ${statusOptions?.find(o => o?.value === value)?.label || value}`;
                  case 'costRange': return `Cost: ${costRangeOptions?.find(o => o?.value === value)?.label || value}`;
                  case 'duration': return `Duration: ${durationOptions?.find(o => o?.value === value)?.label || value}`;
                  case 'createdAfter': return `Created after: ${value}`;
                  case 'updatedAfter': return `Updated after: ${value}`;
                  case 'hasPrerequisites': return 'Has Prerequisites';
                  case 'isRequired': return 'Required Training';
                  case 'expiresIn30Days': return 'Expires in 30 Days';
                  case 'syncIssues': return 'Sync Issues';
                  default: return `${key}: ${value}`;
                }
              };

              return (
                <span
                  key={key}
                  className="inline-flex items-center px-2 py-1 text-xs bg-primary/10 text-primary rounded-full"
                >
                  {getFilterLabel(key, value)}
                  <button
                    onClick={() => handleFilterChange(key, '')}
                    className="ml-1 hover:text-primary/80"
                  >
                    <Icon name="X" size={10} />
                  </button>
                </span>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default CourseFilters;