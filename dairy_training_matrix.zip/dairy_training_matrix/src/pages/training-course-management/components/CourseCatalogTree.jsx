import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const CourseCatalogTree = ({ 
  categories, 
  selectedCategory, 
  onCategorySelect,
  onCategoryToggle,
  expandedCategories,
  className = '' 
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredCategories = categories?.filter(category =>
    category?.name?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
    category?.courses?.some(course => 
      course?.title?.toLowerCase()?.includes(searchTerm?.toLowerCase())
    )
  );

  const getCategoryIcon = (categoryType) => {
    const iconMap = {
      'safety': 'Shield',
      'haccp': 'FileCheck',
      'equipment': 'Settings',
      'quality': 'CheckCircle',
      'emergency': 'AlertTriangle',
      'compliance': 'FileText',
      'driver': 'Truck',
      'induction': 'UserPlus'
    };
    return iconMap?.[categoryType] || 'BookOpen';
  };

  const getCategoryColor = (categoryType) => {
    const colorMap = {
      'safety': 'text-error',
      'haccp': 'text-warning',
      'equipment': 'text-accent',
      'quality': 'text-success',
      'emergency': 'text-error',
      'compliance': 'text-primary',
      'driver': 'text-secondary',
      'induction': 'text-accent'
    };
    return colorMap?.[categoryType] || 'text-foreground';
  };

  return (
    <div className={`bg-card border-r border-border h-full flex flex-col ${className}`}>
      {/* Header */}
      <div className="p-4 border-b border-border">
        <h2 className="text-lg font-semibold text-foreground mb-3">Course Catalog</h2>
        
        {/* Search */}
        <div className="relative">
          <Icon 
            name="Search" 
            size={16} 
            className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" 
          />
          <input
            type="text"
            placeholder="Search categories..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e?.target?.value)}
            className="w-full pl-10 pr-4 py-2 text-sm border border-border rounded-lg bg-input focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
      </div>
      {/* Category Tree */}
      <div className="flex-1 overflow-y-auto p-2">
        <div className="space-y-1">
          {filteredCategories?.map((category) => (
            <div key={category?.id} className="space-y-1">
              {/* Category Header */}
              <div
                className={`
                  flex items-center justify-between p-2 rounded-lg cursor-pointer
                  hover:bg-muted transition-colors
                  ${selectedCategory?.id === category?.id ? 'bg-primary/10 border border-primary/20' : ''}
                `}
                onClick={() => onCategorySelect(category)}
              >
                <div className="flex items-center space-x-2 flex-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={(e) => {
                      e?.stopPropagation();
                      onCategoryToggle(category?.id);
                    }}
                    className="h-6 w-6"
                  >
                    <Icon 
                      name={expandedCategories?.includes(category?.id) ? 'ChevronDown' : 'ChevronRight'} 
                      size={14} 
                    />
                  </Button>
                  
                  <Icon 
                    name={getCategoryIcon(category?.type)} 
                    size={16} 
                    className={getCategoryColor(category?.type)}
                  />
                  
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">
                      {category?.name}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {category?.courses?.length} courses
                    </p>
                  </div>
                </div>

                {/* Category Status */}
                <div className="flex items-center space-x-1">
                  {category?.hasUpdates && (
                    <div className="w-2 h-2 bg-warning rounded-full" title="Has updates" />
                  )}
                  {category?.syncStatus === 'error' && (
                    <Icon name="AlertCircle" size={12} className="text-error" />
                  )}
                </div>
              </div>

              {/* Course List */}
              {expandedCategories?.includes(category?.id) && (
                <div className="ml-6 space-y-1">
                  {category?.courses?.map((course) => (
                    <div
                      key={course?.id}
                      className="flex items-center space-x-2 p-2 rounded hover:bg-muted/50 cursor-pointer"
                      onClick={() => onCategorySelect(category, course)}
                    >
                      <Icon name="BookOpen" size={12} className="text-muted-foreground" />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-medium text-foreground truncate">
                          {course?.title}
                        </p>
                        <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                          <span>{course?.duration}</span>
                          <span>•</span>
                          <span>${course?.cost}</span>
                        </div>
                      </div>
                      
                      {/* Course Status Indicators */}
                      <div className="flex items-center space-x-1">
                        {course?.isRequired && (
                          <div className="w-1.5 h-1.5 bg-error rounded-full" title="Required" />
                        )}
                        {course?.hasPrerequisites && (
                          <Icon name="Link" size={10} className="text-warning" title="Has prerequisites" />
                        )}
                        {course?.expiresIn30Days && (
                          <Icon name="Clock" size={10} className="text-warning" title="Expires soon" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
      {/* Footer Stats */}
      <div className="p-4 border-t border-border bg-muted/30">
        <div className="space-y-2 text-xs">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Total Categories:</span>
            <span className="font-medium text-foreground">{categories?.length}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Total Courses:</span>
            <span className="font-medium text-foreground">
              {categories?.reduce((sum, cat) => sum + cat?.courses?.length, 0)}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Active Providers:</span>
            <span className="font-medium text-foreground">
              {new Set(categories.flatMap(cat => cat.courses.map(course => course.provider)))?.size}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CourseCatalogTree;