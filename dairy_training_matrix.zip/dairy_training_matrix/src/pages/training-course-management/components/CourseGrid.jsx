import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const CourseGrid = ({ 
  courses, 
  selectedCourses, 
  onCourseSelect, 
  onCourseEdit,
  onBulkAction,
  sortConfig,
  onSort,
  className = '' 
}) => {
  const [editingCourse, setEditingCourse] = useState(null);
  const [editForm, setEditForm] = useState({});

  const providerOptions = [
    { value: 'dairy_safety_institute', label: 'Dairy Safety Institute' },
    { value: 'haccp_training_corp', label: 'HACCP Training Corp' },
    { value: 'equipment_masters', label: 'Equipment Masters' },
    { value: 'safety_first_training', label: 'Safety First Training' },
    { value: 'quality_assurance_academy', label: 'Quality Assurance Academy' }
  ];

  const complianceOptions = [
    { value: 'fda', label: 'FDA Required' },
    { value: 'usda', label: 'USDA Required' },
    { value: 'osha', label: 'OSHA Required' },
    { value: 'haccp', label: 'HACCP Certified' },
    { value: 'internal', label: 'Internal Policy' }
  ];

  const handleEditStart = (course) => {
    setEditingCourse(course?.id);
    setEditForm({
      title: course?.title,
      provider: course?.provider,
      duration: course?.duration,
      cost: course?.cost,
      validityPeriod: course?.validityPeriod,
      compliance: course?.compliance,
      description: course?.description
    });
  };

  const handleEditSave = () => {
    onCourseEdit(editingCourse, editForm);
    setEditingCourse(null);
    setEditForm({});
  };

  const handleEditCancel = () => {
    setEditingCourse(null);
    setEditForm({});
  };

  const getSortIcon = (column) => {
    if (sortConfig?.key !== column) return 'ArrowUpDown';
    return sortConfig?.direction === 'asc' ? 'ArrowUp' : 'ArrowDown';
  };

  const getComplianceColor = (compliance) => {
    const colorMap = {
      'fda': 'bg-error/10 text-error border-error/20',
      'usda': 'bg-warning/10 text-warning border-warning/20',
      'osha': 'bg-accent/10 text-accent border-accent/20',
      'haccp': 'bg-success/10 text-success border-success/20',
      'internal': 'bg-muted text-muted-foreground border-border'
    };
    return colorMap?.[compliance] || 'bg-muted text-muted-foreground border-border';
  };

  const getProviderStatus = (provider, lastSync) => {
    const now = new Date();
    const syncDate = new Date(lastSync);
    const hoursDiff = (now - syncDate) / (1000 * 60 * 60);
    
    if (hoursDiff > 24) return { status: 'error', icon: 'XCircle', color: 'text-error' };
    if (hoursDiff > 12) return { status: 'warning', icon: 'AlertTriangle', color: 'text-warning' };
    return { status: 'success', icon: 'CheckCircle', color: 'text-success' };
  };

  return (
    <div className={`bg-card rounded-lg border border-border ${className}`}>
      {/* Grid Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Course Management</h3>
            <p className="text-sm text-muted-foreground">
              {courses?.length} courses • {selectedCourses?.length} selected
            </p>
          </div>
          
          {/* Bulk Actions */}
          {selectedCourses?.length > 0 && (
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => onBulkAction('edit')}
                iconName="Edit"
                iconPosition="left"
              >
                Bulk Edit
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => onBulkAction('duplicate')}
                iconName="Copy"
                iconPosition="left"
              >
                Duplicate
              </Button>
              <Button
                variant="destructive"
                size="sm"
                onClick={() => onBulkAction('delete')}
                iconName="Trash2"
                iconPosition="left"
              >
                Delete
              </Button>
            </div>
          )}
        </div>

        {/* Quick Actions */}
        <div className="flex items-center space-x-2">
          <Button
            variant="default"
            size="sm"
            onClick={() => onBulkAction('add')}
            iconName="Plus"
            iconPosition="left"
          >
            Add Course
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onBulkAction('import')}
            iconName="Upload"
            iconPosition="left"
          >
            Import
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onBulkAction('export')}
            iconName="Download"
            iconPosition="left"
          >
            Export
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onBulkAction('refresh')}
            iconName="RefreshCw"
            iconPosition="left"
          >
            Sync All
          </Button>
        </div>
      </div>
      {/* Course Grid */}
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-muted/30">
            <tr>
              <th className="w-12 p-3 text-left">
                <input
                  type="checkbox"
                  checked={selectedCourses?.length === courses?.length && courses?.length > 0}
                  onChange={(e) => {
                    if (e?.target?.checked) {
                      onCourseSelect(courses?.map(c => c?.id));
                    } else {
                      onCourseSelect([]);
                    }
                  }}
                  className="rounded border-border"
                />
              </th>
              
              {[
                { key: 'title', label: 'Course Title', width: 'w-64' },
                { key: 'provider', label: 'Provider', width: 'w-48' },
                { key: 'duration', label: 'Duration', width: 'w-24' },
                { key: 'cost', label: 'Cost', width: 'w-24' },
                { key: 'validity', label: 'Validity', width: 'w-24' },
                { key: 'compliance', label: 'Compliance', width: 'w-32' },
                { key: 'status', label: 'Status', width: 'w-24' },
                { key: 'actions', label: 'Actions', width: 'w-32' }
              ]?.map((column) => (
                <th 
                  key={column?.key}
                  className={`${column?.width} p-3 text-left text-sm font-medium text-muted-foreground`}
                >
                  {column?.key !== 'actions' ? (
                    <button
                      onClick={() => onSort(column?.key)}
                      className="flex items-center space-x-1 hover:text-foreground transition-colors"
                    >
                      <span>{column?.label}</span>
                      <Icon name={getSortIcon(column?.key)} size={14} />
                    </button>
                  ) : (
                    column?.label
                  )}
                </th>
              ))}
            </tr>
          </thead>
          
          <tbody>
            {courses?.map((course) => (
              <tr 
                key={course?.id} 
                className="border-b border-border hover:bg-muted/20 transition-colors"
              >
                <td className="p-3">
                  <input
                    type="checkbox"
                    checked={selectedCourses?.includes(course?.id)}
                    onChange={(e) => {
                      if (e?.target?.checked) {
                        onCourseSelect([...selectedCourses, course?.id]);
                      } else {
                        onCourseSelect(selectedCourses?.filter(id => id !== course?.id));
                      }
                    }}
                    className="rounded border-border"
                  />
                </td>
                
                {/* Course Title */}
                <td className="p-3">
                  {editingCourse === course?.id ? (
                    <Input
                      type="text"
                      value={editForm?.title}
                      onChange={(e) => setEditForm({...editForm, title: e?.target?.value})}
                      className="text-sm"
                    />
                  ) : (
                    <div>
                      <p className="font-medium text-foreground">{course?.title}</p>
                      <p className="text-xs text-muted-foreground truncate max-w-xs">
                        {course?.description}
                      </p>
                    </div>
                  )}
                </td>
                
                {/* Provider */}
                <td className="p-3">
                  {editingCourse === course?.id ? (
                    <Select
                      options={providerOptions}
                      value={editForm?.provider}
                      onChange={(value) => setEditForm({...editForm, provider: value})}
                    />
                  ) : (
                    <div className="flex items-center space-x-2">
                      <span className="text-sm text-foreground">{course?.providerName}</span>
                      {(() => {
                        const status = getProviderStatus(course?.provider, course?.lastSync);
                        return (
                          <Icon 
                            name={status?.icon} 
                            size={12} 
                            className={status?.color}
                            title={`Sync status: ${status?.status}`}
                          />
                        );
                      })()}
                    </div>
                  )}
                </td>
                
                {/* Duration */}
                <td className="p-3">
                  {editingCourse === course?.id ? (
                    <Input
                      type="text"
                      value={editForm?.duration}
                      onChange={(e) => setEditForm({...editForm, duration: e?.target?.value})}
                      className="text-sm w-20"
                    />
                  ) : (
                    <span className="text-sm text-foreground text-data">{course?.duration}</span>
                  )}
                </td>
                
                {/* Cost */}
                <td className="p-3">
                  {editingCourse === course?.id ? (
                    <Input
                      type="number"
                      value={editForm?.cost}
                      onChange={(e) => setEditForm({...editForm, cost: e?.target?.value})}
                      className="text-sm w-20"
                    />
                  ) : (
                    <span className="text-sm text-foreground text-data">${course?.cost}</span>
                  )}
                </td>
                
                {/* Validity Period */}
                <td className="p-3">
                  {editingCourse === course?.id ? (
                    <Input
                      type="text"
                      value={editForm?.validityPeriod}
                      onChange={(e) => setEditForm({...editForm, validityPeriod: e?.target?.value})}
                      className="text-sm w-20"
                    />
                  ) : (
                    <span className="text-sm text-foreground text-data">{course?.validityPeriod}</span>
                  )}
                </td>
                
                {/* Compliance */}
                <td className="p-3">
                  {editingCourse === course?.id ? (
                    <Select
                      options={complianceOptions}
                      value={editForm?.compliance}
                      onChange={(value) => setEditForm({...editForm, compliance: value})}
                    />
                  ) : (
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded border ${getComplianceColor(course?.compliance)}`}>
                      {course?.complianceLabel}
                    </span>
                  )}
                </td>
                
                {/* Status */}
                <td className="p-3">
                  <div className="flex items-center space-x-1">
                    <div className={`w-2 h-2 rounded-full ${course?.isActive ? 'bg-success' : 'bg-muted'}`} />
                    <span className="text-xs text-muted-foreground">
                      {course?.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                </td>
                
                {/* Actions */}
                <td className="p-3">
                  {editingCourse === course?.id ? (
                    <div className="flex items-center space-x-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={handleEditSave}
                        className="h-8 w-8"
                      >
                        <Icon name="Check" size={14} className="text-success" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={handleEditCancel}
                        className="h-8 w-8"
                      >
                        <Icon name="X" size={14} className="text-error" />
                      </Button>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleEditStart(course)}
                        className="h-8 w-8"
                        title="Edit course"
                      >
                        <Icon name="Edit" size={14} />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onBulkAction('duplicate', [course?.id])}
                        className="h-8 w-8"
                        title="Duplicate course"
                      >
                        <Icon name="Copy" size={14} />
                      </Button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {/* Empty State */}
      {courses?.length === 0 && (
        <div className="p-12 text-center">
          <Icon name="BookOpen" size={48} className="mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-2">No courses found</h3>
          <p className="text-muted-foreground mb-4">
            Get started by adding your first training course.
          </p>
          <Button
            variant="default"
            onClick={() => onBulkAction('add')}
            iconName="Plus"
            iconPosition="left"
          >
            Add Course
          </Button>
        </div>
      )}
    </div>
  );
};

export default CourseGrid;