import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ProviderSyncStatus = ({ className = '' }) => {
  const [providers, setProviders] = useState([]);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastRefresh, setLastRefresh] = useState(new Date());

  // Mock provider data
  useEffect(() => {
    const mockProviders = [
      {
        id: 'dairy_safety_institute',
        name: 'Dairy Safety Institute',
        status: 'connected',
        lastSync: new Date(Date.now() - 5 * 60 * 1000), // 5 minutes ago
        coursesCount: 24,
        error: null,
        apiHealth: 'good'
      },
      {
        id: 'haccp_training_corp',
        name: 'HACCP Training Corp',
        status: 'warning',
        lastSync: new Date(Date.now() - 25 * 60 * 1000), // 25 minutes ago
        coursesCount: 18,
        error: 'Slow response times detected',
        apiHealth: 'degraded'
      },
      {
        id: 'equipment_masters',
        name: 'Equipment Masters',
        status: 'connected',
        lastSync: new Date(Date.now() - 10 * 60 * 1000), // 10 minutes ago
        coursesCount: 32,
        error: null,
        apiHealth: 'good'
      },
      {
        id: 'safety_first_training',
        name: 'Safety First Training',
        status: 'error',
        lastSync: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
        coursesCount: 15,
        error: 'Authentication failed - API key expired',
        apiHealth: 'down'
      },
      {
        id: 'quality_assurance_academy',
        name: 'Quality Assurance Academy',
        status: 'connected',
        lastSync: new Date(Date.now() - 3 * 60 * 1000), // 3 minutes ago
        coursesCount: 21,
        error: null,
        apiHealth: 'good'
      }
    ];

    setProviders(mockProviders);
  }, []);

  const handleRefreshAll = async () => {
    setIsRefreshing(true);
    
    // Simulate API refresh
    setTimeout(() => {
      setProviders(prev => prev?.map(provider => ({
        ...provider,
        lastSync: new Date(),
        status: provider?.status === 'error' ? 'warning' : provider?.status,
        error: provider?.status === 'error' ? 'Retrying connection...' : provider?.error
      })));
      setLastRefresh(new Date());
      setIsRefreshing(false);
    }, 2000);
  };

  const handleRefreshProvider = (providerId) => {
    setProviders(prev => prev?.map(provider => 
      provider?.id === providerId 
        ? { ...provider, lastSync: new Date(), status: 'connected', error: null }
        : provider
    ));
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'connected': return 'CheckCircle';
      case 'warning': return 'AlertTriangle';
      case 'error': return 'XCircle';
      default: return 'Circle';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'connected': return 'text-success';
      case 'warning': return 'text-warning';
      case 'error': return 'text-error';
      default: return 'text-muted-foreground';
    }
  };

  const getHealthColor = (health) => {
    switch (health) {
      case 'good': return 'bg-success';
      case 'degraded': return 'bg-warning';
      case 'down': return 'bg-error';
      default: return 'bg-muted';
    }
  };

  const formatLastSync = (date) => {
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    return date?.toLocaleDateString();
  };

  const getOverallStatus = () => {
    const errorCount = providers?.filter(p => p?.status === 'error')?.length;
    const warningCount = providers?.filter(p => p?.status === 'warning')?.length;
    
    if (errorCount > 0) return 'error';
    if (warningCount > 0) return 'warning';
    return 'connected';
  };

  const overallStatus = getOverallStatus();
  const totalCourses = providers?.reduce((sum, p) => sum + p?.coursesCount, 0);

  return (
    <div className={`bg-card border border-border rounded-lg ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2">
            <Icon 
              name={getStatusIcon(overallStatus)} 
              size={16} 
              className={getStatusColor(overallStatus)}
            />
            <h3 className="font-medium text-foreground">Provider Integration</h3>
          </div>
          
          <div className="text-sm text-muted-foreground">
            {providers?.length} providers • {totalCourses} courses
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-xs text-muted-foreground">
            Last refresh: {formatLastSync(lastRefresh)}
          </span>
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefreshAll}
            disabled={isRefreshing}
            iconName={isRefreshing ? 'Loader2' : 'RefreshCw'}
            iconPosition="left"
            className={isRefreshing ? 'animate-spin' : ''}
          >
            {isRefreshing ? 'Syncing...' : 'Refresh All'}
          </Button>
        </div>
      </div>
      {/* Provider List */}
      <div className="divide-y divide-border">
        {providers?.map((provider) => (
          <div key={provider?.id} className="p-4 hover:bg-muted/20 transition-colors">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                {/* Status Indicator */}
                <div className="relative">
                  <Icon 
                    name={getStatusIcon(provider?.status)} 
                    size={16} 
                    className={getStatusColor(provider?.status)}
                  />
                  <div 
                    className={`absolute -bottom-1 -right-1 w-2 h-2 rounded-full ${getHealthColor(provider?.apiHealth)}`}
                    title={`API Health: ${provider?.apiHealth}`}
                  />
                </div>

                {/* Provider Info */}
                <div>
                  <h4 className="font-medium text-foreground">{provider?.name}</h4>
                  <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                    <span>{provider?.coursesCount} courses</span>
                    <span>•</span>
                    <span>Last sync: {formatLastSync(provider?.lastSync)}</span>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center space-x-2">
                {provider?.status === 'error' && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleRefreshProvider(provider?.id)}
                    iconName="RefreshCw"
                    iconPosition="left"
                  >
                    Retry
                  </Button>
                )}
                
                <Button
                  variant="ghost"
                  size="icon"
                  title="Provider settings"
                >
                  <Icon name="Settings" size={14} />
                </Button>
              </div>
            </div>

            {/* Error Message */}
            {provider?.error && (
              <div className="mt-3 p-2 bg-error/10 border border-error/20 rounded text-xs">
                <div className="flex items-start space-x-2">
                  <Icon name="AlertTriangle" size={12} className="text-error mt-0.5 flex-shrink-0" />
                  <span className="text-error">{provider?.error}</span>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
      {/* Footer Summary */}
      <div className="p-4 border-t border-border bg-muted/30">
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <div className="text-lg font-semibold text-success">
              {providers?.filter(p => p?.status === 'connected')?.length}
            </div>
            <div className="text-xs text-muted-foreground">Connected</div>
          </div>
          <div>
            <div className="text-lg font-semibold text-warning">
              {providers?.filter(p => p?.status === 'warning')?.length}
            </div>
            <div className="text-xs text-muted-foreground">Warning</div>
          </div>
          <div>
            <div className="text-lg font-semibold text-error">
              {providers?.filter(p => p?.status === 'error')?.length}
            </div>
            <div className="text-xs text-muted-foreground">Error</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProviderSyncStatus;