import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import RoleBasedSidebar from '../../components/ui/RoleBasedSidebar';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import AnalyticsKPICard from './components/AnalyticsKPICard';
import TrainingEffectivenessChart from './components/TrainingEffectivenessChart';
import DepartmentComparisonChart from './components/DepartmentComparisonChart';
import TrainingROIAnalysis from './components/TrainingROIAnalysis';
import PredictiveAnalytics from './components/PredictiveAnalytics';
import CustomReportBuilder from './components/CustomReportBuilder';

const TrainingAnalyticsInsights = () => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeView, setActiveView] = useState('overview');
  const [dateRange, setDateRange] = useState('30days');
  const [selectedDepartment, setSelectedDepartment] = useState('all');
  const [refreshing, setRefreshing] = useState(false);

  const userRole = 'training_coordinator';

  // Mock KPI data
  const kpiData = [
    {
      title: 'Training Completion Rate',
      value: '94.2%',
      change: '+2.3%',
      changeType: 'positive',
      icon: 'CheckCircle',
      description: 'Overall completion rate across all programs',
      trend: [2, 1, 3, -1, 2, 4, 1]
    },
    {
      title: 'Compliance Score',
      value: '87.5%',
      change: '+5.1%',
      changeType: 'positive',
      icon: 'Shield',
      description: 'Regulatory compliance achievement',
      trend: [1, 2, 1, 3, 2, 5, 3]
    },
    {
      title: 'Training ROI',
      value: '149.4%',
      change: '+12.7%',
      changeType: 'positive',
      icon: 'DollarSign',
      description: 'Return on training investment',
      trend: [3, 2, 4, 1, 3, 2, 4]
    },
    {
      title: 'Average Training Hours',
      value: '32.8h',
      change: '+4.2h',
      changeType: 'positive',
      icon: 'Clock',
      description: 'Per employee this month',
      trend: [1, 3, 2, 4, 2, 3, 1]
    },
    {
      title: 'Overdue Training',
      value: '23',
      change: '-8',
      changeType: 'positive',
      icon: 'AlertTriangle',
      description: 'Training sessions past due date',
      trend: [-2, -1, -3, 1, -2, -4, -1]
    },
    {
      title: 'Employee Satisfaction',
      value: '4.6/5',
      change: '+0.2',
      changeType: 'positive',
      icon: 'Star',
      description: 'Training program satisfaction score',
      trend: [1, 1, 2, 0, 1, 2, 1]
    }
  ];

  const handleToggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const handleToggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleRefreshData = async () => {
    setRefreshing(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    setRefreshing(false);
  };

  const handleExportDashboard = () => {
    // Simulate export functionality
    console.log('Exporting dashboard data...');
  };

  const viewOptions = [
    { id: 'overview', label: 'Overview Dashboard', icon: 'LayoutDashboard' },
    { id: 'effectiveness', label: 'Training Effectiveness', icon: 'TrendingUp' },
    { id: 'comparison', label: 'Department Comparison', icon: 'Target' },
    { id: 'roi', label: 'ROI Analysis', icon: 'DollarSign' },
    { id: 'predictive', label: 'Predictive Analytics', icon: 'Brain' },
    { id: 'reports', label: 'Custom Reports', icon: 'FileText' }
  ];

  const dateRangeOptions = [
    { value: '7days', label: 'Last 7 days' },
    { value: '30days', label: 'Last 30 days' },
    { value: '90days', label: 'Last 90 days' },
    { value: '6months', label: 'Last 6 months' },
    { value: '1year', label: 'Last year' }
  ];

  const departmentOptions = [
    { value: 'all', label: 'All Departments' },
    { value: 'production', label: 'Production Team' },
    { value: 'quality', label: 'Quality Control' },
    { value: 'maintenance', label: 'Maintenance Team' },
    { value: 'packaging', label: 'Packaging Team' },
    { value: 'laboratory', label: 'Laboratory Staff' },
    { value: 'management', label: 'Management' }
  ];

  useEffect(() => {
    // Auto-refresh data every 5 minutes
    const interval = setInterval(() => {
      if (activeView === 'overview') {
        handleRefreshData();
      }
    }, 300000);

    return () => clearInterval(interval);
  }, [activeView]);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Training Analytics & Insights - Dairy Training Matrix</title>
        <meta name="description" content="Advanced analytics and insights for training program optimization and data-driven decision making" />
      </Helmet>
      <Header onMenuToggle={handleToggleMenu} isMenuOpen={isMenuOpen} />
      <RoleBasedSidebar
        isCollapsed={isSidebarCollapsed}
        onToggleCollapse={handleToggleSidebar}
        userRole={userRole}
        className="lg:block hidden"
      />
      <main className={`pt-16 transition-all duration-200 ${isSidebarCollapsed ? 'lg:ml-16' : 'lg:ml-60'}`}>
        <div className="p-6">
          {/* Page Header */}
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8">
            <div className="mb-4 lg:mb-0">
              <div className="flex items-center space-x-3 mb-2">
                <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center">
                  <Icon name="BarChart3" size={24} className="text-accent" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-foreground">Training Analytics & Insights</h1>
                  <p className="text-sm text-muted-foreground">
                    Data-driven insights for training program optimization
                  </p>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-2 sm:space-y-0 sm:space-x-3">
              <div className="flex items-center space-x-2">
                <select
                  value={dateRange}
                  onChange={(e) => setDateRange(e?.target?.value)}
                  className="text-sm border border-border rounded-md px-3 py-2 bg-background text-foreground"
                >
                  {dateRangeOptions?.map(option => (
                    <option key={option?.value} value={option?.value}>
                      {option?.label}
                    </option>
                  ))}
                </select>

                <select
                  value={selectedDepartment}
                  onChange={(e) => setSelectedDepartment(e?.target?.value)}
                  className="text-sm border border-border rounded-md px-3 py-2 bg-background text-foreground"
                >
                  {departmentOptions?.map(option => (
                    <option key={option?.value} value={option?.value}>
                      {option?.label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleRefreshData}
                  disabled={refreshing}
                  iconName={refreshing ? 'Loader2' : 'RefreshCw'}
                  iconPosition="left"
                  className={refreshing ? 'animate-spin' : ''}
                >
                  {refreshing ? 'Refreshing...' : 'Refresh'}
                </Button>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleExportDashboard}
                  iconName="Download"
                  iconPosition="left"
                >
                  Export
                </Button>
              </div>
            </div>
          </div>

          {/* View Navigation */}
          <div className="mb-8">
            <div className="flex flex-wrap gap-2">
              {viewOptions?.map(option => (
                <Button
                  key={option?.id}
                  variant={activeView === option?.id ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setActiveView(option?.id)}
                  iconName={option?.icon}
                  iconPosition="left"
                >
                  {option?.label}
                </Button>
              ))}
            </div>
          </div>

          {/* Content Area */}
          <div className="space-y-8">
            {activeView === 'overview' && (
              <>
                {/* KPI Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {kpiData?.map((kpi, index) => (
                    <AnalyticsKPICard
                      key={index}
                      title={kpi?.title}
                      value={kpi?.value}
                      change={kpi?.change}
                      changeType={kpi?.changeType}
                      icon={kpi?.icon}
                      description={kpi?.description}
                      trend={kpi?.trend}
                      onClick={() => {
                        if (kpi?.title?.includes('Effectiveness')) setActiveView('effectiveness');
                        else if (kpi?.title?.includes('ROI')) setActiveView('roi');
                      }}
                    />
                  ))}
                </div>

                {/* Quick Charts */}
                <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
                  <TrainingEffectivenessChart />
                  <DepartmentComparisonChart />
                </div>

                {/* Recent Insights */}
                <div className="bg-card border border-border rounded-lg p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                      <Icon name="Lightbulb" size={16} className="text-primary" />
                    </div>
                    <h3 className="text-lg font-semibold text-foreground">Recent Insights</h3>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="p-4 bg-success/10 border border-success/20 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <Icon name="TrendingUp" size={16} className="text-success mt-1" />
                        <div>
                          <p className="text-sm font-medium text-success">Training Completion Improved</p>
                          <p className="text-xs text-success/80">
                            Production team training completion rate increased by 15% after implementing mobile-friendly modules.
                          </p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="p-4 bg-warning/10 border border-warning/20 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <Icon name="AlertTriangle" size={16} className="text-warning mt-1" />
                        <div>
                          <p className="text-sm font-medium text-warning">Attention Required</p>
                          <p className="text-xs text-warning/80">
                            Maintenance team has 12 overdue safety certifications that need immediate attention.
                          </p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="p-4 bg-accent/10 border border-accent/20 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <Icon name="Target" size={16} className="text-accent mt-1" />
                        <div>
                          <p className="text-sm font-medium text-accent">Goal Achievement</p>
                          <p className="text-xs text-accent/80">
                            Q4 compliance target of 90% achieved ahead of schedule with 94.2% completion rate.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}

            {activeView === 'effectiveness' && (
              <TrainingEffectivenessChart className="col-span-full" />
            )}

            {activeView === 'comparison' && (
              <DepartmentComparisonChart className="col-span-full" />
            )}

            {activeView === 'roi' && (
              <TrainingROIAnalysis className="col-span-full" />
            )}

            {activeView === 'predictive' && (
              <PredictiveAnalytics className="col-span-full" />
            )}

            {activeView === 'reports' && (
              <CustomReportBuilder className="col-span-full" />
            )}
          </div>

          {/* Footer Info */}
          <div className="mt-12 p-4 bg-muted/50 rounded-lg">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between space-y-2 sm:space-y-0">
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <Icon name="Info" size={16} />
                <span>Data refreshed every 5 minutes • Last update: {new Date()?.toLocaleTimeString()}</span>
              </div>
              
              <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                <span>© {new Date()?.getFullYear()} Dairy Training Matrix</span>
                <span>•</span>
                <span>Analytics powered by AI insights</span>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default TrainingAnalyticsInsights;