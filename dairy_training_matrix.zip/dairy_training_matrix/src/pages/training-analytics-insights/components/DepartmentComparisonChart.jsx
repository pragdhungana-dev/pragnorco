import React, { useState } from 'react';
import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ResponsiveContainer, Legend } from 'recharts';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const DepartmentComparisonChart = ({ className = '' }) => {
  const [selectedDepartments, setSelectedDepartments] = useState(['production', 'quality', 'maintenance']);
  const [metric, setMetric] = useState('overall');

  const departmentData = [
    {
      category: 'Safety Training',
      production: 92,
      quality: 96,
      maintenance: 88,
      packaging: 90,
      laboratory: 94,
      management: 98
    },
    {
      category: 'Technical Skills',
      production: 87,
      quality: 93,
      maintenance: 95,
      packaging: 85,
      laboratory: 97,
      management: 82
    },
    {
      category: 'Compliance',
      production: 94,
      quality: 98,
      maintenance: 91,
      packaging: 93,
      laboratory: 99,
      management: 96
    },
    {
      category: 'Leadership',
      production: 78,
      quality: 85,
      maintenance: 80,
      packaging: 82,
      laboratory: 88,
      management: 95
    },
    {
      category: 'Communication',
      production: 83,
      quality: 89,
      maintenance: 85,
      packaging: 87,
      laboratory: 91,
      management: 93
    },
    {
      category: 'Emergency Response',
      production: 89,
      quality: 92,
      maintenance: 94,
      packaging: 88,
      laboratory: 90,
      management: 91
    }
  ];

  const departments = [
    { id: 'production', name: 'Production Team', color: '#2563EB' },
    { id: 'quality', name: 'Quality Control', color: '#059669' },
    { id: 'maintenance', name: 'Maintenance', color: '#D97706' },
    { id: 'packaging', name: 'Packaging Team', color: '#DC2626' },
    { id: 'laboratory', name: 'Laboratory Staff', color: '#7C3AED' },
    { id: 'management', name: 'Management', color: '#0EA5E9' }
  ];

  const toggleDepartment = (deptId) => {
    setSelectedDepartments(prev => {
      if (prev?.includes(deptId)) {
        return prev?.filter(id => id !== deptId);
      } else if (prev?.length < 4) {
        return [...prev, deptId];
      }
      return prev;
    });
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload?.length) {
      return (
        <div className="bg-popover border border-border rounded-lg p-3 shadow-industrial-strong">
          <p className="font-medium text-foreground mb-2">{label}</p>
          {payload?.map((entry, index) => (
            <div key={index} className="flex items-center space-x-2 text-sm">
              <div 
                className="w-3 h-3 rounded-full" 
                style={{ backgroundColor: entry?.color }}
              />
              <span className="text-muted-foreground">{entry?.name}:</span>
              <span className="font-medium text-foreground">{entry?.value}%</span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className={`bg-card border border-border rounded-lg p-6 ${className}`}>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-success/10 rounded-lg flex items-center justify-center">
            <Icon name="Target" size={16} className="text-success" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Department Performance Comparison</h3>
            <p className="text-sm text-muted-foreground">Training effectiveness across departments</p>
          </div>
        </div>
        
        <Button
          variant="ghost"
          size="icon"
          title="Export comparison data"
        >
          <Icon name="Download" size={16} />
        </Button>
      </div>
      <div className="mb-6">
        <p className="text-sm font-medium text-foreground mb-3">Select Departments (max 4):</p>
        <div className="flex flex-wrap gap-2">
          {departments?.map(dept => (
            <Button
              key={dept?.id}
              variant={selectedDepartments?.includes(dept?.id) ? 'default' : 'outline'}
              size="sm"
              onClick={() => toggleDepartment(dept?.id)}
              disabled={!selectedDepartments?.includes(dept?.id) && selectedDepartments?.length >= 4}
              className="text-xs"
            >
              <div 
                className="w-3 h-3 rounded-full mr-2" 
                style={{ backgroundColor: dept?.color }}
              />
              {dept?.name}
            </Button>
          ))}
        </div>
      </div>
      <div className="h-96">
        <ResponsiveContainer width="100%" height="100%">
          <RadarChart data={departmentData} margin={{ top: 20, right: 80, bottom: 20, left: 80 }}>
            <PolarGrid stroke="var(--color-border)" />
            <PolarAngleAxis 
              dataKey="category" 
              tick={{ fontSize: 12, fill: 'var(--color-muted-foreground)' }}
            />
            <PolarRadiusAxis 
              angle={90} 
              domain={[0, 100]}
              tick={{ fontSize: 10, fill: 'var(--color-muted-foreground)' }}
            />
            
            {selectedDepartments?.map(deptId => {
              const dept = departments?.find(d => d?.id === deptId);
              return (
                <Radar
                  key={deptId}
                  name={dept?.name}
                  dataKey={deptId}
                  stroke={dept?.color}
                  fill={dept?.color}
                  fillOpacity={0.1}
                  strokeWidth={2}
                />
              );
            })}
            
            <Legend />
          </RadarChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-6 grid grid-cols-2 md:grid-cols-3 gap-4">
        {selectedDepartments?.map(deptId => {
          const dept = departments?.find(d => d?.id === deptId);
          const avgScore = departmentData?.reduce((sum, item) => sum + item?.[deptId], 0) / departmentData?.length;
          
          return (
            <div key={deptId} className="text-center p-3 bg-muted/50 rounded-lg">
              <div className="flex items-center justify-center space-x-2 mb-1">
                <div 
                  className="w-3 h-3 rounded-full" 
                  style={{ backgroundColor: dept?.color }}
                />
                <p className="text-sm font-medium text-foreground">{dept?.name}</p>
              </div>
              <p className="text-xl font-bold" style={{ color: dept?.color }}>
                {avgScore?.toFixed(1)}%
              </p>
              <p className="text-xs text-muted-foreground">Average Score</p>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default DepartmentComparisonChart;