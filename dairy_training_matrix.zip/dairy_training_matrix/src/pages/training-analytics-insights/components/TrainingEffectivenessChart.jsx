import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const TrainingEffectivenessChart = ({ className = '' }) => {
  const [timeRange, setTimeRange] = useState('6months');
  const [viewType, setViewType] = useState('effectiveness');

  const effectivenessData = [
    {
      month: 'Jul 2024',
      effectiveness: 87,
      completion: 94,
      retention: 82,
      satisfaction: 89
    },
    {
      month: 'Aug 2024',
      effectiveness: 91,
      completion: 96,
      retention: 85,
      satisfaction: 92
    },
    {
      month: 'Sep 2024',
      effectiveness: 89,
      completion: 93,
      retention: 88,
      satisfaction: 87
    },
    {
      month: 'Oct 2024',
      effectiveness: 93,
      completion: 97,
      retention: 91,
      satisfaction: 94
    },
    {
      month: 'Nov 2024',
      effectiveness: 88,
      completion: 95,
      retention: 86,
      satisfaction: 90
    },
    {
      month: 'Dec 2024',
      effectiveness: 95,
      completion: 98,
      retention: 93,
      satisfaction: 96
    }
  ];

  const timeRangeOptions = [
    { value: '3months', label: '3 Months' },
    { value: '6months', label: '6 Months' },
    { value: '1year', label: '1 Year' },
    { value: '2years', label: '2 Years' }
  ];

  const viewTypeOptions = [
    { value: 'effectiveness', label: 'Training Effectiveness' },
    { value: 'completion', label: 'Completion Rates' },
    { value: 'retention', label: 'Knowledge Retention' },
    { value: 'satisfaction', label: 'Satisfaction Scores' }
  ];

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload?.length) {
      return (
        <div className="bg-popover border border-border rounded-lg p-3 shadow-industrial-strong">
          <p className="font-medium text-foreground mb-2">{label}</p>
          {payload?.map((entry, index) => (
            <div key={index} className="flex items-center space-x-2 text-sm">
              <div 
                className="w-3 h-3 rounded-full" 
                style={{ backgroundColor: entry?.color }}
              />
              <span className="text-muted-foreground">{entry?.name}:</span>
              <span className="font-medium text-foreground">{entry?.value}%</span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className={`bg-card border border-border rounded-lg p-6 ${className}`}>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-accent/10 rounded-lg flex items-center justify-center">
            <Icon name="TrendingUp" size={16} className="text-accent" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Training Effectiveness Trends</h3>
            <p className="text-sm text-muted-foreground">Performance metrics over time</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e?.target?.value)}
            className="text-sm border border-border rounded-md px-3 py-1 bg-background text-foreground"
          >
            {timeRangeOptions?.map(option => (
              <option key={option?.value} value={option?.value}>
                {option?.label}
              </option>
            ))}
          </select>
          
          <Button
            variant="ghost"
            size="icon"
            title="Export chart data"
          >
            <Icon name="Download" size={16} />
          </Button>
        </div>
      </div>
      <div className="mb-4">
        <div className="flex flex-wrap gap-2">
          {viewTypeOptions?.map(option => (
            <Button
              key={option?.value}
              variant={viewType === option?.value ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewType(option?.value)}
            >
              {option?.label}
            </Button>
          ))}
        </div>
      </div>
      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={effectivenessData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
            <XAxis 
              dataKey="month" 
              stroke="var(--color-muted-foreground)"
              fontSize={12}
            />
            <YAxis 
              stroke="var(--color-muted-foreground)"
              fontSize={12}
              domain={[0, 100]}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            
            {viewType === 'effectiveness' && (
              <Bar 
                dataKey="effectiveness" 
                name="Effectiveness Score"
                fill="var(--color-primary)" 
                radius={[4, 4, 0, 0]}
              />
            )}
            
            {viewType === 'completion' && (
              <Bar 
                dataKey="completion" 
                name="Completion Rate"
                fill="var(--color-success)" 
                radius={[4, 4, 0, 0]}
              />
            )}
            
            {viewType === 'retention' && (
              <Bar 
                dataKey="retention" 
                name="Knowledge Retention"
                fill="var(--color-accent)" 
                radius={[4, 4, 0, 0]}
              />
            )}
            
            {viewType === 'satisfaction' && (
              <Bar 
                dataKey="satisfaction" 
                name="Satisfaction Score"
                fill="var(--color-warning)" 
                radius={[4, 4, 0, 0]}
              />
            )}
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="text-center">
          <p className="text-2xl font-bold text-primary">91.5%</p>
          <p className="text-sm text-muted-foreground">Avg Effectiveness</p>
        </div>
        <div className="text-center">
          <p className="text-2xl font-bold text-success">95.5%</p>
          <p className="text-sm text-muted-foreground">Avg Completion</p>
        </div>
        <div className="text-center">
          <p className="text-2xl font-bold text-accent">87.5%</p>
          <p className="text-sm text-muted-foreground">Avg Retention</p>
        </div>
        <div className="text-center">
          <p className="text-2xl font-bold text-warning">91.3%</p>
          <p className="text-sm text-muted-foreground">Avg Satisfaction</p>
        </div>
      </div>
    </div>
  );
};

export default TrainingEffectivenessChart;