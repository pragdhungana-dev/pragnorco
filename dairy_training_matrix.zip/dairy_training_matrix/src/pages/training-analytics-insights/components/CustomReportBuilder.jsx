import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import { Checkbox } from '../../../components/ui/Checkbox';

const CustomReportBuilder = ({ className = '' }) => {
  const [reportConfig, setReportConfig] = useState({
    name: '',
    description: '',
    schedule: 'manual',
    format: 'pdf',
    recipients: [],
    filters: {
      dateRange: '30days',
      departments: [],
      trainingTypes: [],
      employeeGroups: []
    },
    metrics: [],
    visualizations: []
  });

  const [activeTab, setActiveTab] = useState('basic');
  const [savedReports, setSavedReports] = useState([
    {
      id: 1,
      name: 'Monthly Compliance Summary',
      description: 'Comprehensive compliance status across all departments',
      schedule: 'monthly',
      lastRun: '2024-12-15',
      recipients: ['manager@dairy.com', 'hr@dairy.com']
    },
    {
      id: 2,
      name: 'Training Effectiveness Report',
      description: 'Detailed analysis of training program effectiveness',
      schedule: 'quarterly',
      lastRun: '2024-12-01',
      recipients: ['training@dairy.com']
    },
    {
      id: 3,
      name: 'Safety Training Dashboard',
      description: 'Real-time safety training status and alerts',
      schedule: 'weekly',
      lastRun: '2024-12-20',
      recipients: ['safety@dairy.com', 'operations@dairy.com']
    }
  ]);

  const availableMetrics = [
    { id: 'completion_rate', name: 'Training Completion Rate', category: 'Performance' },
    { id: 'compliance_score', name: 'Compliance Score', category: 'Compliance' },
    { id: 'overdue_training', name: 'Overdue Training Count', category: 'Compliance' },
    { id: 'training_hours', name: 'Total Training Hours', category: 'Performance' },
    { id: 'cost_per_employee', name: 'Cost Per Employee', category: 'Financial' },
    { id: 'roi_metrics', name: 'ROI Metrics', category: 'Financial' },
    { id: 'employee_satisfaction', name: 'Employee Satisfaction', category: 'Quality' },
    { id: 'knowledge_retention', name: 'Knowledge Retention Rate', category: 'Quality' }
  ];

  const availableVisualizations = [
    { id: 'bar_chart', name: 'Bar Chart', icon: 'BarChart3' },
    { id: 'line_chart', name: 'Line Chart', icon: 'TrendingUp' },
    { id: 'pie_chart', name: 'Pie Chart', icon: 'PieChart' },
    { id: 'table', name: 'Data Table', icon: 'Table' },
    { id: 'heatmap', name: 'Heat Map', icon: 'Grid3X3' },
    { id: 'gauge', name: 'Gauge Chart', icon: 'Gauge' }
  ];

  const departments = [
    'Production Team', 'Quality Control', 'Maintenance Team', 
    'Packaging Team', 'Laboratory Staff', 'Management'
  ];

  const trainingTypes = [
    'Safety Training', 'HACCP & Food Safety', 'Equipment Operation',
    'Quality Control', 'Emergency Response', 'Regulatory Compliance'
  ];

  const handleMetricToggle = (metricId) => {
    setReportConfig(prev => ({
      ...prev,
      metrics: prev?.metrics?.includes(metricId)
        ? prev?.metrics?.filter(id => id !== metricId)
        : [...prev?.metrics, metricId]
    }));
  };

  const handleVisualizationToggle = (vizId) => {
    setReportConfig(prev => ({
      ...prev,
      visualizations: prev?.visualizations?.includes(vizId)
        ? prev?.visualizations?.filter(id => id !== vizId)
        : [...prev?.visualizations, vizId]
    }));
  };

  const handleDepartmentToggle = (dept) => {
    setReportConfig(prev => ({
      ...prev,
      filters: {
        ...prev?.filters,
        departments: prev?.filters?.departments?.includes(dept)
          ? prev?.filters?.departments?.filter(d => d !== dept)
          : [...prev?.filters?.departments, dept]
      }
    }));
  };

  const handleSaveReport = () => {
    if (reportConfig?.name?.trim()) {
      const newReport = {
        id: savedReports?.length + 1,
        name: reportConfig?.name,
        description: reportConfig?.description,
        schedule: reportConfig?.schedule,
        lastRun: new Date()?.toISOString()?.split('T')?.[0],
        recipients: reportConfig?.recipients
      };
      setSavedReports(prev => [...prev, newReport]);
      
      // Reset form
      setReportConfig({
        name: '',
        description: '',
        schedule: 'manual',
        format: 'pdf',
        recipients: [],
        filters: {
          dateRange: '30days',
          departments: [],
          trainingTypes: [],
          employeeGroups: []
        },
        metrics: [],
        visualizations: []
      });
    }
  };

  const handleRunReport = (reportId) => {
    setSavedReports(prev => prev?.map(report => 
      report?.id === reportId 
        ? { ...report, lastRun: new Date()?.toISOString()?.split('T')?.[0] }
        : report
    ));
  };

  const handleDeleteReport = (reportId) => {
    setSavedReports(prev => prev?.filter(report => report?.id !== reportId));
  };

  return (
    <div className={`bg-card border border-border rounded-lg p-6 ${className}`}>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon name="FileText" size={16} className="text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Custom Report Builder</h3>
            <p className="text-sm text-muted-foreground">Create and manage custom analytics reports</p>
          </div>
        </div>
      </div>
      <div className="mb-6">
        <div className="flex space-x-1 bg-muted rounded-lg p-1">
          <Button
            variant={activeTab === 'basic' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setActiveTab('basic')}
            className="flex-1"
          >
            Basic Settings
          </Button>
          <Button
            variant={activeTab === 'metrics' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setActiveTab('metrics')}
            className="flex-1"
          >
            Metrics & Data
          </Button>
          <Button
            variant={activeTab === 'saved' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setActiveTab('saved')}
            className="flex-1"
          >
            Saved Reports
          </Button>
        </div>
      </div>
      {activeTab === 'basic' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="Report Name"
              type="text"
              placeholder="Enter report name"
              value={reportConfig?.name}
              onChange={(e) => setReportConfig(prev => ({ ...prev, name: e?.target?.value }))}
              required
            />
            
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Schedule</label>
              <select
                value={reportConfig?.schedule}
                onChange={(e) => setReportConfig(prev => ({ ...prev, schedule: e?.target?.value }))}
                className="w-full text-sm border border-border rounded-md px-3 py-2 bg-background text-foreground"
              >
                <option value="manual">Manual</option>
                <option value="daily">Daily</option>
                <option value="weekly">Weekly</option>
                <option value="monthly">Monthly</option>
                <option value="quarterly">Quarterly</option>
              </select>
            </div>
          </div>

          <Input
            label="Description"
            type="text"
            placeholder="Brief description of the report"
            value={reportConfig?.description}
            onChange={(e) => setReportConfig(prev => ({ ...prev, description: e?.target?.value }))}
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Export Format</label>
              <select
                value={reportConfig?.format}
                onChange={(e) => setReportConfig(prev => ({ ...prev, format: e?.target?.value }))}
                className="w-full text-sm border border-border rounded-md px-3 py-2 bg-background text-foreground"
              >
                <option value="pdf">PDF</option>
                <option value="excel">Excel</option>
                <option value="csv">CSV</option>
                <option value="powerpoint">PowerPoint</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Date Range</label>
              <select
                value={reportConfig?.filters?.dateRange}
                onChange={(e) => setReportConfig(prev => ({
                  ...prev,
                  filters: { ...prev?.filters, dateRange: e?.target?.value }
                }))}
                className="w-full text-sm border border-border rounded-md px-3 py-2 bg-background text-foreground"
              >
                <option value="7days">Last 7 days</option>
                <option value="30days">Last 30 days</option>
                <option value="90days">Last 90 days</option>
                <option value="6months">Last 6 months</option>
                <option value="1year">Last year</option>
                <option value="custom">Custom range</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-3">Filter by Departments</label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {departments?.map(dept => (
                <Checkbox
                  key={dept}
                  label={dept}
                  checked={reportConfig?.filters?.departments?.includes(dept)}
                  onChange={() => handleDepartmentToggle(dept)}
                />
              ))}
            </div>
          </div>
        </div>
      )}
      {activeTab === 'metrics' && (
        <div className="space-y-6">
          <div>
            <h4 className="text-sm font-semibold text-foreground mb-3">Select Metrics to Include</h4>
            <div className="space-y-3">
              {['Performance', 'Compliance', 'Financial', 'Quality']?.map(category => (
                <div key={category}>
                  <p className="text-xs font-medium text-muted-foreground mb-2">{category}</p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 ml-4">
                    {availableMetrics?.filter(metric => metric?.category === category)?.map(metric => (
                        <Checkbox
                          key={metric?.id}
                          label={metric?.name}
                          checked={reportConfig?.metrics?.includes(metric?.id)}
                          onChange={() => handleMetricToggle(metric?.id)}
                        />
                      ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-foreground mb-3">Visualization Types</h4>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {availableVisualizations?.map(viz => (
                <div
                  key={viz?.id}
                  className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                    reportConfig?.visualizations?.includes(viz?.id)
                      ? 'border-primary bg-primary/10' :'border-border hover:border-primary/50'
                  }`}
                  onClick={() => handleVisualizationToggle(viz?.id)}
                >
                  <div className="flex items-center space-x-2">
                    <Icon name={viz?.icon} size={16} className="text-primary" />
                    <span className="text-sm font-medium text-foreground">{viz?.name}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-end space-x-3">
            <Button
              variant="outline"
              onClick={() => setActiveTab('basic')}
            >
              Back to Settings
            </Button>
            <Button
              variant="default"
              onClick={handleSaveReport}
              disabled={!reportConfig?.name?.trim() || reportConfig?.metrics?.length === 0}
            >
              Save Report Template
            </Button>
          </div>
        </div>
      )}
      {activeTab === 'saved' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-semibold text-foreground">Saved Report Templates</h4>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setActiveTab('basic')}
              iconName="Plus"
              iconPosition="left"
            >
              New Report
            </Button>
          </div>

          <div className="space-y-3">
            {savedReports?.map(report => (
              <div key={report?.id} className="p-4 border border-border rounded-lg">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h5 className="text-sm font-semibold text-foreground">{report?.name}</h5>
                    <p className="text-xs text-muted-foreground">{report?.description}</p>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleRunReport(report?.id)}
                      title="Run report now"
                    >
                      <Icon name="Play" size={14} />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      title="Edit report"
                    >
                      <Icon name="Edit" size={14} />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDeleteReport(report?.id)}
                      title="Delete report"
                    >
                      <Icon name="Trash2" size={14} />
                    </Button>
                  </div>
                </div>
                
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <div className="flex items-center space-x-4">
                    <span className="flex items-center space-x-1">
                      <Icon name="Clock" size={12} />
                      <span>Schedule: {report?.schedule}</span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <Icon name="Calendar" size={12} />
                      <span>Last run: {report?.lastRun}</span>
                    </span>
                  </div>
                  
                  <span className="flex items-center space-x-1">
                    <Icon name="Users" size={12} />
                    <span>{report?.recipients?.length} recipients</span>
                  </span>
                </div>
              </div>
            ))}
          </div>

          {savedReports?.length === 0 && (
            <div className="text-center py-8">
              <Icon name="FileText" size={48} className="text-muted-foreground mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">No saved reports yet</p>
              <p className="text-xs text-muted-foreground">Create your first custom report template</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default CustomReportBuilder;