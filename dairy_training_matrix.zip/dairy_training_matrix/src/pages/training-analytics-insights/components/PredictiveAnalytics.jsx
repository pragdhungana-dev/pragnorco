import React, { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, ReferenceLine } from 'recharts';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const PredictiveAnalytics = ({ className = '' }) => {
  const [predictionType, setPredictionType] = useState('demand');
  const [timeHorizon, setTimeHorizon] = useState('6months');

  const demandPredictionData = [
    { month: 'Jan 2024', actual: 45, predicted: null, confidence: null },
    { month: 'Feb 2024', actual: 52, predicted: null, confidence: null },
    { month: 'Mar 2024', actual: 48, predicted: null, confidence: null },
    { month: 'Apr 2024', actual: 61, predicted: null, confidence: null },
    { month: 'May 2024', actual: 58, predicted: null, confidence: null },
    { month: 'Jun 2024', actual: 55, predicted: null, confidence: null },
    { month: 'Jul 2024', actual: 63, predicted: null, confidence: null },
    { month: 'Aug 2024', actual: 59, predicted: null, confidence: null },
    { month: 'Sep 2024', actual: 67, predicted: null, confidence: null },
    { month: 'Oct 2024', actual: 64, predicted: null, confidence: null },
    { month: 'Nov 2024', actual: 71, predicted: null, confidence: null },
    { month: 'Dec 2024', actual: 68, predicted: null, confidence: null },
    { month: 'Jan 2025', actual: null, predicted: 72, confidence: 85 },
    { month: 'Feb 2025', actual: null, predicted: 75, confidence: 82 },
    { month: 'Mar 2025', actual: null, predicted: 69, confidence: 78 },
    { month: 'Apr 2025', actual: null, predicted: 78, confidence: 75 },
    { month: 'May 2025', actual: null, predicted: 74, confidence: 72 },
    { month: 'Jun 2025', actual: null, predicted: 71, confidence: 70 }
  ];

  const riskPredictionData = [
    { department: 'Production Team', riskScore: 23, trend: 'increasing', priority: 'medium' },
    { department: 'Quality Control', riskScore: 12, trend: 'stable', priority: 'low' },
    { department: 'Maintenance Team', riskScore: 34, trend: 'increasing', priority: 'high' },
    { department: 'Packaging Team', riskScore: 18, trend: 'decreasing', priority: 'low' },
    { department: 'Laboratory Staff', riskScore: 8, trend: 'stable', priority: 'low' },
    { department: 'Management', riskScore: 15, trend: 'decreasing', priority: 'low' }
  ];

  const complianceRiskData = [
    { 
      category: 'Safety Training Expiry', 
      riskLevel: 'high', 
      affectedEmployees: 23, 
      daysToExpiry: 15,
      recommendation: 'Schedule immediate refresher training for affected employees'
    },
    { 
      category: 'HACCP Certification', 
      riskLevel: 'medium', 
      affectedEmployees: 8, 
      daysToExpiry: 45,
      recommendation: 'Plan renewal training sessions within next 30 days'
    },
    { 
      category: 'Equipment Operation', 
      riskLevel: 'low', 
      affectedEmployees: 12, 
      daysToExpiry: 90,
      recommendation: 'Monitor and schedule training as needed'
    }
  ];

  const getRiskColor = (level) => {
    switch (level) {
      case 'high': return 'text-error';
      case 'medium': return 'text-warning';
      case 'low': return 'text-success';
      default: return 'text-muted-foreground';
    }
  };

  const getRiskBgColor = (level) => {
    switch (level) {
      case 'high': return 'bg-error/10 border-error/20';
      case 'medium': return 'bg-warning/10 border-warning/20';
      case 'low': return 'bg-success/10 border-success/20';
      default: return 'bg-muted/10 border-muted/20';
    }
  };

  const getTrendIcon = (trend) => {
    switch (trend) {
      case 'increasing': return 'TrendingUp';
      case 'decreasing': return 'TrendingDown';
      case 'stable': return 'Minus';
      default: return 'Minus';
    }
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload?.length) {
      return (
        <div className="bg-popover border border-border rounded-lg p-3 shadow-industrial-strong">
          <p className="font-medium text-foreground mb-2">{label}</p>
          {payload?.map((entry, index) => (
            <div key={index} className="flex items-center space-x-2 text-sm">
              <div 
                className="w-3 h-3 rounded-full" 
                style={{ backgroundColor: entry?.color }}
              />
              <span className="text-muted-foreground">{entry?.name}:</span>
              <span className="font-medium text-foreground">
                {entry?.value}
                {entry?.name === 'Confidence' ? '%' : ' sessions'}
              </span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className={`bg-card border border-border rounded-lg p-6 ${className}`}>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-accent/10 rounded-lg flex items-center justify-center">
            <Icon name="Brain" size={16} className="text-accent" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Predictive Analytics</h3>
            <p className="text-sm text-muted-foreground">AI-powered insights and forecasting</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <select
            value={timeHorizon}
            onChange={(e) => setTimeHorizon(e?.target?.value)}
            className="text-sm border border-border rounded-md px-3 py-1 bg-background text-foreground"
          >
            <option value="3months">3 Months</option>
            <option value="6months">6 Months</option>
            <option value="1year">1 Year</option>
          </select>
          
          <Button
            variant="ghost"
            size="icon"
            title="Export predictions"
          >
            <Icon name="Download" size={16} />
          </Button>
        </div>
      </div>
      <div className="mb-6">
        <div className="flex flex-wrap gap-2">
          <Button
            variant={predictionType === 'demand' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setPredictionType('demand')}
          >
            Training Demand
          </Button>
          <Button
            variant={predictionType === 'risk' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setPredictionType('risk')}
          >
            Risk Assessment
          </Button>
          <Button
            variant={predictionType === 'compliance' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setPredictionType('compliance')}
          >
            Compliance Risks
          </Button>
        </div>
      </div>
      {predictionType === 'demand' && (
        <div>
          <div className="h-80 mb-6">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={demandPredictionData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis 
                  dataKey="month" 
                  stroke="var(--color-muted-foreground)"
                  fontSize={12}
                />
                <YAxis 
                  stroke="var(--color-muted-foreground)"
                  fontSize={12}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <ReferenceLine x="Dec 2024" stroke="var(--color-muted-foreground)" strokeDasharray="2 2" />
                <Line 
                  type="monotone" 
                  dataKey="actual" 
                  name="Actual Demand"
                  stroke="var(--color-primary)" 
                  strokeWidth={2}
                  dot={{ fill: 'var(--color-primary)', strokeWidth: 2, r: 4 }}
                  connectNulls={false}
                />
                <Line 
                  type="monotone" 
                  dataKey="predicted" 
                  name="Predicted Demand"
                  stroke="var(--color-accent)" 
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  dot={{ fill: 'var(--color-accent)', strokeWidth: 2, r: 4 }}
                  connectNulls={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
          
          <div className="p-4 bg-accent/10 border border-accent/20 rounded-lg">
            <div className="flex items-start space-x-3">
              <Icon name="Lightbulb" size={20} className="text-accent mt-1" />
              <div>
                <p className="text-sm font-semibold text-accent mb-1">Prediction Insights</p>
                <p className="text-xs text-accent/80">
                  Training demand is expected to increase by 15% in Q1 2025, primarily driven by new equipment installations and seasonal workforce expansion. Consider scheduling additional training sessions in January and April.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
      {predictionType === 'risk' && (
        <div className="space-y-4">
          <h4 className="text-sm font-semibold text-foreground">Department Risk Scores</h4>
          {riskPredictionData?.map((dept, index) => (
            <div key={index} className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className={`w-3 h-3 rounded-full ${
                  dept?.riskScore > 30 ? 'bg-error' : 
                  dept?.riskScore > 15 ? 'bg-warning' : 'bg-success'
                }`} />
                <span className="text-sm font-medium text-foreground">{dept?.department}</span>
              </div>
              
              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <p className={`text-sm font-bold ${
                    dept?.riskScore > 30 ? 'text-error' : 
                    dept?.riskScore > 15 ? 'text-warning' : 'text-success'
                  }`}>
                    {dept?.riskScore}%
                  </p>
                  <p className="text-xs text-muted-foreground">Risk Score</p>
                </div>
                
                <div className="flex items-center space-x-1">
                  <Icon 
                    name={getTrendIcon(dept?.trend)} 
                    size={14} 
                    className={
                      dept?.trend === 'increasing' ? 'text-error' :
                      dept?.trend === 'decreasing' ? 'text-success' : 'text-muted-foreground'
                    }
                  />
                  <span className="text-xs text-muted-foreground capitalize">{dept?.trend}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      {predictionType === 'compliance' && (
        <div className="space-y-4">
          <h4 className="text-sm font-semibold text-foreground">Compliance Risk Alerts</h4>
          {complianceRiskData?.map((risk, index) => (
            <div key={index} className={`p-4 border rounded-lg ${getRiskBgColor(risk?.riskLevel)}`}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <Icon 
                    name="AlertTriangle" 
                    size={16} 
                    className={getRiskColor(risk?.riskLevel)}
                  />
                  <div>
                    <p className="text-sm font-semibold text-foreground">{risk?.category}</p>
                    <p className="text-xs text-muted-foreground">
                      {risk?.affectedEmployees} employees • {risk?.daysToExpiry} days remaining
                    </p>
                  </div>
                </div>
                
                <span className={`text-xs font-medium px-2 py-1 rounded-full ${
                  risk?.riskLevel === 'high' ? 'bg-error text-error-foreground' :
                  risk?.riskLevel === 'medium' ? 'bg-warning text-warning-foreground' :
                  'bg-success text-success-foreground'
                } capitalize`}>
                  {risk?.riskLevel} Risk
                </span>
              </div>
              
              <p className="text-xs text-foreground bg-background/50 p-2 rounded">
                <Icon name="Lightbulb" size={12} className="inline mr-1" />
                {risk?.recommendation}
              </p>
            </div>
          ))}
          
          <div className="mt-6 p-4 bg-primary/10 border border-primary/20 rounded-lg">
            <div className="flex items-start space-x-3">
              <Icon name="Shield" size={20} className="text-primary mt-1" />
              <div>
                <p className="text-sm font-semibold text-primary mb-1">Proactive Recommendations</p>
                <p className="text-xs text-primary/80">
                  Based on historical patterns, implementing a 30-day advance notification system could reduce compliance risks by 40% and improve training completion rates.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PredictiveAnalytics;