import React, { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, AreaChart, Area } from 'recharts';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const TrainingROIAnalysis = ({ className = '' }) => {
  const [viewMode, setViewMode] = useState('roi');
  const [timeframe, setTimeframe] = useState('quarterly');

  const roiData = [
    {
      period: 'Q1 2024',
      investment: 45000,
      savings: 62000,
      roi: 137.8,
      productivity: 12.5,
      incidents: -8.2
    },
    {
      period: 'Q2 2024',
      investment: 52000,
      savings: 78000,
      roi: 150.0,
      productivity: 15.3,
      incidents: -12.1
    },
    {
      period: 'Q3 2024',
      investment: 48000,
      savings: 71000,
      roi: 147.9,
      productivity: 18.7,
      incidents: -15.6
    },
    {
      period: 'Q4 2024',
      investment: 55000,
      savings: 89000,
      roi: 161.8,
      productivity: 22.1,
      incidents: -18.9
    }
  ];

  const costBreakdown = [
    { category: 'Instructor Fees', amount: 85000, percentage: 42.5 },
    { category: 'Training Materials', amount: 35000, percentage: 17.5 },
    { category: 'Facility Costs', amount: 28000, percentage: 14.0 },
    { category: 'Employee Time', amount: 32000, percentage: 16.0 },
    { category: 'Technology & Tools', amount: 20000, percentage: 10.0 }
  ];

  const benefitsData = [
    { benefit: 'Reduced Incidents', value: 18.9, unit: '% decrease' },
    { benefit: 'Productivity Gain', value: 22.1, unit: '% increase' },
    { benefit: 'Quality Improvement', value: 15.7, unit: '% increase' },
    { benefit: 'Employee Retention', value: 12.3, unit: '% increase' },
    { benefit: 'Compliance Score', value: 8.5, unit: '% increase' }
  ];

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload?.length) {
      return (
        <div className="bg-popover border border-border rounded-lg p-3 shadow-industrial-strong">
          <p className="font-medium text-foreground mb-2">{label}</p>
          {payload?.map((entry, index) => (
            <div key={index} className="flex items-center justify-between space-x-4 text-sm">
              <div className="flex items-center space-x-2">
                <div 
                  className="w-3 h-3 rounded-full" 
                  style={{ backgroundColor: entry?.color }}
                />
                <span className="text-muted-foreground">{entry?.name}:</span>
              </div>
              <span className="font-medium text-foreground">
                {entry?.name === 'ROI' ? `${entry?.value}%` : 
                 entry?.name?.includes('$') ? `$${entry?.value?.toLocaleString()}` : 
                 `${entry?.value}%`}
              </span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className={`bg-card border border-border rounded-lg p-6 ${className}`}>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-warning/10 rounded-lg flex items-center justify-center">
            <Icon name="DollarSign" size={16} className="text-warning" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Training ROI Analysis</h3>
            <p className="text-sm text-muted-foreground">Investment returns and cost-benefit analysis</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <select
            value={timeframe}
            onChange={(e) => setTimeframe(e?.target?.value)}
            className="text-sm border border-border rounded-md px-3 py-1 bg-background text-foreground"
          >
            <option value="monthly">Monthly</option>
            <option value="quarterly">Quarterly</option>
            <option value="yearly">Yearly</option>
          </select>
          
          <Button
            variant="ghost"
            size="icon"
            title="Export ROI analysis"
          >
            <Icon name="Download" size={16} />
          </Button>
        </div>
      </div>
      <div className="mb-6">
        <div className="flex flex-wrap gap-2">
          <Button
            variant={viewMode === 'roi' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setViewMode('roi')}
          >
            ROI Trends
          </Button>
          <Button
            variant={viewMode === 'investment' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setViewMode('investment')}
          >
            Investment vs Savings
          </Button>
          <Button
            variant={viewMode === 'benefits' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setViewMode('benefits')}
          >
            Impact Metrics
          </Button>
        </div>
      </div>
      {viewMode === 'roi' && (
        <div className="h-80 mb-6">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={roiData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis 
                dataKey="period" 
                stroke="var(--color-muted-foreground)"
                fontSize={12}
              />
              <YAxis 
                stroke="var(--color-muted-foreground)"
                fontSize={12}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="roi" 
                name="ROI"
                stroke="var(--color-success)" 
                strokeWidth={3}
                dot={{ fill: 'var(--color-success)', strokeWidth: 2, r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
      {viewMode === 'investment' && (
        <div className="h-80 mb-6">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={roiData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis 
                dataKey="period" 
                stroke="var(--color-muted-foreground)"
                fontSize={12}
              />
              <YAxis 
                stroke="var(--color-muted-foreground)"
                fontSize={12}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <Area 
                type="monotone" 
                dataKey="investment" 
                name="Investment ($)"
                stackId="1"
                stroke="var(--color-error)" 
                fill="var(--color-error)"
                fillOpacity={0.6}
              />
              <Area 
                type="monotone" 
                dataKey="savings" 
                name="Savings ($)"
                stackId="2"
                stroke="var(--color-success)" 
                fill="var(--color-success)"
                fillOpacity={0.6}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      )}
      {viewMode === 'benefits' && (
        <div className="h-80 mb-6">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={roiData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis 
                dataKey="period" 
                stroke="var(--color-muted-foreground)"
                fontSize={12}
              />
              <YAxis 
                stroke="var(--color-muted-foreground)"
                fontSize={12}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="productivity" 
                name="Productivity Gain (%)"
                stroke="var(--color-primary)" 
                strokeWidth={2}
                dot={{ fill: 'var(--color-primary)', strokeWidth: 2, r: 4 }}
              />
              <Line 
                type="monotone" 
                dataKey="incidents" 
                name="Incident Reduction (%)"
                stroke="var(--color-accent)" 
                strokeWidth={2}
                dot={{ fill: 'var(--color-accent)', strokeWidth: 2, r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h4 className="text-sm font-semibold text-foreground mb-3">Cost Breakdown (2024)</h4>
          <div className="space-y-3">
            {costBreakdown?.map((item, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 bg-primary rounded-full" />
                  <span className="text-sm text-foreground">{item?.category}</span>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-foreground">
                    ${item?.amount?.toLocaleString()}
                  </p>
                  <p className="text-xs text-muted-foreground">{item?.percentage}%</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h4 className="text-sm font-semibold text-foreground mb-3">Key Benefits Achieved</h4>
          <div className="space-y-3">
            {benefitsData?.map((item, index) => (
              <div key={index} className="flex items-center justify-between">
                <span className="text-sm text-foreground">{item?.benefit}</span>
                <div className="text-right">
                  <p className="text-sm font-bold text-success">
                    {item?.value > 0 ? '+' : ''}{item?.value}
                  </p>
                  <p className="text-xs text-muted-foreground">{item?.unit}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="mt-6 p-4 bg-success/10 border border-success/20 rounded-lg">
        <div className="flex items-center space-x-3">
          <Icon name="TrendingUp" size={20} className="text-success" />
          <div>
            <p className="text-sm font-semibold text-success">Overall ROI Performance</p>
            <p className="text-xs text-success/80">
              Training investments generated an average ROI of 149.4% in 2024, with total savings of $300,000 against investments of $200,000.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrainingROIAnalysis;