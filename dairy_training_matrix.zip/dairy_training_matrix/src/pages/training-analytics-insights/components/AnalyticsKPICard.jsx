import React from 'react';
import Icon from '../../../components/AppIcon';

const AnalyticsKPICard = ({ 
  title, 
  value, 
  change, 
  changeType = 'positive', 
  icon, 
  description,
  trend = [],
  onClick,
  className = '' 
}) => {
  const getChangeColor = () => {
    if (changeType === 'positive') return 'text-success';
    if (changeType === 'negative') return 'text-error';
    return 'text-muted-foreground';
  };

  const getChangeIcon = () => {
    if (changeType === 'positive') return 'TrendingUp';
    if (changeType === 'negative') return 'TrendingDown';
    return 'Minus';
  };

  return (
    <div 
      className={`bg-card border border-border rounded-lg p-6 hover:shadow-industrial-strong transition-all duration-200 cursor-pointer ${className}`}
      onClick={onClick}
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon name={icon} size={20} className="text-primary" />
          </div>
          <div>
            <h3 className="text-sm font-medium text-muted-foreground">{title}</h3>
            <p className="text-2xl font-bold text-foreground mt-1">{value}</p>
          </div>
        </div>
        {change && (
          <div className={`flex items-center space-x-1 ${getChangeColor()}`}>
            <Icon name={getChangeIcon()} size={14} />
            <span className="text-sm font-medium">{change}</span>
          </div>
        )}
      </div>
      {description && (
        <p className="text-sm text-muted-foreground mb-3">{description}</p>
      )}
      {trend?.length > 0 && (
        <div className="flex items-center space-x-1">
          {trend?.slice(-7)?.map((point, index) => (
            <div
              key={index}
              className={`w-1 rounded-full ${
                point > 0 ? 'bg-success' : point < 0 ? 'bg-error' : 'bg-muted'
              }`}
              style={{ height: `${Math.abs(point) * 2 + 4}px` }}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default AnalyticsKPICard;