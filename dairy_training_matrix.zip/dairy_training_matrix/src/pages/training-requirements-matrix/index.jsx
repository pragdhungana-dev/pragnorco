import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import RoleBasedSidebar from '../../components/ui/RoleBasedSidebar';
import MatrixGrid from './components/MatrixGrid';
import RoleSidebar from './components/RoleSidebar';
import MatrixToolbar from './components/MatrixToolbar';
import SystemIntegrationStatus from './components/SystemIntegrationStatus';
import TrainingCalendarPoster from './components/TrainingCalendarPoster';
import EditableCoursesSection from './components/EditableCoursesSection';
import EditableDepartmentsSection from './components/EditableDepartmentsSection';

const TrainingRequirementsMatrix = () => {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [roleSidebarCollapsed, setRoleSidebarCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [selectedCells, setSelectedCells] = useState(new Set());
  const [selectedRoles, setSelectedRoles] = useState(new Set());
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    facility: 'all',
    department: 'all',
    compliance: 'all',
    savedView: ''
  });

  // Editable data states - start with empty arrays
  const [mandatoryTrainings, setMandatoryTrainings] = useState([]);
  const [trainingCategories, setTrainingCategories] = useState([]);
  const [roleCategories, setRoleCategories] = useState([]);
  const [requirements, setRequirements] = useState([]);
  const [savedViews, setSavedViews] = useState([]);

  // Calendar poster handlers
  const handleAddTraining = useCallback((training) => {
    setMandatoryTrainings(prev => [...prev, training]);
  }, []);

  const handleEditTraining = useCallback((updatedTraining) => {
    setMandatoryTrainings(prev => 
      prev?.map(training => training?.id === updatedTraining?.id ? updatedTraining : training)
    );
  }, []);

  const handleDeleteTraining = useCallback((trainingId) => {
    setMandatoryTrainings(prev => prev?.filter(training => training?.id !== trainingId));
  }, []);

  // Course management handlers
  const handleAddCourse = useCallback((course) => {
    setTrainingCategories(prev => [...prev, course]);
  }, []);

  const handleEditCourse = useCallback((updatedCourse) => {
    setTrainingCategories(prev => 
      prev?.map(course => course?.id === updatedCourse?.id ? updatedCourse : course)
    );
  }, []);

  const handleDeleteCourse = useCallback((courseId) => {
    setTrainingCategories(prev => prev?.filter(course => course?.id !== courseId));
    // Also remove related requirements
    setRequirements(prev => prev?.filter(req => req?.categoryId !== courseId));
  }, []);

  // Department management handlers
  const handleAddDepartment = useCallback((department) => {
    setRoleCategories(prev => [...prev, department]);
  }, []);

  const handleEditDepartment = useCallback((updatedDepartment) => {
    setRoleCategories(prev => 
      prev?.map(dept => dept?.id === updatedDepartment?.id ? updatedDepartment : dept)
    );
  }, []);

  const handleDeleteDepartment = useCallback((departmentId) => {
    const department = roleCategories?.find(dept => dept?.id === departmentId);
    setRoleCategories(prev => prev?.filter(dept => dept?.id !== departmentId));
    
    // Remove requirements for all roles in this department
    if (department?.roles) {
      const roleIds = department?.roles?.map(role => role?.id);
      setRequirements(prev => prev?.filter(req => !roleIds?.includes(req?.roleId)));
    }
  }, [roleCategories]);

  // Role management handlers
  const handleAddRole = useCallback((departmentId, role) => {
    setRoleCategories(prev => 
      prev?.map(dept => 
        dept?.id === departmentId 
          ? { ...dept, roles: [...(dept?.roles || []), role] }
          : dept
      )
    );
  }, []);

  const handleEditRole = useCallback((updatedRole) => {
    setRoleCategories(prev => 
      prev?.map(dept => ({
        ...dept,
        roles: dept?.roles?.map(role => 
          role?.id === updatedRole?.id ? updatedRole : role
        )
      }))
    );
  }, []);

  const handleDeleteRole = useCallback((departmentId, roleId) => {
    setRoleCategories(prev => 
      prev?.map(dept => 
        dept?.id === departmentId 
          ? { ...dept, roles: dept?.roles?.filter(role => role?.id !== roleId) }
          : dept
      )
    );
    
    // Remove requirements for this role
    setRequirements(prev => prev?.filter(req => req?.roleId !== roleId));
  }, []);

  // Get all roles for the matrix
  const allRoles = useMemo(() => {
    return roleCategories?.flatMap(category => category?.roles?.map(role => ({
      ...role,
      department: category?.id
    }))) || [];
  }, [roleCategories]);

  // Filter roles based on search and filters
  const filteredRoles = useMemo(() => {
    let filtered = allRoles;

    if (searchQuery) {
      filtered = filtered?.filter(role =>
        role?.name?.toLowerCase()?.includes(searchQuery?.toLowerCase())
      );
    }

    if (filters?.department !== 'all') {
      filtered = filtered?.filter(role => role?.department === filters?.department);
    }

    if (filters?.compliance !== 'all') {
      filtered = filtered?.filter(role => {
        if (filters?.compliance === 'compliant') return (role?.complianceRate || 0) >= 90;
        if (filters?.compliance === 'warning') return (role?.complianceRate || 0) >= 70 && (role?.complianceRate || 0) < 90;
        if (filters?.compliance === 'critical') return (role?.complianceRate || 0) < 70;
        return true;
      });
    }

    return filtered;
  }, [allRoles, searchQuery, filters]);

  // Filter role categories based on filtered roles
  const filteredRoleCategories = useMemo(() => {
    return roleCategories?.map(category => ({
      ...category,
      roles: category?.roles?.filter(role => filteredRoles?.some(fr => fr?.id === role?.id)) || []
    }))?.filter(category => category?.roles?.length > 0) || [];
  }, [roleCategories, filteredRoles]);

  const handleRequirementChange = useCallback((roleId, categoryId, newType) => {
    setRequirements(prev => {
      const existingIndex = prev?.findIndex(req => req?.roleId === roleId && req?.categoryId === categoryId);
      
      if (existingIndex >= 0) {
        const updated = [...prev];
        updated[existingIndex] = { ...updated?.[existingIndex], type: newType };
        return updated;
      } else {
        return [...prev, {
          roleId,
          categoryId,
          type: newType,
          dueDate: newType === 'mandatory' ? new Date(Date.now() + 90 * 24 * 60 * 60 * 1000) : null,
          completionRate: 0
        }];
      }
    });
  }, []);

  const handleCellSelect = useCallback((cellKey, isSelected) => {
    setSelectedCells(prev => {
      const newSet = new Set(prev);
      if (isSelected) {
        newSet?.add(cellKey);
      } else {
        newSet?.delete(cellKey);
      }
      return newSet;
    });
  }, []);

  const handleRoleSelect = useCallback((roleId) => {
    // Select all cells for this role
    const roleCells = trainingCategories?.map(category => `${roleId}-${category?.id}`);
    setSelectedCells(prev => {
      const newSet = new Set(prev);
      roleCells?.forEach(cell => newSet?.add(cell));
      return newSet;
    });
  }, [trainingCategories]);

  const handleRoleToggle = useCallback((roleId) => {
    setSelectedRoles(prev => {
      const newSet = new Set(prev);
      if (newSet?.has(roleId)) {
        newSet?.delete(roleId);
      } else {
        newSet?.add(roleId);
      }
      return newSet;
    });
  }, []);

  const handleBulkAction = useCallback((action) => {
    selectedCells?.forEach(cellKey => {
      const [roleId, categoryId] = cellKey?.split('-');
      handleRequirementChange(roleId, categoryId, action);
    });
    setSelectedCells(new Set());
  }, [selectedCells, handleRequirementChange]);

  const handleFilterChange = useCallback((filterType, value) => {
    setFilters(prev => ({ ...prev, [filterType]: value }));
  }, []);

  const handleSaveView = useCallback((name, currentFilters) => {
    const view = {
      id: `view-${Date?.now()}`,
      name,
      filters: currentFilters,
      createdAt: new Date()?.toISOString()
    };
    setSavedViews(prev => [...prev, view]);
  }, []);

  const handleLoadView = useCallback((viewId) => {
    const view = savedViews?.find(v => v?.id === viewId);
    if (view) {
      setFilters(view?.filters || {});
    }
  }, [savedViews]);

  const handleExport = useCallback((format) => {
    console.log('Exporting as:', format);
    // Implementation would generate export
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e?.ctrlKey && e?.key === 'z') {
        e?.preventDefault();
        // Implement undo functionality
      }
      if (e?.key === 'Escape') {
        setSelectedCells(new Set());
        setSelectedRoles(new Set());
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <>
      <Helmet>
        <title>Training Requirements Matrix - Custom Training Matrix</title>
        <meta name="description" content="Customize your training compliance matrix with your organization's courses, departments, and requirements." />
      </Helmet>
      <div className="min-h-screen bg-background">
        <Header 
          onMenuToggle={() => setMobileMenuOpen(!mobileMenuOpen)}
          isMenuOpen={mobileMenuOpen}
        />

        <div className="flex pt-16">
          <RoleBasedSidebar
            isCollapsed={sidebarCollapsed}
            onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
            userRole="training_coordinator"
          />

          <div className={`flex-1 transition-all duration-200 ${sidebarCollapsed ? 'ml-16' : 'ml-60'}`}>
            <div className="p-6 space-y-6 max-w-full overflow-x-hidden">
              {/* Training Calendar Poster */}
              <TrainingCalendarPoster
                mandatoryTrainings={mandatoryTrainings}
                onAddTraining={handleAddTraining}
                onEditTraining={handleEditTraining}
                onDeleteTraining={handleDeleteTraining}
                canEdit={true}
              />

              {/* Editable Courses Section */}
              <EditableCoursesSection
                courses={trainingCategories}
                onAddCourse={handleAddCourse}
                onEditCourse={handleEditCourse}
                onDeleteCourse={handleDeleteCourse}
                canEdit={true}
              />

              {/* Editable Departments Section */}
              <EditableDepartmentsSection
                departments={roleCategories}
                onAddDepartment={handleAddDepartment}
                onEditDepartment={handleEditDepartment}
                onDeleteDepartment={handleDeleteDepartment}
                onAddRole={handleAddRole}
                onEditRole={handleEditRole}
                onDeleteRole={handleDeleteRole}
                canEdit={true}
              />

              {/* Training Requirements Matrix */}
              {trainingCategories?.length > 0 && allRoles?.length > 0 && (
                <div className="bg-card rounded-lg border border-border shadow-industrial p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h2 className="text-xl font-semibold text-foreground">Training Requirements Matrix</h2>
                      <p className="text-muted-foreground text-sm mt-1">
                        Set training requirements for each role and course combination
                      </p>
                    </div>
                  </div>

                  <div className="flex h-[600px]">
                    <RoleSidebar
                      roleCategories={filteredRoleCategories}
                      selectedRoles={selectedRoles}
                      onRoleSelect={handleRoleSelect}
                      onRoleToggle={handleRoleToggle}
                      isCollapsed={roleSidebarCollapsed}
                      onToggleCollapse={() => setRoleSidebarCollapsed(!roleSidebarCollapsed)}
                    />

                    <div className="flex-1 flex flex-col">
                      <MatrixToolbar
                        onSaveView={handleSaveView}
                        onLoadView={handleLoadView}
                        onExport={handleExport}
                        onBulkAction={handleBulkAction}
                        selectedCellsCount={selectedCells?.size}
                        searchQuery={searchQuery}
                        onSearchChange={setSearchQuery}
                        filters={filters}
                        onFilterChange={handleFilterChange}
                        savedViews={savedViews}
                        canEdit={true}
                      />

                      <div className="flex-1 overflow-hidden">
                        <MatrixGrid
                          roles={filteredRoles}
                          trainingCategories={trainingCategories}
                          requirements={requirements}
                          onRequirementChange={handleRequirementChange}
                          selectedCells={selectedCells}
                          onCellSelect={handleCellSelect}
                          isReadOnly={false}
                          userRole="training_coordinator"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Empty State for Matrix */}
              {(trainingCategories?.length === 0 || allRoles?.length === 0) && (
                <div className="bg-card rounded-lg border border-border shadow-industrial p-12 text-center">
                  <div className="max-w-md mx-auto">
                    <div className="w-16 h-16 mx-auto mb-4 bg-muted rounded-full flex items-center justify-center">
                      <div className="w-8 h-8 border-2 border-muted-foreground rounded grid grid-cols-2 gap-px">
                        <div className="bg-muted-foreground rounded-sm"></div>
                        <div className="bg-muted-foreground rounded-sm"></div>
                        <div className="bg-muted-foreground rounded-sm"></div>
                        <div className="bg-muted-foreground rounded-sm"></div>
                      </div>
                    </div>
                    <h3 className="text-xl font-medium text-foreground mb-2">
                      Ready to Build Your Training Matrix
                    </h3>
                    <p className="text-muted-foreground mb-6">
                      {trainingCategories?.length === 0 && allRoles?.length === 0
                        ? "Add training courses and departments with job roles to start building your custom training requirements matrix."
                        : trainingCategories?.length === 0
                        ? "Add training courses to start assigning requirements to your job roles." :"Add departments and job roles to start assigning training requirements."
                      }
                    </p>
                  </div>
                </div>
              )}

              {/* System Integration Status */}
              <div className="grid grid-cols-1 xl:grid-cols-1">
                <SystemIntegrationStatus />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default TrainingRequirementsMatrix;