import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const RoleSidebar = ({ 
  roleCategories, 
  selectedRoles, 
  onRoleSelect, 
  onRoleToggle,
  isCollapsed = false,
  onToggleCollapse 
}) => {
  const [expandedCategories, setExpandedCategories] = useState({
    production: true,
    quality: true,
    maintenance: false,
    safety: false,
    management: false
  });

  const toggleCategory = (categoryId) => {
    setExpandedCategories(prev => ({
      ...prev,
      [categoryId]: !prev?.[categoryId]
    }));
  };

  const getComplianceColor = (rate) => {
    if (rate >= 90) return 'text-success';
    if (rate >= 70) return 'text-warning';
    return 'text-error';
  };

  const getComplianceIcon = (rate) => {
    if (rate >= 90) return 'CheckCircle';
    if (rate >= 70) return 'AlertTriangle';
    return 'XCircle';
  };

  if (isCollapsed) {
    return (
      <div className="w-12 bg-card border-r border-border shadow-industrial">
        <div className="p-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggleCollapse}
            className="w-8 h-8"
            title="Expand role sidebar"
          >
            <Icon name="ChevronRight" size={16} />
          </Button>
        </div>
        <div className="space-y-2 p-2">
          {roleCategories?.map(category => (
            <div
              key={category?.id}
              className="flex justify-center"
              title={`${category?.name}: ${category?.roles?.length} roles`}
            >
              <div className={`w-2 h-2 rounded-full ${
                category?.overallCompliance >= 90 ? 'bg-success' :
                category?.overallCompliance >= 70 ? 'bg-warning' : 'bg-error'
              }`}></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="w-60 bg-card border-r border-border shadow-industrial">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center space-x-2">
          <Icon name="Users" size={16} className="text-primary" />
          <span className="font-medium text-foreground">Job Roles</span>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={onToggleCollapse}
          className="w-8 h-8"
          title="Collapse role sidebar"
        >
          <Icon name="ChevronLeft" size={16} />
        </Button>
      </div>
      {/* Role Categories */}
      <div className="overflow-y-auto h-full">
        <div className="p-2 space-y-1">
          {roleCategories?.map(category => (
            <div key={category?.id} className="space-y-1">
              {/* Category Header */}
              <button
                onClick={() => toggleCategory(category?.id)}
                className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-muted transition-colors"
              >
                <div className="flex items-center space-x-2">
                  <Icon name={category?.icon} size={14} className="text-muted-foreground" />
                  <span className="text-sm font-medium text-foreground">
                    {category?.name}
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="flex items-center space-x-1">
                    <Icon 
                      name={getComplianceIcon(category?.overallCompliance)} 
                      size={12} 
                      className={getComplianceColor(category?.overallCompliance)}
                    />
                    <span className={`text-xs font-medium text-data ${getComplianceColor(category?.overallCompliance)}`}>
                      {category?.overallCompliance}%
                    </span>
                  </div>
                  <Icon 
                    name={expandedCategories?.[category?.id] ? 'ChevronDown' : 'ChevronRight'} 
                    size={12} 
                    className="text-muted-foreground"
                  />
                </div>
              </button>

              {/* Category Roles */}
              {expandedCategories?.[category?.id] && (
                <div className="ml-4 space-y-1">
                  {category?.roles?.map(role => (
                    <div
                      key={role?.id}
                      className={`
                        flex items-center justify-between p-2 rounded cursor-pointer transition-colors
                        ${selectedRoles?.has(role?.id) ? 'bg-primary/10 border border-primary/20' : 'hover:bg-muted'}
                      `}
                      onClick={() => onRoleSelect(role?.id)}
                    >
                      <div className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={selectedRoles?.has(role?.id)}
                          onChange={() => onRoleToggle(role?.id)}
                          className="w-3 h-3 text-primary border-border rounded focus:ring-primary focus:ring-1"
                          onClick={(e) => e?.stopPropagation()}
                        />
                        <div>
                          <div className="text-sm font-medium text-foreground">
                            {role?.name}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {role?.employeeCount} employees
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-1">
                        <Icon 
                          name={getComplianceIcon(role?.complianceRate)} 
                          size={10} 
                          className={getComplianceColor(role?.complianceRate)}
                        />
                        <span className={`text-xs font-medium text-data ${getComplianceColor(role?.complianceRate)}`}>
                          {role?.complianceRate}%
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Summary Stats */}
        <div className="p-4 border-t border-border bg-muted/50">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Total Roles:</span>
              <span className="font-medium text-foreground">
                {roleCategories?.reduce((sum, cat) => sum + cat?.roles?.length, 0)}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Selected:</span>
              <span className="font-medium text-foreground">
                {selectedRoles?.size}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Overall Compliance:</span>
              <span className={`font-medium text-data ${getComplianceColor(
                roleCategories?.reduce((sum, cat) => sum + cat?.overallCompliance, 0) / roleCategories?.length
              )}`}>
                {Math.round(roleCategories?.reduce((sum, cat) => sum + cat?.overallCompliance, 0) / roleCategories?.length)}%
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RoleSidebar;