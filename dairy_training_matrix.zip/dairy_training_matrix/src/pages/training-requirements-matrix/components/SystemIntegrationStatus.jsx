import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SystemIntegrationStatus = ({ className = '' }) => {
  const [integrationStatus, setIntegrationStatus] = useState({
    hris: { status: 'syncing', lastSync: null, recordCount: 0 },
    erp: { status: 'syncing', lastSync: null, recordCount: 0 },
    training: { status: 'syncing', lastSync: null, recordCount: 0 },
    overall: 'syncing'
  });

  const [showDetails, setShowDetails] = useState(false);
  const [lastUpdateTime, setLastUpdateTime] = useState(new Date());

  useEffect(() => {
    // Simulate integration status check
    const timer = setTimeout(() => {
      setIntegrationStatus({
        hris: {
          status: 'connected',
          lastSync: new Date(Date.now() - 2 * 60 * 1000), // 2 minutes ago
          recordCount: 247,
          message: 'Employee data synchronized successfully'
        },
        erp: {
          status: 'connected',
          lastSync: new Date(Date.now() - 5 * 60 * 1000), // 5 minutes ago
          recordCount: 189,
          message: 'Role assignments updated'
        },
        training: {
          status: 'warning',
          lastSync: new Date(Date.now() - 12 * 60 * 1000), // 12 minutes ago
          recordCount: 156,
          message: 'Some training records pending validation'
        },
        overall: 'warning'
      });
      setLastUpdateTime(new Date());
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  const getStatusIcon = (status) => {
    switch (status) {
      case 'connected': return 'CheckCircle';
      case 'warning': return 'AlertTriangle';
      case 'error': return 'XCircle';
      case 'syncing': return 'RefreshCw';
      default: return 'Circle';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'connected': return 'text-success';
      case 'warning': return 'text-warning';
      case 'error': return 'text-error';
      case 'syncing': return 'text-accent';
      default: return 'text-muted-foreground';
    }
  };

  const getStatusBgColor = (status) => {
    switch (status) {
      case 'connected': return 'bg-success/10 border-success/20';
      case 'warning': return 'bg-warning/10 border-warning/20';
      case 'error': return 'bg-error/10 border-error/20';
      case 'syncing': return 'bg-accent/10 border-accent/20';
      default: return 'bg-muted/10 border-muted/20';
    }
  };

  const formatLastSync = (date) => {
    if (!date) return 'Never';
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    return `${diffHours}h ${diffMins % 60}m ago`;
  };

  const handleRefresh = () => {
    setIntegrationStatus(prev => ({
      ...prev,
      hris: { ...prev?.hris, status: 'syncing' },
      erp: { ...prev?.erp, status: 'syncing' },
      training: { ...prev?.training, status: 'syncing' },
      overall: 'syncing'
    }));

    // Simulate refresh
    setTimeout(() => {
      setIntegrationStatus(prev => ({
        hris: {
          ...prev?.hris,
          status: 'connected',
          lastSync: new Date(),
          recordCount: prev?.hris?.recordCount + Math.floor(Math.random() * 5)
        },
        erp: {
          ...prev?.erp,
          status: 'connected',
          lastSync: new Date(),
          recordCount: prev?.erp?.recordCount + Math.floor(Math.random() * 3)
        },
        training: {
          ...prev?.training,
          status: 'connected',
          lastSync: new Date(),
          recordCount: prev?.training?.recordCount + Math.floor(Math.random() * 2)
        },
        overall: 'connected'
      }));
      setLastUpdateTime(new Date());
    }, 2000);
  };

  return (
    <div className={`bg-card border border-border rounded-lg shadow-industrial ${className}`}>
      <div className="p-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <Icon 
              name={getStatusIcon(integrationStatus?.overall)} 
              size={16} 
              className={`${getStatusColor(integrationStatus?.overall)} ${
                integrationStatus?.overall === 'syncing' ? 'animate-spin' : ''
              }`}
            />
            <span className="font-medium text-foreground">System Integration</span>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleRefresh}
              iconName="RefreshCw"
              iconPosition="left"
              disabled={integrationStatus?.overall === 'syncing'}
            >
              Refresh
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowDetails(!showDetails)}
              className="w-8 h-8"
            >
              <Icon name={showDetails ? 'ChevronUp' : 'ChevronDown'} size={14} />
            </Button>
          </div>
        </div>

        {/* Quick Status Indicators */}
        <div className="flex items-center space-x-4 mb-3">
          {Object.entries(integrationStatus)?.filter(([key]) => key !== 'overall')?.map(([system, data]) => (
            <div key={system} className="flex items-center space-x-2">
              <Icon 
                name={getStatusIcon(data?.status)} 
                size={12} 
                className={`${getStatusColor(data?.status)} ${
                  data?.status === 'syncing' ? 'animate-spin' : ''
                }`}
              />
              <span className="text-xs text-muted-foreground uppercase font-medium">
                {system}
              </span>
              <span className="text-xs text-data font-medium">
                {data?.recordCount || 0}
              </span>
            </div>
          ))}
        </div>

        {/* Last Update */}
        <div className="text-xs text-muted-foreground">
          Last updated: {lastUpdateTime?.toLocaleTimeString([], { 
            hour: '2-digit', 
            minute: '2-digit',
            second: '2-digit'
          })}
        </div>

        {/* Detailed Status */}
        {showDetails && (
          <div className="mt-4 space-y-3 border-t border-border pt-4">
            {Object.entries(integrationStatus)?.filter(([key]) => key !== 'overall')?.map(([system, data]) => (
              <div 
                key={system}
                className={`p-3 rounded-lg border ${getStatusBgColor(data?.status)}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <Icon 
                      name={getStatusIcon(data?.status)} 
                      size={14} 
                      className={`${getStatusColor(data?.status)} ${
                        data?.status === 'syncing' ? 'animate-spin' : ''
                      }`}
                    />
                    <span className="font-medium text-foreground capitalize">
                      {system === 'hris' ? 'HRIS Integration' : 
                       system === 'erp'? 'ERP Integration' : 'Training Provider'}
                    </span>
                  </div>
                  <span className={`text-sm font-medium ${getStatusColor(data?.status)}`}>
                    {data?.status?.charAt(0)?.toUpperCase() + data?.status?.slice(1)}
                  </span>
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-muted-foreground">Last Sync:</span>
                    <div className="font-medium text-data">
                      {formatLastSync(data?.lastSync)}
                    </div>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Records:</span>
                    <div className="font-medium text-data">
                      {data?.recordCount || 0}
                    </div>
                  </div>
                </div>
                
                {data?.message && (
                  <div className="mt-2 text-xs text-muted-foreground">
                    {data?.message}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default SystemIntegrationStatus;