import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const EditableDepartmentsSection = ({ 
  departments = [], 
  onAddDepartment, 
  onEditDepartment, 
  onDeleteDepartment,
  onAddRole,
  onEditRole,
  onDeleteRole,
  canEdit = true 
}) => {
  const [showAddDeptModal, setShowAddDeptModal] = useState(false);
  const [showAddRoleModal, setShowAddRoleModal] = useState(false);
  const [editingDepartment, setEditingDepartment] = useState(null);
  const [editingRole, setEditingRole] = useState(null);
  const [selectedDeptForRole, setSelectedDeptForRole] = useState(null);
  const [expandedDepartments, setExpandedDepartments] = useState(new Set());
  
  const [newDepartment, setNewDepartment] = useState({
    name: '',
    description: '',
    icon: 'Users',
    location: '',
    manager: ''
  });

  const [newRole, setNewRole] = useState({
    name: '',
    description: '',
    employeeCount: 0,
    level: 'entry'
  });

  const iconOptions = [
    { value: 'Users', label: 'Users (General)' },
    { value: 'Factory', label: 'Factory (Production)' },
    { value: 'Target', label: 'Target (Quality)' },
    { value: 'Wrench', label: 'Wrench (Maintenance)' },
    { value: 'ShieldCheck', label: 'Shield (Safety)' },
    { value: 'Building', label: 'Building (Management)' },
    { value: 'Truck', label: 'Truck (Logistics)' },
    { value: 'Beaker', label: 'Beaker (Laboratory)' },
    { value: 'Package', label: 'Package (Packaging)' }
  ];

  const levelOptions = [
    { value: 'entry', label: 'Entry Level' },
    { value: 'intermediate', label: 'Intermediate' },
    { value: 'senior', label: 'Senior Level' },
    { value: 'supervisor', label: 'Supervisor' },
    { value: 'manager', label: 'Manager' },
    { value: 'director', label: 'Director' }
  ];

  const toggleDepartmentExpand = (deptId) => {
    const newExpanded = new Set(expandedDepartments);
    if (newExpanded?.has(deptId)) {
      newExpanded?.delete(deptId);
    } else {
      newExpanded?.add(deptId);
    }
    setExpandedDepartments(newExpanded);
  };

  const handleAddDepartment = () => {
    if (newDepartment?.name?.trim()) {
      const department = {
        id: `dept-${Date?.now()}`,
        ...newDepartment,
        roles: [],
        createdAt: new Date()?.toISOString()
      };
      onAddDepartment?.(department);
      setNewDepartment({ name: '', description: '', icon: 'Users', location: '', manager: '' });
      setShowAddDeptModal(false);
    }
  };

  const handleEditDepartment = () => {
    if (editingDepartment && editingDepartment?.name?.trim()) {
      onEditDepartment?.(editingDepartment);
      setEditingDepartment(null);
    }
  };

  const handleAddRole = () => {
    if (newRole?.name?.trim() && selectedDeptForRole) {
      const role = {
        id: `role-${Date?.now()}`,
        ...newRole,
        departmentId: selectedDeptForRole,
        complianceRate: 0,
        createdAt: new Date()?.toISOString()
      };
      onAddRole?.(selectedDeptForRole, role);
      setNewRole({ name: '', description: '', employeeCount: 0, level: 'entry' });
      setShowAddRoleModal(false);
      setSelectedDeptForRole(null);
    }
  };

  const handleEditRole = () => {
    if (editingRole && editingRole?.name?.trim()) {
      onEditRole?.(editingRole);
      setEditingRole(null);
    }
  };

  const EmptyState = () => (
    <div className="text-center py-8">
      <Icon name="Users" size={48} className="mx-auto text-muted-foreground mb-4" />
      <h3 className="text-lg font-medium text-foreground mb-2">No Departments & Roles</h3>
      <p className="text-muted-foreground mb-4">
        Set up your organizational structure by adding departments and their associated job roles.
      </p>
      {canEdit && (
        <Button
          onClick={() => setShowAddDeptModal(true)}
          iconName="Plus"
          iconPosition="left"
        >
          Add First Department
        </Button>
      )}
    </div>
  );

  return (
    <div className="bg-card rounded-lg border border-border shadow-industrial p-6 mb-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-xl font-semibold text-foreground flex items-center space-x-2">
            <Icon name="Users" size={20} />
            <span>Departments & Job Roles</span>
          </h2>
          <p className="text-muted-foreground text-sm mt-1">
            Manage your organizational structure and job roles
          </p>
        </div>
        {canEdit && departments?.length > 0 && (
          <Button
            onClick={() => setShowAddDeptModal(true)}
            size="sm"
            iconName="Plus"
            iconPosition="left"
          >
            Add Department
          </Button>
        )}
      </div>

      {departments?.length === 0 ? (
        <EmptyState />
      ) : (
        <div className="space-y-4">
          {departments?.map(department => (
            <div
              key={department?.id}
              className="border border-border rounded-lg overflow-hidden"
            >
              {/* Department Header */}
              <div className="bg-muted p-4 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <button
                    onClick={() => toggleDepartmentExpand(department?.id)}
                    className="p-1 hover:bg-background rounded transition-colors"
                  >
                    <Icon 
                      name={expandedDepartments?.has(department?.id) ? "ChevronDown" : "ChevronRight"} 
                      size={16} 
                    />
                  </button>
                  
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <Icon name={department?.icon} size={20} className="text-primary" />
                  </div>
                  
                  <div>
                    <h3 className="font-medium text-foreground">{department?.name}</h3>
                    <p className="text-sm text-muted-foreground">{department?.description}</p>
                    <div className="flex items-center space-x-4 mt-1 text-xs text-muted-foreground">
                      {department?.location && (
                        <span className="flex items-center space-x-1">
                          <Icon name="MapPin" size={12} />
                          <span>{department?.location}</span>
                        </span>
                      )}
                      {department?.manager && (
                        <span className="flex items-center space-x-1">
                          <Icon name="User" size={12} />
                          <span>{department?.manager}</span>
                        </span>
                      )}
                      <span className="flex items-center space-x-1">
                        <Icon name="Users" size={12} />
                        <span>{department?.roles?.length || 0} roles</span>
                      </span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  {canEdit && (
                    <>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setSelectedDeptForRole(department?.id);
                          setShowAddRoleModal(true);
                        }}
                        iconName="UserPlus"
                        iconPosition="left"
                      >
                        Add Role
                      </Button>
                      <button
                        onClick={() => setEditingDepartment({ ...department })}
                        className="p-2 hover:bg-background rounded transition-colors"
                      >
                        <Icon name="Edit" size={16} />
                      </button>
                      <button
                        onClick={() => onDeleteDepartment?.(department?.id)}
                        className="p-2 hover:bg-background rounded transition-colors text-error"
                      >
                        <Icon name="Trash2" size={16} />
                      </button>
                    </>
                  )}
                </div>
              </div>
              
              {/* Department Roles */}
              {expandedDepartments?.has(department?.id) && (
                <div className="p-4 bg-background">
                  {department?.roles?.length === 0 ? (
                    <div className="text-center py-6">
                      <Icon name="UserPlus" size={32} className="mx-auto text-muted-foreground mb-2" />
                      <p className="text-muted-foreground">No roles in this department</p>
                      {canEdit && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            setSelectedDeptForRole(department?.id);
                            setShowAddRoleModal(true);
                          }}
                          iconName="Plus"
                          iconPosition="left"
                          className="mt-2"
                        >
                          Add First Role
                        </Button>
                      )}
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                      {department?.roles?.map(role => (
                        <div
                          key={role?.id}
                          className="bg-card rounded-lg p-3 border border-border hover:shadow-sm transition-shadow"
                        >
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex-1">
                              <h4 className="font-medium text-foreground">{role?.name}</h4>
                              <p className="text-xs text-muted-foreground line-clamp-2 mt-1">
                                {role?.description}
                              </p>
                            </div>
                            {canEdit && (
                              <div className="flex items-center space-x-1 ml-2">
                                <button
                                  onClick={() => setEditingRole({ ...role, departmentId: department?.id })}
                                  className="p-1 hover:bg-muted rounded transition-colors"
                                >
                                  <Icon name="Edit" size={12} />
                                </button>
                                <button
                                  onClick={() => onDeleteRole?.(department?.id, role?.id)}
                                  className="p-1 hover:bg-muted rounded transition-colors text-error"
                                >
                                  <Icon name="Trash2" size={12} />
                                </button>
                              </div>
                            )}
                          </div>
                          
                          <div className="space-y-1 text-xs">
                            <div className="flex items-center justify-between">
                              <span className="text-muted-foreground">Level:</span>
                              <span className="font-medium text-foreground capitalize">{role?.level}</span>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-muted-foreground">Employees:</span>
                              <span className="font-medium text-foreground">{role?.employeeCount}</span>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-muted-foreground">Compliance:</span>
                              <div className="flex items-center space-x-1">
                                <div className={`w-2 h-2 rounded-full ${
                                  (role?.complianceRate || 0) >= 90 ? 'bg-success' :
                                  (role?.complianceRate || 0) >= 70 ? 'bg-warning' : 'bg-error'
                                }`}></div>
                                <span className="font-medium text-foreground">{role?.complianceRate || 0}%</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Add Department Modal */}
      {showAddDeptModal && (
        <>
          <div
            className="fixed inset-0 bg-black/50 z-200"
            onClick={() => setShowAddDeptModal(false)}
          />
          <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 bg-card border border-border rounded-lg shadow-industrial-strong z-300">
            <div className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">
                Add Department
              </h3>
              <div className="space-y-4">
                <Input
                  label="Department Name"
                  type="text"
                  placeholder="Enter department name..."
                  value={newDepartment?.name}
                  onChange={(e) => setNewDepartment(prev => ({ ...prev, name: e?.target?.value }))}
                />
                <Input
                  label="Description"
                  type="text"
                  placeholder="Department description..."
                  value={newDepartment?.description}
                  onChange={(e) => setNewDepartment(prev => ({ ...prev, description: e?.target?.value }))}
                />
                <Select
                  label="Icon"
                  options={iconOptions}
                  value={newDepartment?.icon}
                  onChange={(value) => setNewDepartment(prev => ({ ...prev, icon: value }))}
                />
                <Input
                  label="Location"
                  type="text"
                  placeholder="Department location..."
                  value={newDepartment?.location}
                  onChange={(e) => setNewDepartment(prev => ({ ...prev, location: e?.target?.value }))}
                />
                <Input
                  label="Manager/Head"
                  type="text"
                  placeholder="Department manager..."
                  value={newDepartment?.manager}
                  onChange={(e) => setNewDepartment(prev => ({ ...prev, manager: e?.target?.value }))}
                />
              </div>
              <div className="flex justify-end space-x-2 mt-6">
                <Button
                  variant="outline"
                  onClick={() => setShowAddDeptModal(false)}
                >
                  Cancel
                </Button>
                <Button
                  variant="default"
                  onClick={handleAddDepartment}
                  disabled={!newDepartment?.name?.trim()}
                >
                  Add Department
                </Button>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Add Role Modal */}
      {showAddRoleModal && (
        <>
          <div
            className="fixed inset-0 bg-black/50 z-200"
            onClick={() => setShowAddRoleModal(false)}
          />
          <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 bg-card border border-border rounded-lg shadow-industrial-strong z-300">
            <div className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">
                Add Job Role
              </h3>
              <div className="space-y-4">
                <Input
                  label="Role Name"
                  type="text"
                  placeholder="Enter role name..."
                  value={newRole?.name}
                  onChange={(e) => setNewRole(prev => ({ ...prev, name: e?.target?.value }))}
                />
                <Input
                  label="Description"
                  type="text"
                  placeholder="Role description..."
                  value={newRole?.description}
                  onChange={(e) => setNewRole(prev => ({ ...prev, description: e?.target?.value }))}
                />
                <Select
                  label="Level"
                  options={levelOptions}
                  value={newRole?.level}
                  onChange={(value) => setNewRole(prev => ({ ...prev, level: value }))}
                />
                <Input
                  label="Number of Employees"
                  type="number"
                  placeholder="0"
                  value={newRole?.employeeCount}
                  onChange={(e) => setNewRole(prev => ({ ...prev, employeeCount: parseInt(e?.target?.value) || 0 }))}
                />
              </div>
              <div className="flex justify-end space-x-2 mt-6">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowAddRoleModal(false);
                    setSelectedDeptForRole(null);
                  }}
                >
                  Cancel
                </Button>
                <Button
                  variant="default"
                  onClick={handleAddRole}
                  disabled={!newRole?.name?.trim()}
                >
                  Add Role
                </Button>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Edit Department Modal */}
      {editingDepartment && (
        <>
          <div
            className="fixed inset-0 bg-black/50 z-200"
            onClick={() => setEditingDepartment(null)}
          />
          <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 bg-card border border-border rounded-lg shadow-industrial-strong z-300">
            <div className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">
                Edit Department
              </h3>
              <div className="space-y-4">
                <Input
                  label="Department Name"
                  type="text"
                  placeholder="Enter department name..."
                  value={editingDepartment?.name}
                  onChange={(e) => setEditingDepartment(prev => ({ ...prev, name: e?.target?.value }))}
                />
                <Input
                  label="Description"
                  type="text"
                  placeholder="Department description..."
                  value={editingDepartment?.description}
                  onChange={(e) => setEditingDepartment(prev => ({ ...prev, description: e?.target?.value }))}
                />
                <Select
                  label="Icon"
                  options={iconOptions}
                  value={editingDepartment?.icon}
                  onChange={(value) => setEditingDepartment(prev => ({ ...prev, icon: value }))}
                />
                <Input
                  label="Location"
                  type="text"
                  placeholder="Department location..."
                  value={editingDepartment?.location}
                  onChange={(e) => setEditingDepartment(prev => ({ ...prev, location: e?.target?.value }))}
                />
                <Input
                  label="Manager/Head"
                  type="text"
                  placeholder="Department manager..."
                  value={editingDepartment?.manager}
                  onChange={(e) => setEditingDepartment(prev => ({ ...prev, manager: e?.target?.value }))}
                />
              </div>
              <div className="flex justify-end space-x-2 mt-6">
                <Button
                  variant="outline"
                  onClick={() => setEditingDepartment(null)}
                >
                  Cancel
                </Button>
                <Button
                  variant="default"
                  onClick={handleEditDepartment}
                  disabled={!editingDepartment?.name?.trim()}
                >
                  Save Changes
                </Button>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Edit Role Modal */}
      {editingRole && (
        <>
          <div
            className="fixed inset-0 bg-black/50 z-200"
            onClick={() => setEditingRole(null)}
          />
          <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 bg-card border border-border rounded-lg shadow-industrial-strong z-300">
            <div className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">
                Edit Job Role
              </h3>
              <div className="space-y-4">
                <Input
                  label="Role Name"
                  type="text"
                  placeholder="Enter role name..."
                  value={editingRole?.name}
                  onChange={(e) => setEditingRole(prev => ({ ...prev, name: e?.target?.value }))}
                />
                <Input
                  label="Description"
                  type="text"
                  placeholder="Role description..."
                  value={editingRole?.description}
                  onChange={(e) => setEditingRole(prev => ({ ...prev, description: e?.target?.value }))}
                />
                <Select
                  label="Level"
                  options={levelOptions}
                  value={editingRole?.level}
                  onChange={(value) => setEditingRole(prev => ({ ...prev, level: value }))}
                />
                <Input
                  label="Number of Employees"
                  type="number"
                  placeholder="0"
                  value={editingRole?.employeeCount}
                  onChange={(e) => setEditingRole(prev => ({ ...prev, employeeCount: parseInt(e?.target?.value) || 0 }))}
                />
              </div>
              <div className="flex justify-end space-x-2 mt-6">
                <Button
                  variant="outline"
                  onClick={() => setEditingRole(null)}
                >
                  Cancel
                </Button>
                <Button
                  variant="default"
                  onClick={handleEditRole}
                  disabled={!editingRole?.name?.trim()}
                >
                  Save Changes
                </Button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default EditableDepartmentsSection;