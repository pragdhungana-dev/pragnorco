import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const TrainingCalendarPoster = ({ 
  mandatoryTrainings = [], 
  onAddTraining, 
  onEditTraining, 
  onDeleteTraining,
  canEdit = true 
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingTraining, setEditingTraining] = useState(null);
  const [newTraining, setNewTraining] = useState({
    name: '',
    frequency: 'monthly',
    nextDue: '',
    priority: 'high',
    description: '',
    department: 'all'
  });

  const frequencyOptions = [
    { value: 'weekly', label: 'Weekly' },
    { value: 'monthly', label: 'Monthly' },
    { value: 'quarterly', label: 'Quarterly' },
    { value: 'semi-annually', label: 'Semi-Annually' },
    { value: 'annually', label: 'Annually' }
  ];

  const priorityOptions = [
    { value: 'high', label: 'High Priority' },
    { value: 'medium', label: 'Medium Priority' },
    { value: 'low', label: 'Low Priority' }
  ];

  const departmentOptions = [
    { value: 'all', label: 'All Departments' },
    { value: 'production', label: 'Production' },
    { value: 'quality', label: 'Quality Control' },
    { value: 'maintenance', label: 'Maintenance' },
    { value: 'safety', label: 'Safety' },
    { value: 'management', label: 'Management' }
  ];

  const handleAddTraining = () => {
    if (newTraining?.name?.trim()) {
      const training = {
        id: Date?.now()?.toString(),
        ...newTraining,
        createdAt: new Date()?.toISOString()
      };
      onAddTraining?.(training);
      setNewTraining({ name: '', frequency: 'monthly', nextDue: '', priority: 'high', description: '', department: 'all' });
      setShowAddModal(false);
    }
  };

  const handleEditTraining = () => {
    if (editingTraining && editingTraining?.name?.trim()) {
      onEditTraining?.(editingTraining);
      setEditingTraining(null);
    }
  };

  const handleDeleteTraining = (id) => {
    onDeleteTraining?.(id);
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const EmptyState = () => (
    <div className="text-center py-8">
      <Icon name="Calendar" size={48} className="mx-auto text-muted-foreground mb-4" />
      <h3 className="text-lg font-medium text-foreground mb-2">No Training Calendar Set</h3>
      <p className="text-muted-foreground mb-4">
        Add mandatory training schedules to track important deadlines and frequencies for your organization.
      </p>
      {canEdit && (
        <Button
          onClick={() => setShowAddModal(true)}
          iconName="Plus"
          iconPosition="left"
        >
          Add First Training Schedule
        </Button>
      )}
    </div>
  );

  return (
    <div className="bg-card rounded-lg border border-border shadow-industrial p-6 mb-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-xl font-semibold text-foreground flex items-center space-x-2">
            <Icon name="Calendar" size={20} />
            <span>Mandatory Training Calendar</span>
          </h2>
          <p className="text-muted-foreground text-sm mt-1">
            Track upcoming mandatory training requirements and their schedules
          </p>
        </div>
        {canEdit && mandatoryTrainings?.length > 0 && (
          <Button
            onClick={() => setShowAddModal(true)}
            size="sm"
            iconName="Plus"
            iconPosition="left"
          >
            Add Training
          </Button>
        )}
      </div>

      {mandatoryTrainings?.length === 0 ? (
        <EmptyState />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {mandatoryTrainings?.map(training => (
            <div
              key={training?.id}
              className="bg-muted rounded-lg p-4 border border-border hover:shadow-sm transition-shadow"
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <h3 className="font-medium text-foreground">{training?.name}</h3>
                  <p className="text-xs text-muted-foreground mt-1">{training?.description}</p>
                </div>
                {canEdit && (
                  <div className="flex items-center space-x-1 ml-2">
                    <button
                      onClick={() => setEditingTraining({ ...training })}
                      className="p-1 hover:bg-background rounded transition-colors"
                    >
                      <Icon name="Edit" size={14} />
                    </button>
                    <button
                      onClick={() => handleDeleteTraining(training?.id)}
                      className="p-1 hover:bg-background rounded transition-colors text-error"
                    >
                      <Icon name="Trash2" size={14} />
                    </button>
                  </div>
                )}
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">Frequency:</span>
                  <span className="text-xs font-medium text-foreground capitalize">
                    {training?.frequency}
                  </span>
                </div>
                
                {training?.nextDue && (
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">Next Due:</span>
                    <span className="text-xs font-medium text-foreground">
                      {new Date(training?.nextDue)?.toLocaleDateString()}
                    </span>
                  </div>
                )}
                
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">Department:</span>
                  <span className="text-xs font-medium text-foreground capitalize">
                    {training?.department}
                  </span>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">Priority:</span>
                  <span className={`text-xs px-2 py-1 rounded-full border ${getPriorityColor(training?.priority)}`}>
                    {training?.priority}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Training Modal */}
      {showAddModal && (
        <>
          <div
            className="fixed inset-0 bg-black/50 z-200"
            onClick={() => setShowAddModal(false)}
          />
          <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 bg-card border border-border rounded-lg shadow-industrial-strong z-300">
            <div className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">
                Add Mandatory Training
              </h3>
              <div className="space-y-4">
                <Input
                  label="Training Name"
                  type="text"
                  placeholder="Enter training name..."
                  value={newTraining?.name}
                  onChange={(e) => setNewTraining(prev => ({ ...prev, name: e?.target?.value }))}
                />
                <Input
                  label="Description"
                  type="text"
                  placeholder="Brief description..."
                  value={newTraining?.description}
                  onChange={(e) => setNewTraining(prev => ({ ...prev, description: e?.target?.value }))}
                />
                <Select
                  label="Frequency"
                  options={frequencyOptions}
                  value={newTraining?.frequency}
                  onChange={(value) => setNewTraining(prev => ({ ...prev, frequency: value }))}
                />
                <Select
                  label="Department"
                  options={departmentOptions}
                  value={newTraining?.department}
                  onChange={(value) => setNewTraining(prev => ({ ...prev, department: value }))}
                />
                <Select
                  label="Priority"
                  options={priorityOptions}
                  value={newTraining?.priority}
                  onChange={(value) => setNewTraining(prev => ({ ...prev, priority: value }))}
                />
                <Input
                  label="Next Due Date"
                  type="date"
                  value={newTraining?.nextDue}
                  onChange={(e) => setNewTraining(prev => ({ ...prev, nextDue: e?.target?.value }))}
                />
              </div>
              <div className="flex justify-end space-x-2 mt-6">
                <Button
                  variant="outline"
                  onClick={() => setShowAddModal(false)}
                >
                  Cancel
                </Button>
                <Button
                  variant="default"
                  onClick={handleAddTraining}
                  disabled={!newTraining?.name?.trim()}
                >
                  Add Training
                </Button>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Edit Training Modal */}
      {editingTraining && (
        <>
          <div
            className="fixed inset-0 bg-black/50 z-200"
            onClick={() => setEditingTraining(null)}
          />
          <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 bg-card border border-border rounded-lg shadow-industrial-strong z-300">
            <div className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">
                Edit Training Schedule
              </h3>
              <div className="space-y-4">
                <Input
                  label="Training Name"
                  type="text"
                  placeholder="Enter training name..."
                  value={editingTraining?.name}
                  onChange={(e) => setEditingTraining(prev => ({ ...prev, name: e?.target?.value }))}
                />
                <Input
                  label="Description"
                  type="text"
                  placeholder="Brief description..."
                  value={editingTraining?.description}
                  onChange={(e) => setEditingTraining(prev => ({ ...prev, description: e?.target?.value }))}
                />
                <Select
                  label="Frequency"
                  options={frequencyOptions}
                  value={editingTraining?.frequency}
                  onChange={(value) => setEditingTraining(prev => ({ ...prev, frequency: value }))}
                />
                <Select
                  label="Department"
                  options={departmentOptions}
                  value={editingTraining?.department}
                  onChange={(value) => setEditingTraining(prev => ({ ...prev, department: value }))}
                />
                <Select
                  label="Priority"
                  options={priorityOptions}
                  value={editingTraining?.priority}
                  onChange={(value) => setEditingTraining(prev => ({ ...prev, priority: value }))}
                />
                <Input
                  label="Next Due Date"
                  type="date"
                  value={editingTraining?.nextDue}
                  onChange={(e) => setEditingTraining(prev => ({ ...prev, nextDue: e?.target?.value }))}
                />
              </div>
              <div className="flex justify-end space-x-2 mt-6">
                <Button
                  variant="outline"
                  onClick={() => setEditingTraining(null)}
                >
                  Cancel
                </Button>
                <Button
                  variant="default"
                  onClick={handleEditTraining}
                  disabled={!editingTraining?.name?.trim()}
                >
                  Save Changes
                </Button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default TrainingCalendarPoster;