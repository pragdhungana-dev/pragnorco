import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const MatrixToolbar = ({
  onSaveView,
  onLoadView,
  onExport,
  onBulkAction,
  selectedCellsCount,
  searchQuery,
  onSearchChange,
  filters,
  onFilterChange,
  savedViews = [],
  canEdit = true
}) => {
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [newViewName, setNewViewName] = useState('');
  const [showBulkMenu, setShowBulkMenu] = useState(false);

  const facilityOptions = [
    { value: 'all', label: 'All Facilities' }
  ];

  const departmentOptions = [
    { value: 'all', label: 'All Departments' }
  ];

  const complianceOptions = [
    { value: 'all', label: 'All Compliance Levels' },
    { value: 'compliant', label: 'Compliant (≥90%)' },
    { value: 'warning', label: 'Warning (70-89%)' },
    { value: 'critical', label: 'Critical (<70%)' }
  ];

  const exportOptions = [
    { value: 'pdf', label: 'PDF Report', icon: 'FileText' },
    { value: 'excel', label: 'Excel Spreadsheet', icon: 'FileSpreadsheet' },
    { value: 'csv', label: 'CSV Data', icon: 'Database' }
  ];

  const bulkActions = [
    { value: 'mandatory', label: 'Set as Mandatory', icon: 'AlertCircle' },
    { value: 'recommended', label: 'Set as Recommended', icon: 'CheckCircle' },
    { value: 'optional', label: 'Set as Optional', icon: 'Clock' },
    { value: 'none', label: 'Remove Requirement', icon: 'Minus' }
  ];

  const handleSaveView = () => {
    if (newViewName?.trim()) {
      onSaveView(newViewName?.trim(), filters);
      setNewViewName('');
      setShowSaveDialog(false);
    }
  };

  const handleBulkAction = (action) => {
    onBulkAction(action);
    setShowBulkMenu(false);
  };

  return (
    <div className="bg-card border-b border-border shadow-industrial">
      <div className="p-4">
        {/* Top Row - Main Actions */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-4">
            {/* Facility Selector - Only show if more than default option */}
            {facilityOptions?.length > 1 && (
              <Select
                options={facilityOptions}
                value={filters?.facility}
                onChange={(value) => onFilterChange('facility', value)}
                placeholder="Select facility"
                className="w-48"
              />
            )}

            {/* Saved Views */}
            <div className="flex items-center space-x-2">
              <Select
                options={savedViews?.map(view => ({ value: view?.id, label: view?.name }))}
                value={filters?.savedView}
                onChange={(value) => onLoadView(value)}
                placeholder="Load saved view"
                className="w-40"
              />
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowSaveDialog(true)}
                iconName="Save"
                iconPosition="left"
                disabled={!canEdit}
              >
                Save View
              </Button>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {/* Dynamic Compliance Status Summary */}
            <div className="flex items-center space-x-4 px-3 py-2 bg-muted rounded-lg">
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span className="text-xs text-muted-foreground">Compliant: 0</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-warning rounded-full"></div>
                <span className="text-xs text-muted-foreground">Warning: 0</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-error rounded-full"></div>
                <span className="text-xs text-muted-foreground">Critical: 0</span>
              </div>
            </div>

            {/* Export Options */}
            <div className="relative">
              <Button
                variant="outline"
                size="sm"
                iconName="Download"
                iconPosition="left"
                onClick={() => onExport('pdf')}
              >
                Export
              </Button>
            </div>
          </div>
        </div>

        {/* Bottom Row - Filters and Search */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            {/* Search */}
            <div className="relative">
              <Input
                type="search"
                placeholder="Search roles or training..."
                value={searchQuery}
                onChange={(e) => onSearchChange(e?.target?.value)}
                className="w-64 pl-10"
              />
              <Icon 
                name="Search" 
                size={16} 
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground"
              />
            </div>

            {/* Department Filter - Only show if more than default option */}
            {departmentOptions?.length > 1 && (
              <Select
                options={departmentOptions}
                value={filters?.department}
                onChange={(value) => onFilterChange('department', value)}
                placeholder="Filter by department"
                className="w-44"
              />
            )}

            {/* Compliance Filter */}
            <Select
              options={complianceOptions}
              value={filters?.compliance}
              onChange={(value) => onFilterChange('compliance', value)}
              placeholder="Filter by compliance"
              className="w-48"
            />

            {/* Clear Filters */}
            {(filters?.department !== 'all' || filters?.compliance !== 'all' || searchQuery) && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  onFilterChange('department', 'all');
                  onFilterChange('compliance', 'all');
                  onSearchChange('');
                }}
                iconName="X"
                iconPosition="left"
              >
                Clear
              </Button>
            )}
          </div>

          {/* Bulk Actions */}
          {canEdit && selectedCellsCount > 0 && (
            <div className="flex items-center space-x-2">
              <span className="text-sm text-muted-foreground">
                {selectedCellsCount} cells selected
              </span>
              <div className="relative">
                <Button
                  variant="default"
                  size="sm"
                  onClick={() => setShowBulkMenu(!showBulkMenu)}
                  iconName="Edit"
                  iconPosition="left"
                >
                  Bulk Actions
                </Button>
                
                {showBulkMenu && (
                  <>
                    <div
                      className="fixed inset-0 z-100"
                      onClick={() => setShowBulkMenu(false)}
                    />
                    <div className="absolute right-0 top-full mt-1 w-48 bg-popover border border-border rounded-lg shadow-industrial-strong z-200">
                      <div className="py-2">
                        {bulkActions?.map(action => (
                          <button
                            key={action?.value}
                            onClick={() => handleBulkAction(action?.value)}
                            className="w-full flex items-center space-x-2 px-3 py-2 text-sm hover:bg-muted transition-colors text-left"
                          >
                            <Icon name={action?.icon} size={14} />
                            <span>{action?.label}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Save View Dialog */}
      {showSaveDialog && (
        <>
          <div
            className="fixed inset-0 bg-black/50 z-200"
            onClick={() => setShowSaveDialog(false)}
          />
          <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 bg-card border border-border rounded-lg shadow-industrial-strong z-300">
            <div className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">
                Save Current View
              </h3>
              <Input
                label="View Name"
                type="text"
                placeholder="Enter view name..."
                value={newViewName}
                onChange={(e) => setNewViewName(e?.target?.value)}
                className="mb-4"
              />
              <div className="flex justify-end space-x-2">
                <Button
                  variant="outline"
                  onClick={() => setShowSaveDialog(false)}
                >
                  Cancel
                </Button>
                <Button
                  variant="default"
                  onClick={handleSaveView}
                  disabled={!newViewName?.trim()}
                >
                  Save View
                </Button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default MatrixToolbar;