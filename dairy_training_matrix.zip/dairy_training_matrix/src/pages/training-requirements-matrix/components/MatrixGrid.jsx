import React, { useState, useCallback, useMemo } from 'react';
import Icon from '../../../components/AppIcon';


const MatrixGrid = ({ 
  roles, 
  trainingCategories, 
  requirements, 
  onRequirementChange,
  selectedCells,
  onCellSelect,
  isReadOnly = false,
  userRole = 'training_coordinator'
}) => {
  const [hoveredCell, setHoveredCell] = useState(null);
  const [contextMenu, setContextMenu] = useState(null);

  const requirementTypes = {
    mandatory: { label: 'Mandatory', color: 'bg-red-100 border-red-300 text-red-800', icon: 'AlertCircle' },
    recommended: { label: 'Recommended', color: 'bg-green-100 border-green-300 text-green-800', icon: 'CheckCircle' },
    optional: { label: 'Optional', color: 'bg-yellow-100 border-yellow-300 text-yellow-800', icon: 'Clock' },
    none: { label: 'Not Required', color: 'bg-gray-50 border-gray-200 text-gray-500', icon: 'Minus' }
  };

  const getRequirement = useCallback((roleId, categoryId) => {
    return requirements?.find(req => req?.roleId === roleId && req?.categoryId === categoryId) || 
           { type: 'none', dueDate: null, completionRate: 0 };
  }, [requirements]);

  const handleCellClick = useCallback((roleId, categoryId, currentType) => {
    if (isReadOnly) return;
    
    const cellKey = `${roleId}-${categoryId}`;
    onCellSelect(cellKey, !selectedCells?.has(cellKey));
  }, [isReadOnly, selectedCells, onCellSelect]);

  const handleCellDoubleClick = useCallback((roleId, categoryId, currentType) => {
    if (isReadOnly) return;
    
    const typeOrder = ['none', 'optional', 'recommended', 'mandatory'];
    const currentIndex = typeOrder?.indexOf(currentType);
    const nextType = typeOrder?.[(currentIndex + 1) % typeOrder?.length];
    
    onRequirementChange(roleId, categoryId, nextType);
  }, [isReadOnly, onRequirementChange]);

  const handleContextMenu = useCallback((e, roleId, categoryId, currentType) => {
    if (isReadOnly) return;
    
    e?.preventDefault();
    setContextMenu({
      x: e?.clientX,
      y: e?.clientY,
      roleId,
      categoryId,
      currentType
    });
  }, [isReadOnly]);

  const handleContextMenuAction = useCallback((action, type) => {
    if (!contextMenu) return;
    
    if (action === 'change') {
      onRequirementChange(contextMenu?.roleId, contextMenu?.categoryId, type);
    }
    
    setContextMenu(null);
  }, [contextMenu, onRequirementChange]);

  const renderCell = useCallback((role, category) => {
    const requirement = getRequirement(role?.id, category?.id);
    const cellKey = `${role?.id}-${category?.id}`;
    const isSelected = selectedCells?.has(cellKey);
    const isHovered = hoveredCell === cellKey;
    const config = requirementTypes?.[requirement?.type];

    return (
      <td
        key={cellKey}
        className={`
          relative border border-border h-12 w-32 cursor-pointer transition-all duration-200
          ${config?.color}
          ${isSelected ? 'ring-2 ring-primary ring-offset-1' : ''}
          ${isHovered ? 'shadow-md scale-105' : ''}
          ${isReadOnly ? 'cursor-default' : 'hover:shadow-sm'}
        `}
        onClick={() => handleCellClick(role?.id, category?.id, requirement?.type)}
        onDoubleClick={() => handleCellDoubleClick(role?.id, category?.id, requirement?.type)}
        onContextMenu={(e) => handleContextMenu(e, role?.id, category?.id, requirement?.type)}
        onMouseEnter={() => setHoveredCell(cellKey)}
        onMouseLeave={() => setHoveredCell(null)}
        title={`${role?.name} - ${category?.name}: ${config?.label}${requirement?.dueDate ? `\nDue: ${requirement?.dueDate?.toLocaleDateString()}` : ''}${requirement?.completionRate > 0 ? `\nCompletion: ${requirement?.completionRate}%` : ''}`}
      >
        <div className="flex items-center justify-center h-full">
          <div className="flex items-center space-x-1">
            <Icon name={config?.icon} size={14} />
            {requirement?.completionRate > 0 && (
              <span className="text-xs font-medium text-data">
                {requirement?.completionRate}%
              </span>
            )}
          </div>
          
          {requirement?.type === 'mandatory' && requirement?.dueDate && (
            <div className="absolute top-0 right-0 w-2 h-2 bg-error rounded-full"></div>
          )}
        </div>
      </td>
    );
  }, [getRequirement, selectedCells, hoveredCell, handleCellClick, handleCellDoubleClick, handleContextMenu, isReadOnly]);

  return (
    <div className="relative">
      <div className="overflow-auto border border-border rounded-lg bg-card shadow-industrial">
        <table className="w-full">
          <thead className="sticky top-0 bg-muted z-10">
            <tr>
              <th className="sticky left-0 bg-muted border-r border-border p-3 text-left font-medium text-foreground min-w-48">
                Job Roles
              </th>
              {trainingCategories?.map(category => (
                <th
                  key={category?.id}
                  className="border-r border-border p-3 text-center font-medium text-foreground min-w-32"
                  title={category?.description}
                >
                  <div className="flex flex-col items-center space-y-1">
                    <Icon name={category?.icon} size={16} />
                    <span className="text-xs leading-tight">{category?.name}</span>
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {roles?.map(role => (
              <tr key={role?.id} className="hover:bg-muted/50 transition-colors">
                <td className="sticky left-0 bg-card border-r border-border p-3 font-medium text-foreground">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">{role?.name}</div>
                      <div className="text-xs text-muted-foreground">
                        {role?.employeeCount} employees
                      </div>
                    </div>
                    <div className="flex items-center space-x-1">
                      <div className={`w-2 h-2 rounded-full ${
                        role?.complianceRate >= 90 ? 'bg-success' :
                        role?.complianceRate >= 70 ? 'bg-warning' : 'bg-error'
                      }`}></div>
                      <span className="text-xs text-data font-medium">
                        {role?.complianceRate}%
                      </span>
                    </div>
                  </div>
                </td>
                {trainingCategories?.map(category => renderCell(role, category))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {/* Context Menu */}
      {contextMenu && (
        <>
          <div
            className="fixed inset-0 z-200"
            onClick={() => setContextMenu(null)}
          />
          <div
            className="fixed z-300 bg-popover border border-border rounded-lg shadow-industrial-strong py-2 min-w-48"
            style={{ left: contextMenu?.x, top: contextMenu?.y }}
          >
            <div className="px-3 py-2 text-xs font-medium text-muted-foreground border-b border-border">
              Change Requirement Type
            </div>
            {Object.entries(requirementTypes)?.map(([type, config]) => (
              <button
                key={type}
                onClick={() => handleContextMenuAction('change', type)}
                className={`
                  w-full flex items-center space-x-2 px-3 py-2 text-sm hover:bg-muted transition-colors
                  ${contextMenu?.currentType === type ? 'bg-muted font-medium' : ''}
                `}
              >
                <Icon name={config?.icon} size={14} />
                <span>{config?.label}</span>
              </button>
            ))}
          </div>
        </>
      )}
      {/* Legend */}
      <div className="mt-4 flex items-center justify-center space-x-6 p-3 bg-muted rounded-lg">
        {Object.entries(requirementTypes)?.map(([type, config]) => (
          <div key={type} className="flex items-center space-x-2">
            <div className={`w-4 h-4 rounded border-2 ${config?.color}`}>
              <Icon name={config?.icon} size={12} className="w-full h-full" />
            </div>
            <span className="text-sm text-foreground">{config?.label}</span>
          </div>
        ))}
      </div>
      {/* Keyboard Shortcuts Help */}
      <div className="mt-2 text-xs text-muted-foreground text-center">
        <span className="font-medium">Shortcuts:</span> Double-click to cycle requirements • Right-click for menu • Arrow keys to navigate • Space to toggle
      </div>
    </div>
  );
};

export default MatrixGrid;