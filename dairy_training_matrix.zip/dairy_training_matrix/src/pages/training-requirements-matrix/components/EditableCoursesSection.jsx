import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const EditableCoursesSection = ({ 
  courses = [], 
  onAddCourse, 
  onEditCourse, 
  onDeleteCourse,
  canEdit = true 
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingCourse, setEditingCourse] = useState(null);
  const [newCourse, setNewCourse] = useState({
    name: '',
    description: '',
    icon: 'BookOpen',
    category: 'safety',
    duration: '',
    prerequisites: ''
  });

  const iconOptions = [
    { value: 'Shield', label: 'Shield (Safety)' },
    { value: 'CheckSquare', label: 'Check Square (Compliance)' },
    { value: 'Settings', label: 'Settings (Equipment)' },
    { value: 'Target', label: 'Target (Quality)' },
    { value: 'AlertTriangle', label: 'Alert (Emergency)' },
    { value: 'FileText', label: 'File (Regulatory)' },
    { value: 'Truck', label: 'Truck (Transportation)' },
    { value: 'UserPlus', label: 'User Plus (Onboarding)' },
    { value: 'BookOpen', label: 'Book (General Training)' },
    { value: 'Award', label: 'Award (Certification)' }
  ];

  const categoryOptions = [
    { value: 'safety', label: 'Safety & Compliance' },
    { value: 'technical', label: 'Technical Skills' },
    { value: 'quality', label: 'Quality Control' },
    { value: 'regulatory', label: 'Regulatory Compliance' },
    { value: 'operational', label: 'Operational Procedures' },
    { value: 'leadership', label: 'Leadership & Management' }
  ];

  const handleAddCourse = () => {
    if (newCourse?.name?.trim()) {
      const course = {
        id: `course-${Date?.now()}`,
        ...newCourse,
        createdAt: new Date()?.toISOString()
      };
      onAddCourse?.(course);
      setNewCourse({ name: '', description: '', icon: 'BookOpen', category: 'safety', duration: '', prerequisites: '' });
      setShowAddModal(false);
    }
  };

  const handleEditCourse = () => {
    if (editingCourse && editingCourse?.name?.trim()) {
      onEditCourse?.(editingCourse);
      setEditingCourse(null);
    }
  };

  const handleDeleteCourse = (id) => {
    onDeleteCourse?.(id);
  };

  const EmptyState = () => (
    <div className="text-center py-8">
      <Icon name="BookOpen" size={48} className="mx-auto text-muted-foreground mb-4" />
      <h3 className="text-lg font-medium text-foreground mb-2">No Training Courses</h3>
      <p className="text-muted-foreground mb-4">
        Add training courses that will be available for assignment to different job roles in your organization.
      </p>
      {canEdit && (
        <Button
          onClick={() => setShowAddModal(true)}
          iconName="Plus"
          iconPosition="left"
        >
          Add First Course
        </Button>
      )}
    </div>
  );

  return (
    <div className="bg-card rounded-lg border border-border shadow-industrial p-6 mb-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-xl font-semibold text-foreground flex items-center space-x-2">
            <Icon name="BookOpen" size={20} />
            <span>Training Courses</span>
          </h2>
          <p className="text-muted-foreground text-sm mt-1">
            Manage available training courses for your organization
          </p>
        </div>
        {canEdit && courses?.length > 0 && (
          <Button
            onClick={() => setShowAddModal(true)}
            size="sm"
            iconName="Plus"
            iconPosition="left"
          >
            Add Course
          </Button>
        )}
      </div>

      {courses?.length === 0 ? (
        <EmptyState />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {courses?.map(course => (
            <div
              key={course?.id}
              className="bg-muted rounded-lg p-4 border border-border hover:shadow-sm transition-shadow"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <Icon name={course?.icon} size={16} className="text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium text-foreground">{course?.name}</h3>
                    <span className="text-xs text-muted-foreground capitalize">
                      {course?.category}
                    </span>
                  </div>
                </div>
                {canEdit && (
                  <div className="flex items-center space-x-1 ml-2">
                    <button
                      onClick={() => setEditingCourse({ ...course })}
                      className="p-1 hover:bg-background rounded transition-colors"
                    >
                      <Icon name="Edit" size={14} />
                    </button>
                    <button
                      onClick={() => handleDeleteCourse(course?.id)}
                      className="p-1 hover:bg-background rounded transition-colors text-error"
                    >
                      <Icon name="Trash2" size={14} />
                    </button>
                  </div>
                )}
              </div>
              
              <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                {course?.description}
              </p>
              
              <div className="space-y-2 text-xs">
                {course?.duration && (
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Duration:</span>
                    <span className="font-medium text-foreground">{course?.duration}</span>
                  </div>
                )}
                
                {course?.prerequisites && (
                  <div className="flex items-start justify-between">
                    <span className="text-muted-foreground">Prerequisites:</span>
                    <span className="font-medium text-foreground text-right text-wrap max-w-32">
                      {course?.prerequisites}
                    </span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Course Modal */}
      {showAddModal && (
        <>
          <div
            className="fixed inset-0 bg-black/50 z-200"
            onClick={() => setShowAddModal(false)}
          />
          <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 bg-card border border-border rounded-lg shadow-industrial-strong z-300">
            <div className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">
                Add Training Course
              </h3>
              <div className="space-y-4">
                <Input
                  label="Course Name"
                  type="text"
                  placeholder="Enter course name..."
                  value={newCourse?.name}
                  onChange={(e) => setNewCourse(prev => ({ ...prev, name: e?.target?.value }))}
                />
                <Input
                  label="Description"
                  type="text"
                  placeholder="Course description..."
                  value={newCourse?.description}
                  onChange={(e) => setNewCourse(prev => ({ ...prev, description: e?.target?.value }))}
                />
                <Select
                  label="Category"
                  options={categoryOptions}
                  value={newCourse?.category}
                  onChange={(value) => setNewCourse(prev => ({ ...prev, category: value }))}
                />
                <Select
                  label="Icon"
                  options={iconOptions}
                  value={newCourse?.icon}
                  onChange={(value) => setNewCourse(prev => ({ ...prev, icon: value }))}
                />
                <Input
                  label="Duration"
                  type="text"
                  placeholder="e.g. 2 hours, 1 day..."
                  value={newCourse?.duration}
                  onChange={(e) => setNewCourse(prev => ({ ...prev, duration: e?.target?.value }))}
                />
                <Input
                  label="Prerequisites"
                  type="text"
                  placeholder="Any prerequisites..."
                  value={newCourse?.prerequisites}
                  onChange={(e) => setNewCourse(prev => ({ ...prev, prerequisites: e?.target?.value }))}
                />
              </div>
              <div className="flex justify-end space-x-2 mt-6">
                <Button
                  variant="outline"
                  onClick={() => setShowAddModal(false)}
                >
                  Cancel
                </Button>
                <Button
                  variant="default"
                  onClick={handleAddCourse}
                  disabled={!newCourse?.name?.trim()}
                >
                  Add Course
                </Button>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Edit Course Modal */}
      {editingCourse && (
        <>
          <div
            className="fixed inset-0 bg-black/50 z-200"
            onClick={() => setEditingCourse(null)}
          />
          <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 bg-card border border-border rounded-lg shadow-industrial-strong z-300">
            <div className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">
                Edit Training Course
              </h3>
              <div className="space-y-4">
                <Input
                  label="Course Name"
                  type="text"
                  placeholder="Enter course name..."
                  value={editingCourse?.name}
                  onChange={(e) => setEditingCourse(prev => ({ ...prev, name: e?.target?.value }))}
                />
                <Input
                  label="Description"
                  type="text"
                  placeholder="Course description..."
                  value={editingCourse?.description}
                  onChange={(e) => setEditingCourse(prev => ({ ...prev, description: e?.target?.value }))}
                />
                <Select
                  label="Category"
                  options={categoryOptions}
                  value={editingCourse?.category}
                  onChange={(value) => setEditingCourse(prev => ({ ...prev, category: value }))}
                />
                <Select
                  label="Icon"
                  options={iconOptions}
                  value={editingCourse?.icon}
                  onChange={(value) => setEditingCourse(prev => ({ ...prev, icon: value }))}
                />
                <Input
                  label="Duration"
                  type="text"
                  placeholder="e.g. 2 hours, 1 day..."
                  value={editingCourse?.duration}
                  onChange={(e) => setEditingCourse(prev => ({ ...prev, duration: e?.target?.value }))}
                />
                <Input
                  label="Prerequisites"
                  type="text"
                  placeholder="Any prerequisites..."
                  value={editingCourse?.prerequisites}
                  onChange={(e) => setEditingCourse(prev => ({ ...prev, prerequisites: e?.target?.value }))}
                />
              </div>
              <div className="flex justify-end space-x-2 mt-6">
                <Button
                  variant="outline"
                  onClick={() => setEditingCourse(null)}
                >
                  Cancel
                </Button>
                <Button
                  variant="default"
                  onClick={handleEditCourse}
                  disabled={!editingCourse?.name?.trim()}
                >
                  Save Changes
                </Button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default EditableCoursesSection;