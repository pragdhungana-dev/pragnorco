import React, { useState, useEffect } from 'react';
import Header from '../../components/ui/Header';
import RoleBasedSidebar from '../../components/ui/RoleBasedSidebar';
import DepartmentNavigation from './components/DepartmentNavigation';
import EmployeeGrid from './components/EmployeeGrid';
import EmployeeDetailPanel from './components/EmployeeDetailPanel';
import BulkOperationsToolbar from './components/BulkOperationsToolbar';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const EmployeeTrainingDashboard = () => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [selectedDepartment, setSelectedDepartment] = useState(null);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [selectedEmployees, setSelectedEmployees] = useState([]);
  const [showDetailPanel, setShowDetailPanel] = useState(false);
  const [userRole] = useState('training_coordinator');

  // Auto-close mobile menu on desktop
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setIsMobileMenuOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handleDepartmentSelect = (department) => {
    setSelectedDepartment(department);
    setSelectedEmployee(null);
    setShowDetailPanel(false);
    setSelectedEmployees([]);
  };

  const handleEmployeeSelect = (employee) => {
    setSelectedEmployee(employee);
    setShowDetailPanel(true);
  };

  const handleEmployeeSelectionChange = (employeeIds) => {
    setSelectedEmployees(employeeIds);
  };

  const handleClearSelection = () => {
    setSelectedEmployees([]);
  };

  const handleCloseDetailPanel = () => {
    setShowDetailPanel(false);
    setSelectedEmployee(null);
  };

  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <Header 
        onMenuToggle={toggleMobileMenu}
        isMenuOpen={isMobileMenuOpen}
      />
      {/* Main Layout */}
      <div className="flex pt-16">
        {/* Sidebar */}
        <RoleBasedSidebar
          isCollapsed={isSidebarCollapsed}
          onToggleCollapse={toggleSidebar}
          userRole={userRole}
          className="hidden lg:block"
        />

        {/* Mobile Sidebar Overlay */}
        {isMobileMenuOpen && (
          <div className="lg:hidden fixed inset-0 top-16 z-50">
            <div className="absolute inset-0 bg-background/80 backdrop-blur-sm" onClick={toggleMobileMenu} />
            <div className="relative w-64 h-full">
              <RoleBasedSidebar
                isCollapsed={false}
                onToggleCollapse={() => {}}
                userRole={userRole}
              />
            </div>
          </div>
        )}

        {/* Main Content Area */}
        <div 
          className={`flex-1 transition-all duration-200 ${
            isSidebarCollapsed ? 'lg:ml-16' : 'lg:ml-60'
          }`}
        >
          <div className="h-screen flex">
            {/* Left Panel - Department Navigation */}
            <div className="w-80 hidden xl:block">
              <DepartmentNavigation
                selectedDepartment={selectedDepartment}
                onDepartmentSelect={handleDepartmentSelect}
                onEmployeeSelect={handleEmployeeSelect}
              />
            </div>

            {/* Center Panel - Employee Grid */}
            <div className="flex-1 flex flex-col">
              {/* Page Header */}
              <div className="p-6 border-b border-border bg-card">
                <div className="flex items-center justify-between">
                  <div>
                    <h1 className="text-2xl font-semibold text-foreground">
                      Employee Training Dashboard
                    </h1>
                    <p className="text-muted-foreground mt-1">
                      Monitor and manage employee training compliance across all departments
                    </p>
                  </div>
                  <div className="flex items-center space-x-3">
                    {/* Mobile Department Toggle */}
                    <Button
                      variant="outline"
                      size="sm"
                      className="xl:hidden"
                      iconName="Building"
                      iconPosition="left"
                    >
                      Departments
                    </Button>
                    
                    {/* Quick Actions */}
                    <Button
                      variant="outline"
                      size="sm"
                      iconName="Plus"
                      iconPosition="left"
                    >
                      Add Employee
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      iconName="Upload"
                      iconPosition="left"
                    >
                      Import Data
                    </Button>
                    <Button
                      variant="default"
                      size="sm"
                      iconName="Download"
                      iconPosition="left"
                    >
                      Export Report
                    </Button>
                  </div>
                </div>

                {/* Department Info Bar */}
                {selectedDepartment && (
                  <div className="mt-4 p-3 bg-primary/5 border border-primary/20 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Icon name={selectedDepartment?.icon} size={20} className="text-primary" />
                        <div>
                          <div className="font-medium text-foreground">
                            {selectedDepartment?.name}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {selectedDepartment?.employeeCount} employees • {selectedDepartment?.complianceRate}% compliance
                          </div>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setSelectedDepartment(null)}
                        iconName="X"
                      >
                        Clear Filter
                      </Button>
                    </div>
                  </div>
                )}
              </div>

              {/* Bulk Operations Toolbar */}
              {selectedEmployees?.length > 0 && (
                <div className="p-4 border-b border-border">
                  <BulkOperationsToolbar
                    selectedEmployees={selectedEmployees}
                    onClearSelection={handleClearSelection}
                  />
                </div>
              )}

              {/* Employee Grid */}
              <div className="flex-1">
                <EmployeeGrid
                  selectedDepartment={selectedDepartment}
                  onEmployeeSelect={handleEmployeeSelect}
                  selectedEmployees={selectedEmployees}
                  onEmployeeSelectionChange={handleEmployeeSelectionChange}
                />
              </div>
            </div>

            {/* Right Panel - Employee Details */}
            {showDetailPanel && (
              <div className="w-96 hidden lg:block">
                <EmployeeDetailPanel
                  selectedEmployee={selectedEmployee}
                  onClose={handleCloseDetailPanel}
                />
              </div>
            )}
          </div>
        </div>
      </div>
      {/* Mobile Employee Detail Modal */}
      {showDetailPanel && selectedEmployee && (
        <div className="lg:hidden fixed inset-0 top-16 z-50 bg-background">
          <EmployeeDetailPanel
            selectedEmployee={selectedEmployee}
            onClose={handleCloseDetailPanel}
          />
        </div>
      )}
      {/* Floating Action Button for Mobile */}
      <div className="lg:hidden fixed bottom-6 right-6 z-40">
        <Button
          variant="default"
          size="lg"
          className="rounded-full shadow-industrial-strong"
          iconName="Plus"
        >
          Quick Action
        </Button>
      </div>
    </div>
  );
};

export default EmployeeTrainingDashboard;