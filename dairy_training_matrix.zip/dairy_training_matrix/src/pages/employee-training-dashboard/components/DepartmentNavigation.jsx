import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';


const DepartmentNavigation = ({ 
  selectedDepartment, 
  onDepartmentSelect, 
  onEmployeeSelect,
  className = '' 
}) => {
  const [expandedDepartments, setExpandedDepartments] = useState({
    production: true,
    quality: false,
    maintenance: false,
    safety: false,
    management: false
  });

  const departmentData = [
    {
      id: 'production',
      name: 'Production Team',
      icon: 'Factory',
      employeeCount: 45,
      complianceRate: 87,
      overdue: 8,
      employees: [
        { id: 'emp001', name: 'John Martinez', role: 'Machine Operator', compliance: 92 },
        { id: 'emp002', name: 'Sarah Johnson', role: 'Production Supervisor', compliance: 98 },
        { id: 'emp003', name: 'Mike Chen', role: 'Line Worker', compliance: 78 },
        { id: 'emp004', name: 'Lisa Rodriguez', role: 'Quality Inspector', compliance: 95 },
        { id: 'emp005', name: 'David Kim', role: 'Machine Operator', compliance: 85 }
      ]
    },
    {
      id: 'quality',
      name: 'Quality Control',
      icon: 'CheckCircle',
      employeeCount: 12,
      complianceRate: 95,
      overdue: 1,
      employees: [
        { id: 'emp006', name: 'Emma Wilson', role: 'QC Manager', compliance: 100 },
        { id: 'emp007', name: 'Robert Taylor', role: 'Lab Technician', compliance: 92 },
        { id: 'emp008', name: 'Jennifer Brown', role: 'Quality Analyst', compliance: 88 }
      ]
    },
    {
      id: 'maintenance',
      name: 'Maintenance Team',
      icon: 'Wrench',
      employeeCount: 18,
      complianceRate: 82,
      overdue: 5,
      employees: [
        { id: 'emp009', name: 'Carlos Mendez', role: 'Maintenance Supervisor', compliance: 96 },
        { id: 'emp010', name: 'Tom Anderson', role: 'Technician', compliance: 75 },
        { id: 'emp011', name: 'Maria Garcia', role: 'Electrician', compliance: 88 }
      ]
    },
    {
      id: 'safety',
      name: 'Safety Officers',
      icon: 'Shield',
      employeeCount: 8,
      complianceRate: 98,
      overdue: 0,
      employees: [
        { id: 'emp012', name: 'James Wilson', role: 'Safety Manager', compliance: 100 },
        { id: 'emp013', name: 'Anna Thompson', role: 'Safety Officer', compliance: 96 }
      ]
    },
    {
      id: 'management',
      name: 'Management',
      icon: 'Users',
      employeeCount: 15,
      complianceRate: 93,
      overdue: 2,
      employees: [
        { id: 'emp014', name: 'Richard Davis', role: 'Plant Manager', compliance: 100 },
        { id: 'emp015', name: 'Susan Miller', role: 'HR Manager', compliance: 89 },
        { id: 'emp016', name: 'Kevin Lee', role: 'Operations Manager', compliance: 91 }
      ]
    }
  ];

  const toggleDepartment = (departmentId) => {
    setExpandedDepartments(prev => ({
      ...prev,
      [departmentId]: !prev?.[departmentId]
    }));
  };

  const getComplianceColor = (rate) => {
    if (rate >= 95) return 'text-success';
    if (rate >= 85) return 'text-warning';
    return 'text-error';
  };

  const handleEmployeeClick = (employee, department) => {
    onEmployeeSelect({
      ...employee,
      department: department?.name,
      departmentId: department?.id
    });
  };

  return (
    <div className={`bg-card border-r border-border h-full overflow-y-auto ${className}`}>
      <div className="p-4 border-b border-border">
        <h2 className="text-lg font-semibold text-foreground mb-2">Departments</h2>
        <div className="text-sm text-muted-foreground">
          Total Employees: {departmentData?.reduce((sum, dept) => sum + dept?.employeeCount, 0)}
        </div>
      </div>
      <div className="p-2">
        {departmentData?.map((department) => (
          <div key={department?.id} className="mb-2">
            {/* Department Header */}
            <button
              onClick={() => {
                toggleDepartment(department?.id);
                onDepartmentSelect(department);
              }}
              className={`w-full flex items-center justify-between p-3 rounded-lg hover:bg-muted transition-colors ${
                selectedDepartment?.id === department?.id ? 'bg-primary/10 border border-primary/20' : ''
              }`}
            >
              <div className="flex items-center space-x-3">
                <Icon name={department?.icon} size={16} className="text-muted-foreground" />
                <div className="text-left">
                  <div className="font-medium text-foreground text-sm">
                    {department?.name}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {department?.employeeCount} employees
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <div className="text-right">
                  <div className={`text-sm font-medium ${getComplianceColor(department?.complianceRate)}`}>
                    {department?.complianceRate}%
                  </div>
                  {department?.overdue > 0 && (
                    <div className="text-xs text-error">
                      {department?.overdue} overdue
                    </div>
                  )}
                </div>
                <Icon 
                  name={expandedDepartments?.[department?.id] ? 'ChevronDown' : 'ChevronRight'} 
                  size={14} 
                  className="text-muted-foreground"
                />
              </div>
            </button>

            {/* Employee List */}
            {expandedDepartments?.[department?.id] && (
              <div className="ml-6 mt-2 space-y-1">
                {department?.employees?.map((employee) => (
                  <button
                    key={employee?.id}
                    onClick={() => handleEmployeeClick(employee, department)}
                    className="w-full flex items-center justify-between p-2 rounded hover:bg-muted/50 transition-colors text-left"
                  >
                    <div className="flex items-center space-x-2">
                      <div className="w-6 h-6 bg-muted rounded-full flex items-center justify-center">
                        <span className="text-xs font-medium text-muted-foreground">
                          {employee?.name?.split(' ')?.map(n => n?.[0])?.join('')}
                        </span>
                      </div>
                      <div>
                        <div className="text-sm font-medium text-foreground">
                          {employee?.name}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {employee?.role}
                        </div>
                      </div>
                    </div>
                    <div className={`text-xs font-medium ${getComplianceColor(employee?.compliance)}`}>
                      {employee?.compliance}%
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default DepartmentNavigation;