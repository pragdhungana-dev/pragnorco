import React, { useState, useMemo } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';
import Image from '../../../components/AppImage';

const EmployeeGrid = ({ 
  selectedDepartment, 
  onEmployeeSelect, 
  selectedEmployees,
  onEmployeeSelectionChange,
  className = '' 
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortBy, setSortBy] = useState('name');
  const [sortOrder, setSortOrder] = useState('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(25);

  const allEmployees = [
    {
      id: 'emp001',
      name: 'John Martinez',
      role: 'Machine Operator',
      department: 'Production Team',
      email: 'john.martinez@dairyplant.com',
      avatar: 'https://randomuser.me/api/portraits/men/1.jpg',
      compliance: 92,
      overdue: 1,
      upcoming: 2,
      completed: 15,
      lastTraining: new Date('2024-08-15'),
      nextDeadline: new Date('2024-09-10'),
      status: 'active'
    },
    {
      id: 'emp002',
      name: 'Sarah Johnson',
      role: 'Production Supervisor',
      department: 'Production Team',
      email: 'sarah.johnson@dairyplant.com',
      avatar: 'https://randomuser.me/api/portraits/women/2.jpg',
      compliance: 98,
      overdue: 0,
      upcoming: 1,
      completed: 22,
      lastTraining: new Date('2024-08-20'),
      nextDeadline: new Date('2024-09-15'),
      status: 'active'
    },
    {
      id: 'emp003',
      name: 'Mike Chen',
      role: 'Line Worker',
      department: 'Production Team',
      email: 'mike.chen@dairyplant.com',
      avatar: 'https://randomuser.me/api/portraits/men/3.jpg',
      compliance: 78,
      overdue: 3,
      upcoming: 1,
      completed: 12,
      lastTraining: new Date('2024-07-28'),
      nextDeadline: new Date('2024-08-30'),
      status: 'active'
    },
    {
      id: 'emp004',
      name: 'Lisa Rodriguez',
      role: 'Quality Inspector',
      department: 'Quality Control',
      email: 'lisa.rodriguez@dairyplant.com',
      avatar: 'https://randomuser.me/api/portraits/women/4.jpg',
      compliance: 95,
      overdue: 0,
      upcoming: 2,
      completed: 18,
      lastTraining: new Date('2024-08-18'),
      nextDeadline: new Date('2024-09-12'),
      status: 'active'
    },
    {
      id: 'emp005',
      name: 'David Kim',
      role: 'Machine Operator',
      department: 'Production Team',
      email: 'david.kim@dairyplant.com',
      avatar: 'https://randomuser.me/api/portraits/men/5.jpg',
      compliance: 85,
      overdue: 2,
      upcoming: 3,
      completed: 14,
      lastTraining: new Date('2024-08-10'),
      nextDeadline: new Date('2024-09-05'),
      status: 'active'
    },
    {
      id: 'emp006',
      name: 'Emma Wilson',
      role: 'QC Manager',
      department: 'Quality Control',
      email: 'emma.wilson@dairyplant.com',
      avatar: 'https://randomuser.me/api/portraits/women/6.jpg',
      compliance: 100,
      overdue: 0,
      upcoming: 1,
      completed: 25,
      lastTraining: new Date('2024-08-22'),
      nextDeadline: new Date('2024-09-20'),
      status: 'active'
    },
    {
      id: 'emp007',
      name: 'Robert Taylor',
      role: 'Lab Technician',
      department: 'Quality Control',
      email: 'robert.taylor@dairyplant.com',
      avatar: 'https://randomuser.me/api/portraits/men/7.jpg',
      compliance: 92,
      overdue: 1,
      upcoming: 2,
      completed: 16,
      lastTraining: new Date('2024-08-12'),
      nextDeadline: new Date('2024-09-08'),
      status: 'active'
    },
    {
      id: 'emp008',
      name: 'Jennifer Brown',
      role: 'Quality Analyst',
      department: 'Quality Control',
      email: 'jennifer.brown@dairyplant.com',
      avatar: 'https://randomuser.me/api/portraits/women/8.jpg',
      compliance: 88,
      overdue: 1,
      upcoming: 3,
      completed: 13,
      lastTraining: new Date('2024-08-05'),
      nextDeadline: new Date('2024-09-02'),
      status: 'active'
    }
  ];

  const statusOptions = [
    { value: 'all', label: 'All Employees' },
    { value: 'compliant', label: 'Compliant (≥95%)' },
    { value: 'warning', label: 'Warning (85-94%)' },
    { value: 'critical', label: 'Critical (<85%)' },
    { value: 'overdue', label: 'Has Overdue Training' }
  ];

  const sortOptions = [
    { value: 'name', label: 'Name' },
    { value: 'compliance', label: 'Compliance %' },
    { value: 'overdue', label: 'Overdue Count' },
    { value: 'nextDeadline', label: 'Next Deadline' },
    { value: 'department', label: 'Department' }
  ];

  const filteredEmployees = useMemo(() => {
    let filtered = allEmployees;

    // Department filter
    if (selectedDepartment) {
      filtered = filtered?.filter(emp => emp?.department === selectedDepartment?.name);
    }

    // Search filter
    if (searchTerm) {
      filtered = filtered?.filter(emp =>
        emp?.name?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
        emp?.role?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
        emp?.email?.toLowerCase()?.includes(searchTerm?.toLowerCase())
      );
    }

    // Status filter
    if (statusFilter !== 'all') {
      filtered = filtered?.filter(emp => {
        switch (statusFilter) {
          case 'compliant':
            return emp?.compliance >= 95;
          case 'warning':
            return emp?.compliance >= 85 && emp?.compliance < 95;
          case 'critical':
            return emp?.compliance < 85;
          case 'overdue':
            return emp?.overdue > 0;
          default:
            return true;
        }
      });
    }

    // Sort
    filtered?.sort((a, b) => {
      let aVal = a?.[sortBy];
      let bVal = b?.[sortBy];

      if (sortBy === 'nextDeadline') {
        aVal = new Date(aVal);
        bVal = new Date(bVal);
      }

      if (typeof aVal === 'string') {
        aVal = aVal?.toLowerCase();
        bVal = bVal?.toLowerCase();
      }

      if (sortOrder === 'asc') {
        return aVal > bVal ? 1 : -1;
      } else {
        return aVal < bVal ? 1 : -1;
      }
    });

    return filtered;
  }, [allEmployees, selectedDepartment, searchTerm, statusFilter, sortBy, sortOrder]);

  const paginatedEmployees = useMemo(() => {
    const startIndex = (currentPage - 1) * pageSize;
    return filteredEmployees?.slice(startIndex, startIndex + pageSize);
  }, [filteredEmployees, currentPage, pageSize]);

  const totalPages = Math.ceil(filteredEmployees?.length / pageSize);

  const getComplianceColor = (compliance) => {
    if (compliance >= 95) return 'text-success';
    if (compliance >= 85) return 'text-warning';
    return 'text-error';
  };

  const getComplianceBadge = (compliance) => {
    if (compliance >= 95) return 'bg-success/10 text-success border-success/20';
    if (compliance >= 85) return 'bg-warning/10 text-warning border-warning/20';
    return 'bg-error/10 text-error border-error/20';
  };

  const formatDate = (date) => {
    return new Date(date)?.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric'
    });
  };

  const handleSelectAll = (checked) => {
    if (checked) {
      const allIds = paginatedEmployees?.map(emp => emp?.id);
      onEmployeeSelectionChange([...new Set([...selectedEmployees, ...allIds])]);
    } else {
      const currentPageIds = paginatedEmployees?.map(emp => emp?.id);
      onEmployeeSelectionChange(selectedEmployees?.filter(id => !currentPageIds?.includes(id)));
    }
  };

  const handleEmployeeSelect = (employeeId, checked) => {
    if (checked) {
      onEmployeeSelectionChange([...selectedEmployees, employeeId]);
    } else {
      onEmployeeSelectionChange(selectedEmployees?.filter(id => id !== employeeId));
    }
  };

  const isAllSelected = paginatedEmployees?.length > 0 && 
    paginatedEmployees?.every(emp => selectedEmployees?.includes(emp?.id));

  const isIndeterminate = paginatedEmployees?.some(emp => selectedEmployees?.includes(emp?.id)) && !isAllSelected;

  return (
    <div className={`bg-card h-full flex flex-col ${className}`}>
      {/* Header with Filters */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-foreground">
            Employee Training Status
          </h2>
          <div className="text-sm text-muted-foreground">
            {filteredEmployees?.length} of {allEmployees?.length} employees
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Input
            type="search"
            placeholder="Search employees..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e?.target?.value)}
            className="md:col-span-2"
          />
          
          <Select
            options={statusOptions}
            value={statusFilter}
            onChange={setStatusFilter}
            placeholder="Filter by status"
          />

          <div className="flex items-center space-x-2">
            <Select
              options={sortOptions}
              value={sortBy}
              onChange={setSortBy}
              placeholder="Sort by"
            />
            <Button
              variant="outline"
              size="icon"
              onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
              title={`Sort ${sortOrder === 'asc' ? 'descending' : 'ascending'}`}
            >
              <Icon name={sortOrder === 'asc' ? 'ArrowUp' : 'ArrowDown'} size={16} />
            </Button>
          </div>
        </div>
      </div>
      {/* Employee Grid */}
      <div className="flex-1 overflow-auto">
        <div className="min-w-full">
          {/* Table Header */}
          <div className="sticky top-0 bg-muted/50 border-b border-border p-4">
            <div className="grid grid-cols-12 gap-4 items-center text-sm font-medium text-muted-foreground">
              <div className="col-span-1">
                <Checkbox
                  checked={isAllSelected}
                  indeterminate={isIndeterminate}
                  onChange={(e) => handleSelectAll(e?.target?.checked)}
                />
              </div>
              <div className="col-span-3">Employee</div>
              <div className="col-span-2">Department</div>
              <div className="col-span-2">Compliance</div>
              <div className="col-span-2">Training Status</div>
              <div className="col-span-2">Next Deadline</div>
            </div>
          </div>

          {/* Employee Rows */}
          <div className="divide-y divide-border">
            {paginatedEmployees?.map((employee) => (
              <div
                key={employee?.id}
                className="p-4 hover:bg-muted/30 transition-colors cursor-pointer"
                onClick={() => onEmployeeSelect(employee)}
              >
                <div className="grid grid-cols-12 gap-4 items-center">
                  <div className="col-span-1" onClick={(e) => e?.stopPropagation()}>
                    <Checkbox
                      checked={selectedEmployees?.includes(employee?.id)}
                      onChange={(e) => handleEmployeeSelect(employee?.id, e?.target?.checked)}
                    />
                  </div>
                  
                  <div className="col-span-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 rounded-full overflow-hidden bg-muted">
                        <Image
                          src={employee?.avatar}
                          alt={employee?.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <div className="font-medium text-foreground">
                          {employee?.name}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {employee?.role}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="col-span-2">
                    <div className="text-sm text-foreground">
                      {employee?.department}
                    </div>
                  </div>

                  <div className="col-span-2">
                    <div className="flex items-center space-x-2">
                      <div className={`text-lg font-semibold ${getComplianceColor(employee?.compliance)}`}>
                        {employee?.compliance}%
                      </div>
                      <div className={`px-2 py-1 rounded-full text-xs font-medium border ${getComplianceBadge(employee?.compliance)}`}>
                        {employee?.compliance >= 95 ? 'Compliant' : 
                         employee?.compliance >= 85 ? 'Warning' : 'Critical'}
                      </div>
                    </div>
                  </div>

                  <div className="col-span-2">
                    <div className="flex items-center space-x-4 text-sm">
                      {employee?.overdue > 0 && (
                        <div className="flex items-center space-x-1 text-error">
                          <Icon name="AlertTriangle" size={14} />
                          <span>{employee?.overdue} overdue</span>
                        </div>
                      )}
                      {employee?.upcoming > 0 && (
                        <div className="flex items-center space-x-1 text-warning">
                          <Icon name="Clock" size={14} />
                          <span>{employee?.upcoming} upcoming</span>
                        </div>
                      )}
                      <div className="flex items-center space-x-1 text-success">
                        <Icon name="CheckCircle" size={14} />
                        <span>{employee?.completed} completed</span>
                      </div>
                    </div>
                  </div>

                  <div className="col-span-2">
                    <div className="text-sm text-foreground">
                      {formatDate(employee?.nextDeadline)}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {Math.ceil((new Date(employee.nextDeadline) - new Date()) / (1000 * 60 * 60 * 24))} days
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      {/* Pagination */}
      {totalPages > 1 && (
        <div className="p-4 border-t border-border">
          <div className="flex items-center justify-between">
            <div className="text-sm text-muted-foreground">
              Showing {((currentPage - 1) * pageSize) + 1} to {Math.min(currentPage * pageSize, filteredEmployees?.length)} of {filteredEmployees?.length} employees
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(currentPage - 1)}
                disabled={currentPage === 1}
                iconName="ChevronLeft"
                iconPosition="left"
              >
                Previous
              </Button>
              <div className="flex items-center space-x-1">
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  const page = i + 1;
                  return (
                    <Button
                      key={page}
                      variant={currentPage === page ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setCurrentPage(page)}
                    >
                      {page}
                    </Button>
                  );
                })}
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(currentPage + 1)}
                disabled={currentPage === totalPages}
                iconName="ChevronRight"
                iconPosition="right"
              >
                Next
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EmployeeGrid;