import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const BulkOperationsToolbar = ({ 
  selectedEmployees, 
  onClearSelection,
  className = '' 
}) => {
  const [selectedAction, setSelectedAction] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const bulkActions = [
    { value: '', label: 'Select bulk action...' },
    { value: 'assign_training', label: 'Assign Training Course' },
    { value: 'extend_deadline', label: 'Extend Training Deadline' },
    { value: 'send_reminder', label: 'Send Training Reminder' },
    { value: 'schedule_session', label: 'Schedule Training Session' },
    { value: 'generate_report', label: 'Generate Training Report' },
    { value: 'export_data', label: 'Export Employee Data' },
    { value: 'update_status', label: 'Update Training Status' }
  ];

  const trainingCourses = [
    { value: 'haccp', label: 'HACCP Fundamentals' },
    { value: 'safety', label: 'Machine Safety Protocol' },
    { value: 'quality', label: 'Quality Control Procedures' },
    { value: 'emergency', label: 'Emergency Response Training' },
    { value: 'maintenance', label: 'Equipment Maintenance' },
    { value: 'hygiene', label: 'Dairy Safety & Hygiene' }
  ];

  const handleExecuteAction = async () => {
    if (!selectedAction || selectedEmployees?.length === 0) return;

    setIsProcessing(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Mock success response
    console.log(`Executing ${selectedAction} for ${selectedEmployees?.length} employees`);
    
    setIsProcessing(false);
    setSelectedAction('');
    onClearSelection();
  };

  const getActionIcon = (action) => {
    switch (action) {
      case 'assign_training': return 'BookOpen';
      case 'extend_deadline': return 'Clock';
      case 'send_reminder': return 'Mail';
      case 'schedule_session': return 'Calendar';
      case 'generate_report': return 'FileText';
      case 'export_data': return 'Download';
      case 'update_status': return 'CheckCircle';
      default: return 'Settings';
    }
  };

  const getActionDescription = (action) => {
    switch (action) {
      case 'assign_training':
        return 'Assign a training course to selected employees';
      case 'extend_deadline':
        return 'Extend training deadlines for selected employees';
      case 'send_reminder':
        return 'Send training reminder notifications';
      case 'schedule_session':
        return 'Schedule group training sessions';
      case 'generate_report':
        return 'Generate training reports for selected employees';
      case 'export_data':
        return 'Export employee training data to CSV/Excel';
      case 'update_status':
        return 'Bulk update training completion status';
      default:
        return 'Select an action to perform on selected employees';
    }
  };

  if (selectedEmployees?.length === 0) {
    return null;
  }

  return (
    <div className={`bg-primary/5 border border-primary/20 rounded-lg p-4 ${className}`}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2">
            <Icon name="Users" size={20} className="text-primary" />
            <span className="font-medium text-foreground">
              {selectedEmployees?.length} employee{selectedEmployees?.length !== 1 ? 's' : ''} selected
            </span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClearSelection}
            iconName="X"
            iconPosition="left"
          >
            Clear Selection
          </Button>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
        <div className="md:col-span-2">
          <Select
            label="Bulk Action"
            description={getActionDescription(selectedAction)}
            options={bulkActions}
            value={selectedAction}
            onChange={setSelectedAction}
            placeholder="Choose an action..."
          />
        </div>

        <div className="flex items-center space-x-2">
          <Button
            variant="default"
            onClick={handleExecuteAction}
            disabled={!selectedAction || isProcessing}
            loading={isProcessing}
            iconName={selectedAction ? getActionIcon(selectedAction) : 'Play'}
            iconPosition="left"
          >
            {isProcessing ? 'Processing...' : 'Execute Action'}
          </Button>
        </div>
      </div>
      {/* Action-specific options */}
      {selectedAction === 'assign_training' && (
        <div className="mt-4 p-4 bg-card border border-border rounded-lg">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Select
              label="Training Course"
              options={trainingCourses}
              placeholder="Select training course..."
            />
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                Deadline
              </label>
              <input
                type="date"
                className="w-full px-3 py-2 border border-border rounded-lg bg-input text-foreground"
                min={new Date()?.toISOString()?.split('T')?.[0]}
              />
            </div>
          </div>
        </div>
      )}
      {selectedAction === 'extend_deadline' && (
        <div className="mt-4 p-4 bg-card border border-border rounded-lg">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                Extension Period
              </label>
              <select className="w-full px-3 py-2 border border-border rounded-lg bg-input text-foreground">
                <option value="7">7 days</option>
                <option value="14">14 days</option>
                <option value="30">30 days</option>
                <option value="60">60 days</option>
                <option value="90">90 days</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                Reason for Extension
              </label>
              <select className="w-full px-3 py-2 border border-border rounded-lg bg-input text-foreground">
                <option value="">Select reason...</option>
                <option value="workload">High workload</option>
                <option value="absence">Employee absence</option>
                <option value="technical">Technical issues</option>
                <option value="scheduling">Scheduling conflicts</option>
                <option value="other">Other</option>
              </select>
            </div>
          </div>
        </div>
      )}
      {selectedAction === 'send_reminder' && (
        <div className="mt-4 p-4 bg-card border border-border rounded-lg">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                Reminder Type
              </label>
              <select className="w-full px-3 py-2 border border-border rounded-lg bg-input text-foreground">
                <option value="email">Email Notification</option>
                <option value="sms">SMS Alert</option>
                <option value="both">Email + SMS</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                Send Time
              </label>
              <select className="w-full px-3 py-2 border border-border rounded-lg bg-input text-foreground">
                <option value="now">Send immediately</option>
                <option value="morning">Tomorrow morning (9 AM)</option>
                <option value="afternoon">Tomorrow afternoon (2 PM)</option>
                <option value="custom">Custom time</option>
              </select>
            </div>
          </div>
        </div>
      )}
      {/* Progress indicator */}
      {isProcessing && (
        <div className="mt-4 p-3 bg-accent/10 border border-accent/20 rounded-lg">
          <div className="flex items-center space-x-3">
            <Icon name="Loader2" size={16} className="animate-spin text-accent" />
            <div>
              <div className="text-sm font-medium text-foreground">
                Processing bulk action...
              </div>
              <div className="text-xs text-muted-foreground">
                This may take a few moments for {selectedEmployees?.length} employees
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BulkOperationsToolbar;