import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Image from '../../../components/AppImage';

const EmployeeDetailPanel = ({ 
  selectedEmployee, 
  onClose,
  className = '' 
}) => {
  const [activeTab, setActiveTab] = useState('overview');

  if (!selectedEmployee) {
    return (
      <div className={`bg-card border-l border-border h-full flex items-center justify-center ${className}`}>
        <div className="text-center text-muted-foreground">
          <Icon name="User" size={48} className="mx-auto mb-4 opacity-50" />
          <p>Select an employee to view details</p>
        </div>
      </div>
    );
  }

  const trainingHistory = [
    {
      id: 'th001',
      course: 'HACCP Fundamentals',
      category: 'Food Safety',
      completedDate: new Date('2024-08-15'),
      expiryDate: new Date('2025-08-15'),
      score: 95,
      certificate: 'CERT-HACCP-2024-001',
      status: 'completed',
      instructor: 'Dr. Sarah Mitchell'
    },
    {
      id: 'th002',
      course: 'Machine Safety Protocol',
      category: 'Safety Training',
      completedDate: new Date('2024-07-20'),
      expiryDate: new Date('2025-07-20'),
      score: 88,
      certificate: 'CERT-SAFETY-2024-002',
      status: 'completed',
      instructor: 'James Wilson'
    },
    {
      id: 'th003',
      course: 'Quality Control Procedures',
      category: 'Quality Assurance',
      completedDate: new Date('2024-06-10'),
      expiryDate: new Date('2025-06-10'),
      score: 92,
      certificate: 'CERT-QC-2024-003',
      status: 'completed',
      instructor: 'Emma Wilson'
    },
    {
      id: 'th004',
      course: 'Emergency Response Training',
      category: 'Safety Training',
      dueDate: new Date('2024-09-10'),
      status: 'upcoming',
      instructor: 'Anna Thompson'
    },
    {
      id: 'th005',
      course: 'Equipment Maintenance',
      category: 'Technical Training',
      dueDate: new Date('2024-08-30'),
      status: 'overdue',
      instructor: 'Carlos Mendez'
    }
  ];

  const upcomingTraining = trainingHistory?.filter(t => t?.status === 'upcoming');
  const overdueTraining = trainingHistory?.filter(t => t?.status === 'overdue');
  const completedTraining = trainingHistory?.filter(t => t?.status === 'completed');

  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'User' },
    { id: 'training', label: 'Training History', icon: 'BookOpen' },
    { id: 'certificates', label: 'Certificates', icon: 'Award' },
    { id: 'actions', label: 'Quick Actions', icon: 'Settings' }
  ];

  const formatDate = (date) => {
    return new Date(date)?.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'text-success';
      case 'upcoming': return 'text-warning';
      case 'overdue': return 'text-error';
      default: return 'text-muted-foreground';
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'completed': return 'bg-success/10 text-success border-success/20';
      case 'upcoming': return 'bg-warning/10 text-warning border-warning/20';
      case 'overdue': return 'bg-error/10 text-error border-error/20';
      default: return 'bg-muted/10 text-muted-foreground border-muted/20';
    }
  };

  const renderOverviewTab = () => (
    <div className="space-y-6">
      {/* Employee Info */}
      <div className="text-center">
        <div className="w-20 h-20 rounded-full overflow-hidden mx-auto mb-4 bg-muted">
          <Image
            src={selectedEmployee?.avatar || 'https://randomuser.me/api/portraits/men/1.jpg'}
            alt={selectedEmployee?.name}
            className="w-full h-full object-cover"
          />
        </div>
        <h3 className="text-lg font-semibold text-foreground">{selectedEmployee?.name}</h3>
        <p className="text-sm text-muted-foreground">{selectedEmployee?.role}</p>
        <p className="text-sm text-muted-foreground">{selectedEmployee?.department}</p>
      </div>

      {/* Compliance Overview */}
      <div className="bg-muted/30 rounded-lg p-4">
        <h4 className="font-medium text-foreground mb-3">Compliance Status</h4>
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Overall Compliance</span>
            <span className={`text-lg font-semibold ${selectedEmployee?.compliance >= 95 ? 'text-success' : selectedEmployee?.compliance >= 85 ? 'text-warning' : 'text-error'}`}>
              {selectedEmployee?.compliance}%
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Completed Training</span>
            <span className="text-sm font-medium text-success">{selectedEmployee?.completed || 15}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Upcoming Training</span>
            <span className="text-sm font-medium text-warning">{selectedEmployee?.upcoming || 2}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Overdue Training</span>
            <span className="text-sm font-medium text-error">{selectedEmployee?.overdue || 1}</span>
          </div>
        </div>
      </div>

      {/* Contact Info */}
      <div className="space-y-3">
        <h4 className="font-medium text-foreground">Contact Information</h4>
        <div className="space-y-2 text-sm">
          <div className="flex items-center space-x-2">
            <Icon name="Mail" size={14} className="text-muted-foreground" />
            <span className="text-foreground">{selectedEmployee?.email}</span>
          </div>
          <div className="flex items-center space-x-2">
            <Icon name="Phone" size={14} className="text-muted-foreground" />
            <span className="text-foreground">+1 (555) 123-4567</span>
          </div>
          <div className="flex items-center space-x-2">
            <Icon name="MapPin" size={14} className="text-muted-foreground" />
            <span className="text-foreground">Floor 2, Production Area</span>
          </div>
        </div>
      </div>
    </div>
  );

  const renderTrainingTab = () => (
    <div className="space-y-4">
      {/* Overdue Training */}
      {overdueTraining?.length > 0 && (
        <div>
          <h4 className="font-medium text-error mb-3 flex items-center">
            <Icon name="AlertTriangle" size={16} className="mr-2" />
            Overdue Training ({overdueTraining?.length})
          </h4>
          <div className="space-y-2">
            {overdueTraining?.map((training) => (
              <div key={training?.id} className="p-3 bg-error/5 border border-error/20 rounded-lg">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="font-medium text-foreground">{training?.course}</div>
                    <div className="text-sm text-muted-foreground">{training?.category}</div>
                    <div className="text-sm text-error">Due: {formatDate(training?.dueDate)}</div>
                  </div>
                  <div className={`px-2 py-1 rounded text-xs font-medium border ${getStatusBadge(training?.status)}`}>
                    Overdue
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Upcoming Training */}
      {upcomingTraining?.length > 0 && (
        <div>
          <h4 className="font-medium text-warning mb-3 flex items-center">
            <Icon name="Clock" size={16} className="mr-2" />
            Upcoming Training ({upcomingTraining?.length})
          </h4>
          <div className="space-y-2">
            {upcomingTraining?.map((training) => (
              <div key={training?.id} className="p-3 bg-warning/5 border border-warning/20 rounded-lg">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="font-medium text-foreground">{training?.course}</div>
                    <div className="text-sm text-muted-foreground">{training?.category}</div>
                    <div className="text-sm text-warning">Due: {formatDate(training?.dueDate)}</div>
                  </div>
                  <div className={`px-2 py-1 rounded text-xs font-medium border ${getStatusBadge(training?.status)}`}>
                    Upcoming
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Completed Training */}
      <div>
        <h4 className="font-medium text-success mb-3 flex items-center">
          <Icon name="CheckCircle" size={16} className="mr-2" />
          Completed Training ({completedTraining?.length})
        </h4>
        <div className="space-y-2 max-h-64 overflow-y-auto">
          {completedTraining?.map((training) => (
            <div key={training?.id} className="p-3 bg-success/5 border border-success/20 rounded-lg">
              <div className="flex justify-between items-start">
                <div>
                  <div className="font-medium text-foreground">{training?.course}</div>
                  <div className="text-sm text-muted-foreground">{training?.category}</div>
                  <div className="text-sm text-success">
                    Completed: {formatDate(training?.completedDate)}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Expires: {formatDate(training?.expiryDate)}
                  </div>
                </div>
                <div className="text-right">
                  <div className={`px-2 py-1 rounded text-xs font-medium border ${getStatusBadge(training?.status)} mb-1`}>
                    Completed
                  </div>
                  <div className="text-sm font-medium text-success">
                    Score: {training?.score}%
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderCertificatesTab = () => (
    <div className="space-y-4">
      <h4 className="font-medium text-foreground">Training Certificates</h4>
      <div className="space-y-3">
        {completedTraining?.map((training) => (
          <div key={training?.id} className="p-3 border border-border rounded-lg">
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-3">
                <div className="w-10 h-10 bg-success/10 rounded-lg flex items-center justify-center">
                  <Icon name="Award" size={20} className="text-success" />
                </div>
                <div>
                  <div className="font-medium text-foreground">{training?.course}</div>
                  <div className="text-sm text-muted-foreground">
                    Certificate ID: {training?.certificate}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Issued: {formatDate(training?.completedDate)}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Valid until: {formatDate(training?.expiryDate)}
                  </div>
                </div>
              </div>
              <Button variant="outline" size="sm" iconName="Download" iconPosition="left">
                Download
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderActionsTab = () => (
    <div className="space-y-4">
      <h4 className="font-medium text-foreground">Quick Actions</h4>
      <div className="space-y-3">
        <Button variant="default" fullWidth iconName="Plus" iconPosition="left">
          Assign New Training
        </Button>
        <Button variant="outline" fullWidth iconName="Calendar" iconPosition="left">
          Schedule Training Session
        </Button>
        <Button variant="outline" fullWidth iconName="Clock" iconPosition="left">
          Extend Deadline
        </Button>
        <Button variant="outline" fullWidth iconName="Mail" iconPosition="left">
          Send Reminder
        </Button>
        <Button variant="outline" fullWidth iconName="FileText" iconPosition="left">
          Generate Report
        </Button>
        <Button variant="outline" fullWidth iconName="Upload" iconPosition="left">
          Upload Certificate
        </Button>
      </div>

      <div className="pt-4 border-t border-border">
        <h5 className="font-medium text-foreground mb-3">Bulk Actions</h5>
        <div className="space-y-2">
          <Button variant="secondary" fullWidth iconName="Users" iconPosition="left">
            Apply to Department
          </Button>
          <Button variant="secondary" fullWidth iconName="Copy" iconPosition="left">
            Copy Training Plan
          </Button>
        </div>
      </div>
    </div>
  );

  return (
    <div className={`bg-card border-l border-border h-full flex flex-col ${className}`}>
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-foreground">Employee Details</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <Icon name="X" size={20} />
          </Button>
        </div>
      </div>
      {/* Tabs */}
      <div className="border-b border-border">
        <div className="flex overflow-x-auto">
          {tabs?.map((tab) => (
            <button
              key={tab?.id}
              onClick={() => setActiveTab(tab?.id)}
              className={`flex items-center space-x-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                activeTab === tab?.id
                  ? 'border-primary text-primary' :'border-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              <Icon name={tab?.icon} size={16} />
              <span>{tab?.label}</span>
            </button>
          ))}
        </div>
      </div>
      {/* Tab Content */}
      <div className="flex-1 overflow-y-auto p-4">
        {activeTab === 'overview' && renderOverviewTab()}
        {activeTab === 'training' && renderTrainingTab()}
        {activeTab === 'certificates' && renderCertificatesTab()}
        {activeTab === 'actions' && renderActionsTab()}
      </div>
    </div>
  );
};

export default EmployeeDetailPanel;