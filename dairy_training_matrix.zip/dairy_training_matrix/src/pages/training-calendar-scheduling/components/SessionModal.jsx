import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const SessionModal = ({ 
  isOpen, 
  onClose, 
  session, 
  onSave, 
  onDelete,
  instructors,
  rooms 
}) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    department: '',
    trainingType: '',
    instructor: '',
    location: '',
    startTime: '',
    endTime: '',
    maxAttendees: '',
    isRecurring: false,
    recurringPattern: '',
    notes: ''
  });

  const [errors, setErrors] = useState({});

  const departmentOptions = [
    { value: 'Production', label: 'Production Team' },
    { value: 'Quality', label: 'Quality Control' },
    { value: 'Safety', label: 'Safety Officers' },
    { value: 'Maintenance', label: 'Maintenance Team' },
    { value: 'Laboratory', label: 'Laboratory Staff' },
    { value: 'Management', label: 'Management' }
  ];

  const trainingTypeOptions = [
    { value: 'safety', label: 'Dairy Safety & Hygiene' },
    { value: 'haccp', label: 'HACCP & Food Safety' },
    { value: 'equipment', label: 'Equipment Operation' },
    { value: 'quality', label: 'Quality Control Procedures' },
    { value: 'emergency', label: 'Emergency Response' },
    { value: 'compliance', label: 'Regulatory Compliance' },
    { value: 'induction', label: 'New Employee Induction' }
  ];

  const recurringOptions = [
    { value: 'weekly', label: 'Weekly' },
    { value: 'biweekly', label: 'Bi-weekly' },
    { value: 'monthly', label: 'Monthly' },
    { value: 'quarterly', label: 'Quarterly' }
  ];

  useEffect(() => {
    if (session) {
      setFormData({
        title: session?.title || '',
        description: session?.description || '',
        department: session?.department || '',
        trainingType: session?.trainingType || '',
        instructor: session?.instructor || '',
        location: session?.location || '',
        startTime: session?.startTime ? new Date(session.startTime)?.toISOString()?.slice(0, 16) : '',
        endTime: session?.endTime ? new Date(session.endTime)?.toISOString()?.slice(0, 16) : '',
        maxAttendees: session?.maxAttendees?.toString() || '',
        isRecurring: session?.isRecurring || false,
        recurringPattern: session?.recurringPattern || '',
        notes: session?.notes || ''
      });
    } else {
      // Reset form for new session
      setFormData({
        title: '',
        description: '',
        department: '',
        trainingType: '',
        instructor: '',
        location: '',
        startTime: '',
        endTime: '',
        maxAttendees: '',
        isRecurring: false,
        recurringPattern: '',
        notes: ''
      });
    }
    setErrors({});
  }, [session, isOpen]);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Clear error when user starts typing
    if (errors?.[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData?.title?.trim()) {
      newErrors.title = 'Session title is required';
    }

    if (!formData?.department) {
      newErrors.department = 'Department is required';
    }

    if (!formData?.trainingType) {
      newErrors.trainingType = 'Training type is required';
    }

    if (!formData?.instructor) {
      newErrors.instructor = 'Instructor is required';
    }

    if (!formData?.location) {
      newErrors.location = 'Location is required';
    }

    if (!formData?.startTime) {
      newErrors.startTime = 'Start time is required';
    }

    if (!formData?.endTime) {
      newErrors.endTime = 'End time is required';
    }

    if (formData?.startTime && formData?.endTime && new Date(formData.startTime) >= new Date(formData.endTime)) {
      newErrors.endTime = 'End time must be after start time';
    }

    if (!formData?.maxAttendees || parseInt(formData?.maxAttendees) <= 0) {
      newErrors.maxAttendees = 'Valid maximum attendees is required';
    }

    if (formData?.isRecurring && !formData?.recurringPattern) {
      newErrors.recurringPattern = 'Recurring pattern is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleSave = () => {
    if (validateForm()) {
      const sessionData = {
        ...formData,
        id: session?.id || Date.now()?.toString(),
        startTime: new Date(formData.startTime)?.toISOString(),
        endTime: new Date(formData.endTime)?.toISOString(),
        maxAttendees: parseInt(formData?.maxAttendees),
        attendees: session?.attendees || 0
      };
      onSave(sessionData);
    }
  };

  const handleDelete = () => {
    if (session && window.confirm('Are you sure you want to delete this training session?')) {
      onDelete(session?.id);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-200 flex items-center justify-center">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/50"
        onClick={onClose}
      />
      {/* Modal */}
      <div className="relative bg-card rounded-lg shadow-industrial-strong w-full max-w-2xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <h2 className="text-xl font-semibold text-foreground">
            {session ? 'Edit Training Session' : 'New Training Session'}
          </h2>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
          >
            <Icon name="X" size={20} />
          </Button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-140px)]">
          <div className="space-y-6">
            {/* Basic Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-foreground">Basic Information</h3>
              
              <Input
                label="Session Title"
                type="text"
                value={formData?.title}
                onChange={(e) => handleInputChange('title', e?.target?.value)}
                error={errors?.title}
                placeholder="Enter session title"
                required
              />

              <Input
                label="Description"
                type="text"
                value={formData?.description}
                onChange={(e) => handleInputChange('description', e?.target?.value)}
                placeholder="Brief description of the training session"
              />

              <div className="grid grid-cols-2 gap-4">
                <Select
                  label="Department"
                  options={departmentOptions}
                  value={formData?.department}
                  onChange={(value) => handleInputChange('department', value)}
                  error={errors?.department}
                  placeholder="Select department"
                  required
                />

                <Select
                  label="Training Type"
                  options={trainingTypeOptions}
                  value={formData?.trainingType}
                  onChange={(value) => handleInputChange('trainingType', value)}
                  error={errors?.trainingType}
                  placeholder="Select training type"
                  required
                />
              </div>
            </div>

            {/* Schedule & Location */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-foreground">Schedule & Location</h3>
              
              <div className="grid grid-cols-2 gap-4">
                <Select
                  label="Instructor"
                  options={instructors?.map(instructor => ({
                    value: instructor?.name,
                    label: instructor?.name,
                    description: instructor?.specialization
                  }))}
                  value={formData?.instructor}
                  onChange={(value) => handleInputChange('instructor', value)}
                  error={errors?.instructor}
                  placeholder="Select instructor"
                  required
                />

                <Select
                  label="Location"
                  options={rooms?.map(room => ({
                    value: room?.name,
                    label: room?.name,
                    description: `Capacity: ${room?.capacity} people`
                  }))}
                  value={formData?.location}
                  onChange={(value) => handleInputChange('location', value)}
                  error={errors?.location}
                  placeholder="Select location"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <Input
                  label="Start Time"
                  type="datetime-local"
                  value={formData?.startTime}
                  onChange={(e) => handleInputChange('startTime', e?.target?.value)}
                  error={errors?.startTime}
                  required
                />

                <Input
                  label="End Time"
                  type="datetime-local"
                  value={formData?.endTime}
                  onChange={(e) => handleInputChange('endTime', e?.target?.value)}
                  error={errors?.endTime}
                  required
                />
              </div>

              <Input
                label="Maximum Attendees"
                type="number"
                value={formData?.maxAttendees}
                onChange={(e) => handleInputChange('maxAttendees', e?.target?.value)}
                error={errors?.maxAttendees}
                placeholder="Enter maximum number of attendees"
                min="1"
                required
              />
            </div>

            {/* Recurring Options */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-foreground">Recurring Options</h3>
              
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="isRecurring"
                  checked={formData?.isRecurring}
                  onChange={(e) => handleInputChange('isRecurring', e?.target?.checked)}
                  className="w-4 h-4 text-primary bg-background border-border rounded focus:ring-primary"
                />
                <label htmlFor="isRecurring" className="text-sm text-foreground">
                  Make this a recurring session
                </label>
              </div>

              {formData?.isRecurring && (
                <Select
                  label="Recurring Pattern"
                  options={recurringOptions}
                  value={formData?.recurringPattern}
                  onChange={(value) => handleInputChange('recurringPattern', value)}
                  error={errors?.recurringPattern}
                  placeholder="Select recurring pattern"
                  required
                />
              )}
            </div>

            {/* Additional Notes */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-foreground">Additional Notes</h3>
              
              <textarea
                value={formData?.notes}
                onChange={(e) => handleInputChange('notes', e?.target?.value)}
                placeholder="Any additional notes or requirements for this session"
                rows={3}
                className="w-full p-3 border border-border rounded-lg bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between p-6 border-t border-border">
          <div>
            {session && (
              <Button
                variant="destructive"
                onClick={handleDelete}
                iconName="Trash2"
                iconPosition="left"
              >
                Delete Session
              </Button>
            )}
          </div>
          
          <div className="flex items-center space-x-3">
            <Button
              variant="outline"
              onClick={onClose}
            >
              Cancel
            </Button>
            <Button
              variant="default"
              onClick={handleSave}
              iconName="Save"
              iconPosition="left"
            >
              {session ? 'Update Session' : 'Create Session'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SessionModal;