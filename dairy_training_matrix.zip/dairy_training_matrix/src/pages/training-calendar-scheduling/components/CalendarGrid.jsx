import React from 'react';
import Icon from '../../../components/AppIcon';

const CalendarGrid = ({ 
  viewMode, 
  currentDate, 
  sessions, 
  onSessionClick, 
  onTimeSlotClick,
  onSessionDrop 
}) => {
  const getDaysInMonth = (date) => {
    const year = date?.getFullYear();
    const month = date?.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay?.getDate();
    const startingDayOfWeek = firstDay?.getDay();
    
    const days = [];
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
      days?.push(null);
    }
    
    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      days?.push(new Date(year, month, day));
    }
    
    return days;
  };

  const getWeekDays = (date) => {
    const startOfWeek = new Date(date);
    let day = startOfWeek?.getDay();
    const diff = startOfWeek?.getDate() - day;
    startOfWeek?.setDate(diff);
    
    const days = [];
    for (let i = 0; i < 7; i++) {
      let day = new Date(startOfWeek);
      day?.setDate(startOfWeek?.getDate() + i);
      days?.push(day);
    }
    return days;
  };

  const getSessionsForDate = (date) => {
    if (!date) return [];
    const dateStr = date?.toDateString();
    return sessions?.filter(session => 
      new Date(session.startTime)?.toDateString() === dateStr
    );
  };

  const formatTime = (timeString) => {
    return new Date(timeString)?.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  const getSessionColor = (department) => {
    switch (department) {
      case 'Production': return 'bg-blue-100 border-blue-300 text-blue-800';
      case 'Quality': return 'bg-green-100 border-green-300 text-green-800';
      case 'Safety': return 'bg-red-100 border-red-300 text-red-800';
      case 'Maintenance': return 'bg-yellow-100 border-yellow-300 text-yellow-800';
      case 'Laboratory': return 'bg-purple-100 border-purple-300 text-purple-800';
      default: return 'bg-gray-100 border-gray-300 text-gray-800';
    }
  };

  const renderMonthView = () => {
    const days = getDaysInMonth(currentDate);
    const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    return (
      <div className="h-full flex flex-col">
        {/* Week day headers */}
        <div className="grid grid-cols-7 border-b border-border">
          {weekDays?.map((day) => (
            <div key={day} className="p-3 text-center text-sm font-medium text-muted-foreground bg-muted">
              {day}
            </div>
          ))}
        </div>
        {/* Calendar grid */}
        <div className="flex-1 grid grid-cols-7 auto-rows-fr">
          {days?.map((day, index) => {
            const daySessions = day ? getSessionsForDate(day) : [];
            const isToday = day && day?.toDateString() === new Date()?.toDateString();
            
            return (
              <div
                key={index}
                className={`border-r border-b border-border p-2 min-h-32 cursor-pointer hover:bg-muted/50 transition-colors ${
                  !day ? 'bg-muted/20' : ''
                } ${isToday ? 'bg-accent/10' : ''}`}
                onClick={() => day && onTimeSlotClick(day)}
              >
                {day && (
                  <>
                    <div className={`text-sm font-medium mb-2 ${
                      isToday ? 'text-accent font-semibold' : 'text-foreground'
                    }`}>
                      {day?.getDate()}
                    </div>
                    <div className="space-y-1">
                      {daySessions?.slice(0, 3)?.map((session) => (
                        <div
                          key={session?.id}
                          onClick={(e) => {
                            e?.stopPropagation();
                            onSessionClick(session);
                          }}
                          className={`text-xs p-1 rounded border cursor-pointer hover:shadow-sm transition-shadow ${
                            getSessionColor(session?.department)
                          }`}
                        >
                          <div className="font-medium truncate">{session?.title}</div>
                          <div className="opacity-75">{formatTime(session?.startTime)}</div>
                        </div>
                      ))}
                      {daySessions?.length > 3 && (
                        <div className="text-xs text-muted-foreground">
                          +{daySessions?.length - 3} more
                        </div>
                      )}
                    </div>
                  </>
                )}
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const renderWeekView = () => {
    const weekDays = getWeekDays(currentDate);
    const hours = Array.from({ length: 12 }, (_, i) => i + 8); // 8 AM to 7 PM

    return (
      <div className="h-full flex flex-col">
        {/* Week day headers */}
        <div className="grid grid-cols-8 border-b border-border">
          <div className="p-3 border-r border-border bg-muted"></div>
          {weekDays?.map((day) => {
            const isToday = day?.toDateString() === new Date()?.toDateString();
            return (
              <div key={day?.toISOString()} className={`p-3 text-center border-r border-border ${
                isToday ? 'bg-accent/10' : 'bg-muted'
              }`}>
                <div className="text-sm font-medium text-foreground">
                  {day?.toLocaleDateString('en-US', { weekday: 'short' })}
                </div>
                <div className={`text-lg font-semibold ${
                  isToday ? 'text-accent' : 'text-foreground'
                }`}>
                  {day?.getDate()}
                </div>
              </div>
            );
          })}
        </div>
        {/* Time slots grid */}
        <div className="flex-1 overflow-y-auto">
          <div className="grid grid-cols-8 auto-rows-fr min-h-full">
            {hours?.map((hour) => (
              <React.Fragment key={hour}>
                {/* Time label */}
                <div className="p-2 border-r border-b border-border bg-muted text-sm text-muted-foreground text-center">
                  {hour === 12 ? '12 PM' : hour > 12 ? `${hour - 12} PM` : `${hour} AM`}
                </div>
                
                {/* Time slots for each day */}
                {weekDays?.map((day) => {
                  const slotSessions = sessions?.filter(session => {
                    const sessionDate = new Date(session.startTime);
                    const sessionHour = sessionDate?.getHours();
                    return sessionDate?.toDateString() === day?.toDateString() && sessionHour === hour;
                  });

                  return (
                    <div
                      key={`${day?.toISOString()}-${hour}`}
                      className="border-r border-b border-border p-1 min-h-16 cursor-pointer hover:bg-muted/50 transition-colors relative"
                      onClick={() => onTimeSlotClick(new Date(day.getFullYear(), day.getMonth(), day.getDate(), hour))}
                    >
                      {slotSessions?.map((session) => (
                        <div
                          key={session?.id}
                          onClick={(e) => {
                            e?.stopPropagation();
                            onSessionClick(session);
                          }}
                          className={`text-xs p-1 rounded border cursor-pointer hover:shadow-sm transition-shadow mb-1 ${
                            getSessionColor(session?.department)
                          }`}
                        >
                          <div className="font-medium truncate">{session?.title}</div>
                          <div className="opacity-75">{formatTime(session?.startTime)}</div>
                        </div>
                      ))}
                    </div>
                  );
                })}
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>
    );
  };

  const renderDayView = () => {
    const hours = Array.from({ length: 12 }, (_, i) => i + 8); // 8 AM to 7 PM
    const daySessions = getSessionsForDate(currentDate);

    return (
      <div className="h-full flex flex-col">
        {/* Day header */}
        <div className="p-4 border-b border-border bg-muted">
          <div className="text-center">
            <div className="text-sm font-medium text-muted-foreground">
              {currentDate?.toLocaleDateString('en-US', { weekday: 'long' })}
            </div>
            <div className="text-2xl font-semibold text-foreground">
              {currentDate?.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
            </div>
          </div>
        </div>
        {/* Time slots */}
        <div className="flex-1 overflow-y-auto">
          {hours?.map((hour) => {
            const hourSessions = daySessions?.filter(session => {
              const sessionHour = new Date(session.startTime)?.getHours();
              return sessionHour === hour;
            });

            return (
              <div key={hour} className="flex border-b border-border min-h-20">
                {/* Time label */}
                <div className="w-20 p-3 border-r border-border bg-muted text-sm text-muted-foreground text-center">
                  {hour === 12 ? '12 PM' : hour > 12 ? `${hour - 12} PM` : `${hour} AM`}
                </div>
                {/* Session content */}
                <div 
                  className="flex-1 p-2 cursor-pointer hover:bg-muted/50 transition-colors"
                  onClick={() => onTimeSlotClick(new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate(), hour))}
                >
                  {hourSessions?.map((session) => (
                    <div
                      key={session?.id}
                      onClick={(e) => {
                        e?.stopPropagation();
                        onSessionClick(session);
                      }}
                      className={`p-3 rounded-lg border cursor-pointer hover:shadow-sm transition-shadow mb-2 ${
                        getSessionColor(session?.department)
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">{session?.title}</h4>
                        <span className="text-sm opacity-75">
                          {formatTime(session?.startTime)} - {formatTime(session?.endTime)}
                        </span>
                      </div>
                      <div className="flex items-center space-x-4 text-sm opacity-75">
                        <div className="flex items-center space-x-1">
                          <Icon name="MapPin" size={14} />
                          <span>{session?.location}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Icon name="Users" size={14} />
                          <span>{session?.attendees} attendees</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Icon name="User" size={14} />
                          <span>{session?.instructor}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className="flex-1 bg-background">
      {viewMode === 'month' && renderMonthView()}
      {viewMode === 'week' && renderWeekView()}
      {viewMode === 'day' && renderDayView()}
    </div>
  );
};

export default CalendarGrid;