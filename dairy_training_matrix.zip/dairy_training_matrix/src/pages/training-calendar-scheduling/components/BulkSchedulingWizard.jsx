import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const BulkSchedulingWizard = ({ 
  isOpen, 
  onClose, 
  onSchedule,
  employees,
  instructors,
  rooms 
}) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    trainingType: '',
    department: '',
    selectedEmployees: [],
    instructor: '',
    duration: '',
    startDate: '',
    endDate: '',
    preferredTimes: [],
    location: '',
    maxSessionSize: '',
    sessionGap: '',
    notes: ''
  });

  const [errors, setErrors] = useState({});
  const [schedulingResults, setSchedulingResults] = useState(null);

  const steps = [
    { id: 1, title: 'Training Details', icon: 'BookOpen' },
    { id: 2, title: 'Select Employees', icon: 'Users' },
    { id: 3, title: 'Schedule Settings', icon: 'Calendar' },
    { id: 4, title: 'Review & Confirm', icon: 'CheckCircle' }
  ];

  const trainingTypeOptions = [
    { value: 'safety', label: 'Dairy Safety & Hygiene' },
    { value: 'haccp', label: 'HACCP & Food Safety' },
    { value: 'equipment', label: 'Equipment Operation' },
    { value: 'quality', label: 'Quality Control Procedures' },
    { value: 'emergency', label: 'Emergency Response' },
    { value: 'compliance', label: 'Regulatory Compliance' },
    { value: 'induction', label: 'New Employee Induction' }
  ];

  const departmentOptions = [
    { value: 'Production', label: 'Production Team' },
    { value: 'Quality', label: 'Quality Control' },
    { value: 'Safety', label: 'Safety Officers' },
    { value: 'Maintenance', label: 'Maintenance Team' },
    { value: 'Laboratory', label: 'Laboratory Staff' },
    { value: 'Management', label: 'Management' }
  ];

  const timeSlotOptions = [
    { value: '08:00', label: '8:00 AM - Morning Shift' },
    { value: '14:00', label: '2:00 PM - Afternoon Shift' },
    { value: '20:00', label: '8:00 PM - Night Shift' }
  ];

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    if (errors?.[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  const handleEmployeeSelection = (employeeId, checked) => {
    setFormData(prev => ({
      ...prev,
      selectedEmployees: checked 
        ? [...prev?.selectedEmployees, employeeId]
        : prev?.selectedEmployees?.filter(id => id !== employeeId)
    }));
  };

  const handleTimeSlotSelection = (timeSlot, checked) => {
    setFormData(prev => ({
      ...prev,
      preferredTimes: checked 
        ? [...prev?.preferredTimes, timeSlot]
        : prev?.preferredTimes?.filter(time => time !== timeSlot)
    }));
  };

  const validateStep = (step) => {
    const newErrors = {};

    switch (step) {
      case 1:
        if (!formData?.trainingType) newErrors.trainingType = 'Training type is required';
        if (!formData?.department) newErrors.department = 'Department is required';
        break;
      case 2:
        if (formData?.selectedEmployees?.length === 0) {
          newErrors.selectedEmployees = 'At least one employee must be selected';
        }
        break;
      case 3:
        if (!formData?.instructor) newErrors.instructor = 'Instructor is required';
        if (!formData?.duration) newErrors.duration = 'Duration is required';
        if (!formData?.startDate) newErrors.startDate = 'Start date is required';
        if (!formData?.endDate) newErrors.endDate = 'End date is required';
        if (!formData?.location) newErrors.location = 'Location is required';
        if (!formData?.maxSessionSize) newErrors.maxSessionSize = 'Max session size is required';
        if (formData?.preferredTimes?.length === 0) {
          newErrors.preferredTimes = 'At least one time slot must be selected';
        }
        break;
    }

    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleNext = () => {
    if (validateStep(currentStep)) {
      if (currentStep === 3) {
        // Generate scheduling preview
        generateSchedulingPreview();
      }
      setCurrentStep(prev => prev + 1);
    }
  };

  const handlePrevious = () => {
    setCurrentStep(prev => prev - 1);
  };

  const generateSchedulingPreview = () => {
    // Mock scheduling algorithm
    const sessionsNeeded = Math.ceil(formData?.selectedEmployees?.length / parseInt(formData?.maxSessionSize));
    const sessions = [];
    
    for (let i = 0; i < sessionsNeeded; i++) {
      const sessionDate = new Date(formData.startDate);
      sessionDate?.setDate(sessionDate?.getDate() + (i * parseInt(formData?.sessionGap || 1)));
      
      sessions?.push({
        id: `bulk-${i + 1}`,
        title: `${trainingTypeOptions?.find(t => t?.value === formData?.trainingType)?.label} - Session ${i + 1}`,
        date: sessionDate?.toLocaleDateString(),
        time: formData?.preferredTimes?.[0],
        attendees: Math.min(parseInt(formData?.maxSessionSize), formData?.selectedEmployees?.length - (i * parseInt(formData?.maxSessionSize))),
        instructor: formData?.instructor,
        location: formData?.location
      });
    }

    setSchedulingResults({
      totalSessions: sessionsNeeded,
      totalEmployees: formData?.selectedEmployees?.length,
      sessions: sessions,
      conflicts: [] // Mock - no conflicts for demo
    });
  };

  const handleSchedule = () => {
    if (schedulingResults) {
      onSchedule({
        ...formData,
        sessions: schedulingResults?.sessions
      });
    }
  };

  const getFilteredEmployees = () => {
    return employees?.filter(emp => 
      !formData?.department || emp?.department === formData?.department
    );
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-200 flex items-center justify-center">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/50"
        onClick={onClose}
      />
      {/* Modal */}
      <div className="relative bg-card rounded-lg shadow-industrial-strong w-full max-w-4xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div>
            <h2 className="text-xl font-semibold text-foreground">
              Bulk Training Scheduler
            </h2>
            <p className="text-sm text-muted-foreground">
              Schedule training sessions for multiple employees
            </p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
          >
            <Icon name="X" size={20} />
          </Button>
        </div>

        {/* Progress Steps */}
        <div className="px-6 py-4 border-b border-border">
          <div className="flex items-center justify-between">
            {steps?.map((step, index) => (
              <div key={step?.id} className="flex items-center">
                <div className={`flex items-center justify-center w-8 h-8 rounded-full border-2 ${
                  currentStep >= step?.id 
                    ? 'bg-primary border-primary text-primary-foreground' 
                    : 'border-border text-muted-foreground'
                }`}>
                  {currentStep > step?.id ? (
                    <Icon name="Check" size={16} />
                  ) : (
                    <span className="text-sm font-medium">{step?.id}</span>
                  )}
                </div>
                <div className="ml-3">
                  <p className={`text-sm font-medium ${
                    currentStep >= step?.id ? 'text-foreground' : 'text-muted-foreground'
                  }`}>
                    {step?.title}
                  </p>
                </div>
                {index < steps?.length - 1 && (
                  <div className={`w-16 h-0.5 mx-4 ${
                    currentStep > step?.id ? 'bg-primary' : 'bg-border'
                  }`} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-200px)]">
          {/* Step 1: Training Details */}
          {currentStep === 1 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-foreground mb-4">
                  Training Details
                </h3>
                <p className="text-sm text-muted-foreground mb-6">
                  Select the type of training and target department for bulk scheduling.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <Select
                  label="Training Type"
                  options={trainingTypeOptions}
                  value={formData?.trainingType}
                  onChange={(value) => handleInputChange('trainingType', value)}
                  error={errors?.trainingType}
                  placeholder="Select training type"
                  required
                />

                <Select
                  label="Target Department"
                  options={departmentOptions}
                  value={formData?.department}
                  onChange={(value) => handleInputChange('department', value)}
                  error={errors?.department}
                  placeholder="Select department"
                  required
                />
              </div>

              <Input
                label="Training Description"
                type="text"
                value={formData?.notes}
                onChange={(e) => handleInputChange('notes', e?.target?.value)}
                placeholder="Brief description of the training program"
              />
            </div>
          )}

          {/* Step 2: Select Employees */}
          {currentStep === 2 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-foreground mb-4">
                  Select Employees
                </h3>
                <p className="text-sm text-muted-foreground mb-6">
                  Choose employees who need to attend this training.
                </p>
              </div>

              {errors?.selectedEmployees && (
                <div className="p-3 bg-error/10 border border-error/20 rounded-lg">
                  <p className="text-sm text-error">{errors?.selectedEmployees}</p>
                </div>
              )}

              <div className="space-y-2 max-h-96 overflow-y-auto border border-border rounded-lg">
                <div className="sticky top-0 bg-muted p-3 border-b border-border">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-foreground">
                      Available Employees ({getFilteredEmployees()?.length})
                    </span>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          const allIds = getFilteredEmployees()?.map(emp => emp?.id);
                          handleInputChange('selectedEmployees', allIds);
                        }}
                      >
                        Select All
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleInputChange('selectedEmployees', [])}
                      >
                        Clear All
                      </Button>
                    </div>
                  </div>
                </div>

                {getFilteredEmployees()?.map((employee) => (
                  <div key={employee?.id} className="p-3 hover:bg-muted/50 transition-colors">
                    <Checkbox
                      label={
                        <div className="flex items-center justify-between w-full">
                          <div>
                            <p className="font-medium text-foreground">{employee?.name}</p>
                            <p className="text-sm text-muted-foreground">
                              {employee?.role} • {employee?.department}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="text-sm text-muted-foreground">
                              Last Training: {employee?.lastTraining}
                            </p>
                            <p className={`text-xs ${
                              employee?.complianceStatus === 'Compliant' ? 'text-success' :
                              employee?.complianceStatus === 'Due Soon'? 'text-warning' : 'text-error'
                            }`}>
                              {employee?.complianceStatus}
                            </p>
                          </div>
                        </div>
                      }
                      checked={formData?.selectedEmployees?.includes(employee?.id)}
                      onChange={(e) => handleEmployeeSelection(employee?.id, e?.target?.checked)}
                    />
                  </div>
                ))}
              </div>

              <div className="p-3 bg-muted rounded-lg">
                <p className="text-sm text-foreground">
                  <span className="font-medium">{formData?.selectedEmployees?.length}</span> employees selected
                </p>
              </div>
            </div>
          )}

          {/* Step 3: Schedule Settings */}
          {currentStep === 3 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-foreground mb-4">
                  Schedule Settings
                </h3>
                <p className="text-sm text-muted-foreground mb-6">
                  Configure scheduling parameters for optimal session planning.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <Select
                  label="Instructor"
                  options={instructors?.map(instructor => ({
                    value: instructor?.name,
                    label: instructor?.name,
                    description: instructor?.specialization
                  }))}
                  value={formData?.instructor}
                  onChange={(value) => handleInputChange('instructor', value)}
                  error={errors?.instructor}
                  placeholder="Select instructor"
                  required
                />

                <Select
                  label="Location"
                  options={rooms?.map(room => ({
                    value: room?.name,
                    label: room?.name,
                    description: `Capacity: ${room?.capacity} people`
                  }))}
                  value={formData?.location}
                  onChange={(value) => handleInputChange('location', value)}
                  error={errors?.location}
                  placeholder="Select location"
                  required
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <Input
                  label="Session Duration (hours)"
                  type="number"
                  value={formData?.duration}
                  onChange={(e) => handleInputChange('duration', e?.target?.value)}
                  error={errors?.duration}
                  placeholder="2"
                  min="0.5"
                  step="0.5"
                  required
                />

                <Input
                  label="Max Session Size"
                  type="number"
                  value={formData?.maxSessionSize}
                  onChange={(e) => handleInputChange('maxSessionSize', e?.target?.value)}
                  error={errors?.maxSessionSize}
                  placeholder="15"
                  min="1"
                  required
                />

                <Input
                  label="Days Between Sessions"
                  type="number"
                  value={formData?.sessionGap}
                  onChange={(e) => handleInputChange('sessionGap', e?.target?.value)}
                  placeholder="1"
                  min="1"
                />
              </div>

              <div className="grid grid-cols-2 gap-6">
                <Input
                  label="Start Date"
                  type="date"
                  value={formData?.startDate}
                  onChange={(e) => handleInputChange('startDate', e?.target?.value)}
                  error={errors?.startDate}
                  required
                />

                <Input
                  label="End Date"
                  type="date"
                  value={formData?.endDate}
                  onChange={(e) => handleInputChange('endDate', e?.target?.value)}
                  error={errors?.endDate}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-3">
                  Preferred Time Slots *
                </label>
                {errors?.preferredTimes && (
                  <p className="text-sm text-error mb-2">{errors?.preferredTimes}</p>
                )}
                <div className="space-y-2">
                  {timeSlotOptions?.map((timeSlot) => (
                    <Checkbox
                      key={timeSlot?.value}
                      label={timeSlot?.label}
                      checked={formData?.preferredTimes?.includes(timeSlot?.value)}
                      onChange={(e) => handleTimeSlotSelection(timeSlot?.value, e?.target?.checked)}
                    />
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Step 4: Review & Confirm */}
          {currentStep === 4 && schedulingResults && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-foreground mb-4">
                  Review & Confirm
                </h3>
                <p className="text-sm text-muted-foreground mb-6">
                  Review the generated schedule and confirm to create all sessions.
                </p>
              </div>

              {/* Summary */}
              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 bg-muted rounded-lg text-center">
                  <div className="text-2xl font-bold text-primary">
                    {schedulingResults?.totalSessions}
                  </div>
                  <div className="text-sm text-muted-foreground">Sessions</div>
                </div>
                <div className="p-4 bg-muted rounded-lg text-center">
                  <div className="text-2xl font-bold text-primary">
                    {schedulingResults?.totalEmployees}
                  </div>
                  <div className="text-sm text-muted-foreground">Employees</div>
                </div>
                <div className="p-4 bg-muted rounded-lg text-center">
                  <div className="text-2xl font-bold text-success">
                    {schedulingResults?.conflicts?.length}
                  </div>
                  <div className="text-sm text-muted-foreground">Conflicts</div>
                </div>
              </div>

              {/* Session List */}
              <div className="space-y-3">
                <h4 className="font-medium text-foreground">Scheduled Sessions</h4>
                {schedulingResults?.sessions?.map((session, index) => (
                  <div key={session?.id} className="p-4 bg-background border border-border rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <h5 className="font-medium text-foreground">{session?.title}</h5>
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground mt-1">
                          <span>{session?.date}</span>
                          <span>{session?.time}</span>
                          <span>{session?.location}</span>
                          <span>{session?.attendees} attendees</span>
                        </div>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Instructor: {session?.instructor}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between p-6 border-t border-border">
          <div className="text-sm text-muted-foreground">
            Step {currentStep} of {steps?.length}
          </div>
          
          <div className="flex items-center space-x-3">
            <Button
              variant="outline"
              onClick={currentStep === 1 ? onClose : handlePrevious}
            >
              {currentStep === 1 ? 'Cancel' : 'Previous'}
            </Button>
            
            {currentStep < steps?.length ? (
              <Button
                variant="default"
                onClick={handleNext}
                iconName="ChevronRight"
                iconPosition="right"
              >
                Next
              </Button>
            ) : (
              <Button
                variant="default"
                onClick={handleSchedule}
                iconName="Calendar"
                iconPosition="left"
              >
                Schedule All Sessions
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BulkSchedulingWizard;