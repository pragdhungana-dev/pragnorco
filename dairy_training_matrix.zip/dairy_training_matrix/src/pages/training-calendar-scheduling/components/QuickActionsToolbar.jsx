import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const QuickActionsToolbar = ({ 
  onNewSession,
  onBulkSchedule,
  onExport,
  onFilterChange,
  currentFilters,
  onViewPresetChange,
  currentViewPreset 
}) => {
  const [showFilters, setShowFilters] = useState(false);

  const departmentOptions = [
    { value: '', label: 'All Departments' },
    { value: 'Production', label: 'Production Team' },
    { value: 'Quality', label: 'Quality Control' },
    { value: 'Safety', label: 'Safety Officers' },
    { value: 'Maintenance', label: 'Maintenance Team' },
    { value: 'Laboratory', label: 'Laboratory Staff' },
    { value: 'Management', label: 'Management' }
  ];

  const trainingTypeOptions = [
    { value: '', label: 'All Training Types' },
    { value: 'safety', label: 'Dairy Safety & Hygiene' },
    { value: 'haccp', label: 'HACCP & Food Safety' },
    { value: 'equipment', label: 'Equipment Operation' },
    { value: 'quality', label: 'Quality Control Procedures' },
    { value: 'emergency', label: 'Emergency Response' },
    { value: 'compliance', label: 'Regulatory Compliance' },
    { value: 'induction', label: 'New Employee Induction' }
  ];

  const instructorOptions = [
    { value: '', label: 'All Instructors' },
    { value: 'Dr. Sarah Johnson', label: 'Dr. Sarah Johnson' },
    { value: 'Mike Rodriguez', label: 'Mike Rodriguez' },
    { value: 'Lisa Chen', label: 'Lisa Chen' },
    { value: 'David Thompson', label: 'David Thompson' },
    { value: 'Emily Davis', label: 'Emily Davis' }
  ];

  const viewPresetOptions = [
    { value: 'all', label: 'All Sessions' },
    { value: 'my-department', label: 'My Department' },
    { value: 'my-sessions', label: 'My Sessions' },
    { value: 'upcoming', label: 'Upcoming Only' },
    { value: 'overdue', label: 'Overdue Training' },
    { value: 'high-priority', label: 'High Priority' }
  ];

  const exportOptions = [
    { value: 'schedule', label: 'Training Schedule' },
    { value: 'attendance', label: 'Attendance Sheets' },
    { value: 'utilization', label: 'Resource Utilization' },
    { value: 'instructor-workload', label: 'Instructor Workload' }
  ];

  const handleFilterChange = (field, value) => {
    onFilterChange({
      ...currentFilters,
      [field]: value
    });
  };

  const clearFilters = () => {
    onFilterChange({
      department: '',
      trainingType: '',
      instructor: '',
      status: ''
    });
  };

  const hasActiveFilters = () => {
    return Object.values(currentFilters)?.some(value => value !== '');
  };

  return (
    <div className="bg-card border-b border-border">
      {/* Main Toolbar */}
      <div className="flex items-center justify-between p-4">
        {/* Left Actions */}
        <div className="flex items-center space-x-3">
          <Button
            variant="default"
            onClick={onNewSession}
            iconName="Plus"
            iconPosition="left"
          >
            New Session
          </Button>

          <Button
            variant="outline"
            onClick={onBulkSchedule}
            iconName="Calendar"
            iconPosition="left"
          >
            Bulk Schedule
          </Button>

          <div className="h-6 w-px bg-border" />

          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowFilters(!showFilters)}
            iconName="Filter"
            iconPosition="left"
            className={hasActiveFilters() ? 'text-primary' : ''}
          >
            Filters
            {hasActiveFilters() && (
              <span className="ml-1 px-1.5 py-0.5 bg-primary text-primary-foreground text-xs rounded-full">
                {Object.values(currentFilters)?.filter(v => v !== '')?.length}
              </span>
            )}
          </Button>

          <Select
            options={viewPresetOptions}
            value={currentViewPreset}
            onChange={onViewPresetChange}
            placeholder="View preset"
            className="w-40"
          />
        </div>

        {/* Right Actions */}
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="sm"
            iconName="Search"
            iconPosition="left"
          >
            Search
          </Button>

          <div className="relative">
            <Button
              variant="ghost"
              size="sm"
              iconName="Download"
              iconPosition="left"
              onClick={() => {
                // Simple export - in real app would show dropdown
                onExport('schedule');
              }}
            >
              Export
            </Button>
          </div>

          <Button
            variant="ghost"
            size="sm"
            iconName="RefreshCw"
            iconPosition="left"
          >
            Refresh
          </Button>
        </div>
      </div>
      {/* Filters Panel */}
      {showFilters && (
        <div className="px-4 pb-4 border-t border-border bg-muted/30">
          <div className="grid grid-cols-4 gap-4 mt-4">
            <Select
              label="Department"
              options={departmentOptions}
              value={currentFilters?.department || ''}
              onChange={(value) => handleFilterChange('department', value)}
              placeholder="All departments"
            />

            <Select
              label="Training Type"
              options={trainingTypeOptions}
              value={currentFilters?.trainingType || ''}
              onChange={(value) => handleFilterChange('trainingType', value)}
              placeholder="All training types"
            />

            <Select
              label="Instructor"
              options={instructorOptions}
              value={currentFilters?.instructor || ''}
              onChange={(value) => handleFilterChange('instructor', value)}
              placeholder="All instructors"
            />

            <div className="flex items-end space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={clearFilters}
                iconName="X"
                iconPosition="left"
                disabled={!hasActiveFilters()}
              >
                Clear Filters
              </Button>
            </div>
          </div>

          {/* Active Filters Display */}
          {hasActiveFilters() && (
            <div className="flex items-center space-x-2 mt-3">
              <span className="text-sm text-muted-foreground">Active filters:</span>
              {Object.entries(currentFilters)?.map(([key, value]) => {
                if (!value) return null;
                
                const getFilterLabel = (key, value) => {
                  switch (key) {
                    case 'department':
                      return departmentOptions?.find(opt => opt?.value === value)?.label || value;
                    case 'trainingType':
                      return trainingTypeOptions?.find(opt => opt?.value === value)?.label || value;
                    case 'instructor':
                      return instructorOptions?.find(opt => opt?.value === value)?.label || value;
                    default:
                      return value;
                  }
                };

                return (
                  <span
                    key={key}
                    className="inline-flex items-center px-2 py-1 bg-primary/10 text-primary text-xs rounded-full"
                  >
                    {getFilterLabel(key, value)}
                    <button
                      onClick={() => handleFilterChange(key, '')}
                      className="ml-1 hover:bg-primary/20 rounded-full p-0.5"
                    >
                      <Icon name="X" size={10} />
                    </button>
                  </span>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default QuickActionsToolbar;