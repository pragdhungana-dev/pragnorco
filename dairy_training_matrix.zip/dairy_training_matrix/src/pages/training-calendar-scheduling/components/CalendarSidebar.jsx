import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const CalendarSidebar = ({ 
  upcomingSessions, 
  instructors, 
  rooms,
  onSessionClick,
  onNewSession 
}) => {
  const [activeTab, setActiveTab] = useState('upcoming');

  const tabs = [
    { id: 'upcoming', label: 'Upcoming', icon: 'Clock' },
    { id: 'instructors', label: 'Instructors', icon: 'Users' },
    { id: 'resources', label: 'Resources', icon: 'Building' }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'available': return 'text-success';
      case 'busy': return 'text-warning';
      case 'unavailable': return 'text-error';
      default: return 'text-muted-foreground';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'available': return 'CheckCircle';
      case 'busy': return 'Clock';
      case 'unavailable': return 'XCircle';
      default: return 'Circle';
    }
  };

  return (
    <div className="w-80 bg-card border-r border-border flex flex-col h-full">
      {/* Sidebar Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">
            Training Schedule
          </h3>
          <Button
            variant="default"
            size="sm"
            onClick={onNewSession}
            iconName="Plus"
            iconPosition="left"
          >
            New Session
          </Button>
        </div>

        {/* Tab Navigation */}
        <div className="flex space-x-1 bg-muted rounded-lg p-1">
          {tabs?.map((tab) => (
            <Button
              key={tab?.id}
              variant={activeTab === tab?.id ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveTab(tab?.id)}
              iconName={tab?.icon}
              iconPosition="left"
              className="flex-1"
            >
              {tab?.label}
            </Button>
          ))}
        </div>
      </div>
      {/* Tab Content */}
      <div className="flex-1 overflow-y-auto p-4">
        {activeTab === 'upcoming' && (
          <div className="space-y-3">
            <h4 className="text-sm font-medium text-muted-foreground mb-3">
              Next 7 Days ({upcomingSessions?.length} sessions)
            </h4>
            {upcomingSessions?.map((session) => (
              <div
                key={session?.id}
                onClick={() => onSessionClick(session)}
                className="p-3 bg-background border border-border rounded-lg cursor-pointer hover:bg-muted transition-colors"
              >
                <div className="flex items-start justify-between mb-2">
                  <h5 className="text-sm font-medium text-foreground truncate">
                    {session?.title}
                  </h5>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    session?.department === 'Production' ? 'bg-blue-100 text-blue-800' :
                    session?.department === 'Quality' ? 'bg-green-100 text-green-800' :
                    session?.department === 'Safety'? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800'
                  }`}>
                    {session?.department}
                  </span>
                </div>
                <div className="space-y-1 text-xs text-muted-foreground">
                  <div className="flex items-center space-x-2">
                    <Icon name="Calendar" size={12} />
                    <span>{session?.date}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Icon name="Clock" size={12} />
                    <span>{session?.time}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Icon name="MapPin" size={12} />
                    <span>{session?.location}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Icon name="Users" size={12} />
                    <span>{session?.attendees} attendees</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'instructors' && (
          <div className="space-y-3">
            <h4 className="text-sm font-medium text-muted-foreground mb-3">
              Instructor Availability
            </h4>
            {instructors?.map((instructor) => (
              <div
                key={instructor?.id}
                className="p-3 bg-background border border-border rounded-lg"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                      <span className="text-xs font-medium text-primary-foreground">
                        {instructor?.name?.split(' ')?.map(n => n?.[0])?.join('')}
                      </span>
                    </div>
                    <div>
                      <h5 className="text-sm font-medium text-foreground">
                        {instructor?.name}
                      </h5>
                      <p className="text-xs text-muted-foreground">
                        {instructor?.specialization}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Icon 
                      name={getStatusIcon(instructor?.status)} 
                      size={12} 
                      className={getStatusColor(instructor?.status)}
                    />
                    <span className={`text-xs capitalize ${getStatusColor(instructor?.status)}`}>
                      {instructor?.status}
                    </span>
                  </div>
                </div>
                <div className="text-xs text-muted-foreground">
                  <div className="flex justify-between">
                    <span>Sessions Today:</span>
                    <span className="font-medium">{instructor?.sessionsToday}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Next Available:</span>
                    <span className="font-medium">{instructor?.nextAvailable}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'resources' && (
          <div className="space-y-3">
            <h4 className="text-sm font-medium text-muted-foreground mb-3">
              Room & Equipment Status
            </h4>
            {rooms?.map((room) => (
              <div
                key={room?.id}
                className="p-3 bg-background border border-border rounded-lg"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <Icon name="Building" size={16} className="text-muted-foreground" />
                    <div>
                      <h5 className="text-sm font-medium text-foreground">
                        {room?.name}
                      </h5>
                      <p className="text-xs text-muted-foreground">
                        Capacity: {room?.capacity} people
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Icon 
                      name={getStatusIcon(room?.status)} 
                      size={12} 
                      className={getStatusColor(room?.status)}
                    />
                    <span className={`text-xs capitalize ${getStatusColor(room?.status)}`}>
                      {room?.status}
                    </span>
                  </div>
                </div>
                <div className="space-y-1 text-xs text-muted-foreground">
                  <div className="flex justify-between">
                    <span>Current Session:</span>
                    <span className="font-medium">
                      {room?.currentSession || 'None'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Next Available:</span>
                    <span className="font-medium">{room?.nextAvailable}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Utilization:</span>
                    <span className="font-medium">{room?.utilization}%</span>
                  </div>
                </div>
                {room?.equipment && room?.equipment?.length > 0 && (
                  <div className="mt-2 pt-2 border-t border-border">
                    <p className="text-xs text-muted-foreground mb-1">Equipment:</p>
                    <div className="flex flex-wrap gap-1">
                      {room?.equipment?.map((item, index) => (
                        <span
                          key={index}
                          className="text-xs px-2 py-1 bg-muted rounded text-muted-foreground"
                        >
                          {item}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default CalendarSidebar;