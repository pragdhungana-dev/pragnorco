import React from 'react';

import Button from '../../../components/ui/Button';

const CalendarHeader = ({ 
  currentDate, 
  viewMode, 
  onViewModeChange, 
  onNavigate,
  onTodayClick 
}) => {
  const formatHeaderDate = () => {
    const options = {
      month: { month: 'long', year: 'numeric' },
      week: { month: 'short', day: 'numeric', year: 'numeric' },
      day: { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }
    };
    
    return currentDate?.toLocaleDateString('en-US', options?.[viewMode]);
  };

  return (
    <div className="flex items-center justify-between p-4 bg-card border-b border-border">
      {/* Navigation Controls */}
      <div className="flex items-center space-x-2">
        <Button
          variant="outline"
          size="sm"
          onClick={() => onNavigate('prev')}
          iconName="ChevronLeft"
          iconPosition="left"
        >
          Previous
        </Button>
        
        <Button
          variant="ghost"
          size="sm"
          onClick={onTodayClick}
        >
          Today
        </Button>
        
        <Button
          variant="outline"
          size="sm"
          onClick={() => onNavigate('next')}
          iconName="ChevronRight"
          iconPosition="right"
        >
          Next
        </Button>
      </div>
      {/* Current Date Display */}
      <div className="flex-1 text-center">
        <h2 className="text-xl font-semibold text-foreground">
          {formatHeaderDate()}
        </h2>
      </div>
      {/* View Mode Controls */}
      <div className="flex items-center space-x-1 bg-muted rounded-lg p-1">
        {['month', 'week', 'day']?.map((mode) => (
          <Button
            key={mode}
            variant={viewMode === mode ? 'default' : 'ghost'}
            size="sm"
            onClick={() => onViewModeChange(mode)}
            className="capitalize"
          >
            {mode}
          </Button>
        ))}
      </div>
    </div>
  );
};

export default CalendarHeader;