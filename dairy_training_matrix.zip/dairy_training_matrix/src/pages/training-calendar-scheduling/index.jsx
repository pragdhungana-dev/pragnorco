import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import RoleBasedSidebar from '../../components/ui/RoleBasedSidebar';
import CalendarHeader from './components/CalendarHeader';
import CalendarSidebar from './components/CalendarSidebar';
import CalendarGrid from './components/CalendarGrid';
import SessionModal from './components/SessionModal';
import BulkSchedulingWizard from './components/BulkSchedulingWizard';
import QuickActionsToolbar from './components/QuickActionsToolbar';

const TrainingCalendarScheduling = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewMode, setViewMode] = useState('month');
  const [selectedSession, setSelectedSession] = useState(null);
  const [isSessionModalOpen, setIsSessionModalOpen] = useState(false);
  const [isBulkSchedulingOpen, setIsBulkSchedulingOpen] = useState(false);
  const [filters, setFilters] = useState({
    department: '',
    trainingType: '',
    instructor: '',
    status: ''
  });
  const [viewPreset, setViewPreset] = useState('all');

  // Mock data
  const sessions = [
    {
      id: "1",
      title: "HACCP Fundamentals",
      description: "Introduction to Hazard Analysis and Critical Control Points",
      department: "Quality",
      trainingType: "haccp",
      instructor: "Dr. Sarah Johnson",
      location: "Training Room A",
      startTime: "2024-08-25T09:00:00",
      endTime: "2024-08-25T12:00:00",
      maxAttendees: 20,
      attendees: 15,
      isRecurring: false,
      notes: "Bring safety equipment"
    },
    {
      id: "2",
      title: "Equipment Safety Training",
      description: "Safe operation of dairy processing equipment",
      department: "Production",
      trainingType: "equipment",
      instructor: "Mike Rodriguez",
      location: "Production Floor",
      startTime: "2024-08-26T14:00:00",
      endTime: "2024-08-26T16:00:00",
      maxAttendees: 12,
      attendees: 10,
      isRecurring: true,
      recurringPattern: "weekly",
      notes: "Hands-on training session"
    },
    {
      id: "3",
      title: "Emergency Response Drill",
      description: "Fire safety and evacuation procedures",
      department: "Safety",
      trainingType: "emergency",
      instructor: "Lisa Chen",
      location: "Main Assembly Area",
      startTime: "2024-08-27T10:00:00",
      endTime: "2024-08-27T11:30:00",
      maxAttendees: 50,
      attendees: 45,
      isRecurring: false,
      notes: "All departments mandatory"
    },
    {
      id: "4",
      title: "Quality Control Procedures",
      description: "Standard operating procedures for quality testing",
      department: "Quality",
      trainingType: "quality",
      instructor: "David Thompson",
      location: "Laboratory",
      startTime: "2024-08-28T08:00:00",
      endTime: "2024-08-28T10:00:00",
      maxAttendees: 8,
      attendees: 6,
      isRecurring: false,
      notes: "Lab coats required"
    },
    {
      id: "5",
      title: "New Employee Orientation",
      description: "Company policies and safety introduction",
      department: "Management",
      trainingType: "induction",
      instructor: "Emily Davis",
      location: "Conference Room",
      startTime: "2024-08-29T13:00:00",
      endTime: "2024-08-29T17:00:00",
      maxAttendees: 15,
      attendees: 8,
      isRecurring: true,
      recurringPattern: "monthly",
      notes: "Welcome package provided"
    }
  ];

  const upcomingSessions = [
    {
      id: "1",
      title: "HACCP Fundamentals",
      department: "Quality",
      date: "Aug 25, 2024",
      time: "9:00 AM - 12:00 PM",
      location: "Training Room A",
      attendees: 15,
      instructor: "Dr. Sarah Johnson"
    },
    {
      id: "2",
      title: "Equipment Safety Training",
      department: "Production",
      date: "Aug 26, 2024",
      time: "2:00 PM - 4:00 PM",
      location: "Production Floor",
      attendees: 10,
      instructor: "Mike Rodriguez"
    },
    {
      id: "3",
      title: "Emergency Response Drill",
      department: "Safety",
      date: "Aug 27, 2024",
      time: "10:00 AM - 11:30 AM",
      location: "Main Assembly Area",
      attendees: 45,
      instructor: "Lisa Chen"
    },
    {
      id: "4",
      title: "Quality Control Procedures",
      department: "Quality",
      date: "Aug 28, 2024",
      time: "8:00 AM - 10:00 AM",
      location: "Laboratory",
      attendees: 6,
      instructor: "David Thompson"
    },
    {
      id: "5",
      title: "New Employee Orientation",
      department: "Management",
      date: "Aug 29, 2024",
      time: "1:00 PM - 5:00 PM",
      location: "Conference Room",
      attendees: 8,
      instructor: "Emily Davis"
    }
  ];

  const instructors = [
    {
      id: "1",
      name: "Dr. Sarah Johnson",
      specialization: "Food Safety & HACCP",
      status: "available",
      sessionsToday: 2,
      nextAvailable: "2:00 PM"
    },
    {
      id: "2",
      name: "Mike Rodriguez",
      specialization: "Equipment & Maintenance",
      status: "busy",
      sessionsToday: 3,
      nextAvailable: "Tomorrow 9:00 AM"
    },
    {
      id: "3",
      name: "Lisa Chen",
      specialization: "Safety & Emergency Response",
      status: "available",
      sessionsToday: 1,
      nextAvailable: "4:00 PM"
    },
    {
      id: "4",
      name: "David Thompson",
      specialization: "Quality Control",
      status: "unavailable",
      sessionsToday: 0,
      nextAvailable: "Monday 8:00 AM"
    },
    {
      id: "5",
      name: "Emily Davis",
      specialization: "HR & Compliance",
      status: "available",
      sessionsToday: 1,
      nextAvailable: "11:00 AM"
    }
  ];

  const rooms = [
    {
      id: "1",
      name: "Training Room A",
      capacity: 25,
      status: "available",
      currentSession: null,
      nextAvailable: "Available now",
      utilization: 65,
      equipment: ["Projector", "Whiteboard", "Audio System"]
    },
    {
      id: "2",
      name: "Training Room B",
      capacity: 15,
      status: "busy",
      currentSession: "Safety Meeting",
      nextAvailable: "3:00 PM",
      utilization: 80,
      equipment: ["Projector", "Flipchart"]
    },
    {
      id: "3",
      name: "Production Floor",
      capacity: 30,
      status: "available",
      currentSession: null,
      nextAvailable: "Available now",
      utilization: 45,
      equipment: ["Safety Equipment", "Machinery Access"]
    },
    {
      id: "4",
      name: "Laboratory",
      capacity: 10,
      status: "available",
      currentSession: null,
      nextAvailable: "Available now",
      utilization: 55,
      equipment: ["Lab Equipment", "Testing Stations", "Safety Shower"]
    },
    {
      id: "5",
      name: "Conference Room",
      capacity: 20,
      status: "busy",
      currentSession: "Management Review",
      nextAvailable: "5:00 PM",
      utilization: 70,
      equipment: ["Video Conferencing", "Projector", "Whiteboard"]
    }
  ];

  const employees = [
    {
      id: "1",
      name: "John Smith",
      role: "Production Operator",
      department: "Production",
      lastTraining: "Jul 15, 2024",
      complianceStatus: "Compliant"
    },
    {
      id: "2",
      name: "Maria Garcia",
      role: "Quality Technician",
      department: "Quality",
      lastTraining: "Jun 20, 2024",
      complianceStatus: "Due Soon"
    },
    {
      id: "3",
      name: "Robert Johnson",
      role: "Maintenance Tech",
      department: "Maintenance",
      lastTraining: "May 10, 2024",
      complianceStatus: "Overdue"
    },
    {
      id: "4",
      name: "Lisa Wong",
      role: "Lab Analyst",
      department: "Laboratory",
      lastTraining: "Aug 01, 2024",
      complianceStatus: "Compliant"
    },
    {
      id: "5",
      name: "Michael Brown",
      role: "Safety Officer",
      department: "Safety",
      lastTraining: "Jul 25, 2024",
      complianceStatus: "Compliant"
    },
    {
      id: "6",
      name: "Sarah Davis",
      role: "Production Supervisor",
      department: "Production",
      lastTraining: "Jun 05, 2024",
      complianceStatus: "Due Soon"
    },
    {
      id: "7",
      name: "James Wilson",
      role: "Packaging Operator",
      department: "Production",
      lastTraining: "Apr 15, 2024",
      complianceStatus: "Overdue"
    },
    {
      id: "8",
      name: "Jennifer Lee",
      role: "Quality Manager",
      department: "Quality",
      lastTraining: "Aug 10, 2024",
      complianceStatus: "Compliant"
    }
  ];

  const handleMenuToggle = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleSidebarToggle = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const handleNavigate = (direction) => {
    const newDate = new Date(currentDate);
    
    switch (viewMode) {
      case 'month':
        newDate?.setMonth(newDate?.getMonth() + (direction === 'next' ? 1 : -1));
        break;
      case 'week':
        newDate?.setDate(newDate?.getDate() + (direction === 'next' ? 7 : -7));
        break;
      case 'day':
        newDate?.setDate(newDate?.getDate() + (direction === 'next' ? 1 : -1));
        break;
    }
    
    setCurrentDate(newDate);
  };

  const handleTodayClick = () => {
    setCurrentDate(new Date());
  };

  const handleSessionClick = (session) => {
    setSelectedSession(session);
    setIsSessionModalOpen(true);
  };

  const handleNewSession = () => {
    setSelectedSession(null);
    setIsSessionModalOpen(true);
  };

  const handleTimeSlotClick = (dateTime) => {
    const newSession = {
      startTime: dateTime?.toISOString(),
      endTime: new Date(dateTime.getTime() + 2 * 60 * 60 * 1000)?.toISOString() // 2 hours later
    };
    setSelectedSession(newSession);
    setIsSessionModalOpen(true);
  };

  const handleSessionSave = (sessionData) => {
    console.log('Saving session:', sessionData);
    setIsSessionModalOpen(false);
    setSelectedSession(null);
  };

  const handleSessionDelete = (sessionId) => {
    console.log('Deleting session:', sessionId);
    setIsSessionModalOpen(false);
    setSelectedSession(null);
  };

  const handleBulkSchedule = (scheduleData) => {
    console.log('Bulk scheduling:', scheduleData);
    setIsBulkSchedulingOpen(false);
  };

  const handleExport = (type) => {
    console.log('Exporting:', type);
  };

  const handleFilterChange = (newFilters) => {
    setFilters(newFilters);
  };

  const handleViewPresetChange = (preset) => {
    setViewPreset(preset);
  };

  // Filter sessions based on current filters
  const filteredSessions = sessions?.filter(session => {
    if (filters?.department && session?.department !== filters?.department) return false;
    if (filters?.trainingType && session?.trainingType !== filters?.trainingType) return false;
    if (filters?.instructor && session?.instructor !== filters?.instructor) return false;
    return true;
  });

  return (
    <>
      <Helmet>
        <title>Training Calendar & Scheduling - Dairy Training Matrix</title>
        <meta name="description" content="Schedule and manage training sessions across multiple shifts and departments with intelligent resource allocation and conflict detection." />
      </Helmet>

      <div className="min-h-screen bg-background">
        {/* Header */}
        <Header onMenuToggle={handleMenuToggle} isMenuOpen={isMenuOpen} />

        {/* Sidebar */}
        <RoleBasedSidebar
          isCollapsed={isSidebarCollapsed}
          onToggleCollapse={handleSidebarToggle}
          userRole="training_coordinator"
          className="lg:block hidden"
        />

        {/* Main Content */}
        <main className={`transition-all duration-200 ${
          isSidebarCollapsed ? 'lg:ml-16' : 'lg:ml-60'
        } mt-16`}>
          <div className="flex h-[calc(100vh-4rem)]">
            {/* Calendar Sidebar */}
            <CalendarSidebar
              upcomingSessions={upcomingSessions}
              instructors={instructors}
              rooms={rooms}
              onSessionClick={handleSessionClick}
              onNewSession={handleNewSession}
            />

            {/* Main Calendar Area */}
            <div className="flex-1 flex flex-col">
              {/* Quick Actions Toolbar */}
              <QuickActionsToolbar
                onNewSession={handleNewSession}
                onBulkSchedule={() => setIsBulkSchedulingOpen(true)}
                onExport={handleExport}
                onFilterChange={handleFilterChange}
                currentFilters={filters}
                onViewPresetChange={handleViewPresetChange}
                currentViewPreset={viewPreset}
              />

              {/* Calendar Header */}
              <CalendarHeader
                currentDate={currentDate}
                viewMode={viewMode}
                onViewModeChange={setViewMode}
                onNavigate={handleNavigate}
                onTodayClick={handleTodayClick}
              />

              {/* Calendar Grid */}
              <CalendarGrid
                viewMode={viewMode}
                currentDate={currentDate}
                sessions={filteredSessions}
                onSessionClick={handleSessionClick}
                onTimeSlotClick={handleTimeSlotClick}
                onSessionDrop={(sessionId, newDateTime) => {
                  console.log('Moving session:', sessionId, 'to:', newDateTime);
                  // Handle session drag and drop logic here
                }}
              />
            </div>
          </div>
        </main>

        {/* Modals */}
        <SessionModal
          isOpen={isSessionModalOpen}
          onClose={() => {
            setIsSessionModalOpen(false);
            setSelectedSession(null);
          }}
          session={selectedSession}
          onSave={handleSessionSave}
          onDelete={handleSessionDelete}
          instructors={instructors}
          rooms={rooms}
        />

        <BulkSchedulingWizard
          isOpen={isBulkSchedulingOpen}
          onClose={() => setIsBulkSchedulingOpen(false)}
          onSchedule={handleBulkSchedule}
          employees={employees}
          instructors={instructors}
          rooms={rooms}
        />
      </div>
    </>
  );
};

export default TrainingCalendarScheduling;