import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
import NotFound from "pages/NotFound";
import CertificateManagementSystem from './pages/certificate-management-system';
import EmployeeTrainingDashboard from './pages/employee-training-dashboard';
import TrainingAnalyticsInsights from './pages/training-analytics-insights';
import TrainingRequirementsMatrix from './pages/training-requirements-matrix';
import TrainingCalendarScheduling from './pages/training-calendar-scheduling';
import TrainingCourseManagement from './pages/training-course-management';
import UserRoleManagement from './pages/user-role-management';
import ComplianceReportingDashboard from './pages/compliance-reporting-dashboard';

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Define your route here */}
        <Route path="/" element={<CertificateManagementSystem />} />
        <Route path="/certificate-management-system" element={<CertificateManagementSystem />} />
        <Route path="/employee-training-dashboard" element={<EmployeeTrainingDashboard />} />
        <Route path="/training-analytics-insights" element={<TrainingAnalyticsInsights />} />
        <Route path="/training-requirements-matrix" element={<TrainingRequirementsMatrix />} />
        <Route path="/training-calendar-scheduling" element={<TrainingCalendarScheduling />} />
        <Route path="/training-course-management" element={<TrainingCourseManagement />} />
        <Route path="/user-role-management" element={<UserRoleManagement />} />
        <Route path="/compliance-reporting-dashboard" element={<ComplianceReportingDashboard />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;
