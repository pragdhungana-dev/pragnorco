import React, { useState, useEffect } from 'react';
import Icon from '../AppIcon';

const ComplianceStatusIndicator = ({ 
  path, 
  size = 'default',
  showCount = true,
  className = '' 
}) => {
  const [complianceData, setComplianceData] = useState({
    overdue: 0,
    upcoming: 0,
    compliant: 0,
    status: 'loading'
  });

  // Mock compliance data based on path
  useEffect(() => {
    const mockData = {
      '/training-requirements-matrix': {
        overdue: 12,
        upcoming: 8,
        compliant: 156,
        status: 'warning'
      },
      '/employee-training-dashboard': {
        overdue: 5,
        upcoming: 15,
        compliant: 180,
        status: 'success'
      },
      '/compliance-reporting-dashboard': {
        overdue: 3,
        upcoming: 7,
        compliant: 190,
        status: 'success'
      }
    };

    // Simulate API call delay
    const timer = setTimeout(() => {
      const data = mockData?.[path] || {
        overdue: 0,
        upcoming: 0,
        compliant: 0,
        status: 'success'
      };
      setComplianceData(data);
    }, 500);

    return () => clearTimeout(timer);
  }, [path]);

  const getStatusColor = () => {
    if (complianceData?.status === 'loading') return 'muted';
    if (complianceData?.overdue > 10) return 'error';
    if (complianceData?.overdue > 0 || complianceData?.upcoming > 10) return 'warning';
    return 'success';
  };

  const getStatusIcon = () => {
    if (complianceData?.status === 'loading') return 'Loader2';
    if (complianceData?.overdue > 10) return 'AlertTriangle';
    if (complianceData?.overdue > 0) return 'Clock';
    return 'CheckCircle';
  };

  const getTotalIssues = () => {
    return complianceData?.overdue + (complianceData?.upcoming > 10 ? complianceData?.upcoming - 10 : 0);
  };

  const sizeClasses = {
    sm: 'w-2 h-2',
    default: 'w-3 h-3',
    lg: 'w-4 h-4'
  };

  const iconSizes = {
    sm: 12,
    default: 14,
    lg: 16
  };

  if (complianceData?.status === 'loading') {
    return (
      <div className={`flex items-center space-x-1 ${className}`}>
        <div className={`${sizeClasses?.[size]} bg-muted rounded-full animate-pulse-subtle`} />
        {showCount && size !== 'sm' && (
          <Icon name="Loader2" size={iconSizes?.[size]} className="animate-spin text-muted-foreground" />
        )}
      </div>
    );
  }

  const statusColor = getStatusColor();
  const totalIssues = getTotalIssues();

  return (
    <div className={`flex items-center space-x-1 status-indicator ${className}`}>
      {/* Status Dot */}
      <div 
        className={`
          ${sizeClasses?.[size]} rounded-full
          ${statusColor === 'success' ? 'compliance-status-success' : ''}
          ${statusColor === 'warning' ? 'compliance-status-warning' : ''}
          ${statusColor === 'error' ? 'compliance-status-error' : ''}
          ${statusColor === 'muted' ? 'bg-muted' : ''}
        `}
        title={`Compliance Status: ${statusColor}`}
      />
      {/* Issue Count */}
      {showCount && totalIssues > 0 && size !== 'sm' && (
        <div className="flex items-center space-x-1">
          <Icon 
            name={getStatusIcon()} 
            size={iconSizes?.[size]} 
            className={`
              ${statusColor === 'error' ? 'text-error' : ''}
              ${statusColor === 'warning' ? 'text-warning' : ''}
              ${statusColor === 'success' ? 'text-success' : ''}
            `}
          />
          <span 
            className={`
              text-xs font-medium text-data
              ${statusColor === 'error' ? 'text-error' : ''}
              ${statusColor === 'warning' ? 'text-warning' : ''}
              ${statusColor === 'success' ? 'text-success' : ''}
            `}
          >
            {totalIssues}
          </span>
        </div>
      )}
      {/* Detailed Tooltip Content (Hidden, for future tooltip implementation) */}
      <div className="hidden">
        <div className="text-xs space-y-1">
          <div className="flex justify-between">
            <span>Overdue:</span>
            <span className="text-error font-medium">{complianceData?.overdue}</span>
          </div>
          <div className="flex justify-between">
            <span>Upcoming:</span>
            <span className="text-warning font-medium">{complianceData?.upcoming}</span>
          </div>
          <div className="flex justify-between">
            <span>Compliant:</span>
            <span className="text-success font-medium">{complianceData?.compliant}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ComplianceStatusIndicator;