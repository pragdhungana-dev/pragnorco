import React, { useState, useEffect } from 'react';
import Icon from '../AppIcon';

const SystemSyncStatus = ({ isCollapsed = false, className = '' }) => {
  const [syncStatus, setSyncStatus] = useState({
    hris: { status: 'connected', lastSync: null, error: null },
    erp: { status: 'connected', lastSync: null, error: null },
    training: { status: 'connected', lastSync: null, error: null },
    overall: 'syncing'
  });

  const [lastUpdateTime, setLastUpdateTime] = useState(new Date());

  useEffect(() => {
    // Simulate initial sync check
    const initialTimer = setTimeout(() => {
      setSyncStatus({
        hris: { 
          status: 'connected', 
          lastSync: new Date(Date.now() - 5 * 60 * 1000), // 5 minutes ago
          error: null 
        },
        erp: { 
          status: 'connected', 
          lastSync: new Date(Date.now() - 3 * 60 * 1000), // 3 minutes ago
          error: null 
        },
        training: { 
          status: 'warning', 
          lastSync: new Date(Date.now() - 15 * 60 * 1000), // 15 minutes ago
          error: 'Slow response from training provider API' 
        },
        overall: 'warning'
      });
      setLastUpdateTime(new Date());
    }, 2000);

    // Periodic sync status updates
    const interval = setInterval(() => {
      setSyncStatus(prev => {
        const now = new Date();
        return {
          ...prev,
          hris: {
            ...prev?.hris,
            lastSync: new Date(now.getTime() - Math.random() * 10 * 60 * 1000)
          },
          erp: {
            ...prev?.erp,
            lastSync: new Date(now.getTime() - Math.random() * 8 * 60 * 1000)
          }
        };
      });
      setLastUpdateTime(new Date());
    }, 30000); // Update every 30 seconds

    return () => {
      clearTimeout(initialTimer);
      clearInterval(interval);
    };
  }, []);

  const getOverallStatus = () => {
    const statuses = [syncStatus?.hris?.status, syncStatus?.erp?.status, syncStatus?.training?.status];
    if (statuses?.includes('error')) return 'error';
    if (statuses?.includes('warning')) return 'warning';
    if (statuses?.includes('syncing')) return 'syncing';
    return 'connected';
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'connected': return 'CheckCircle';
      case 'warning': return 'AlertTriangle';
      case 'error': return 'XCircle';
      case 'syncing': return 'RefreshCw';
      default: return 'Circle';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'connected': return 'text-success';
      case 'warning': return 'text-warning';
      case 'error': return 'text-error';
      case 'syncing': return 'text-accent';
      default: return 'text-muted-foreground';
    }
  };

  const formatLastSync = (date) => {
    if (!date) return 'Never';
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    return date?.toLocaleDateString();
  };

  const overallStatus = getOverallStatus();

  if (isCollapsed) {
    return (
      <div className={`flex justify-center ${className}`}>
        <div 
          className="relative cursor-pointer"
          title={`System Status: ${overallStatus?.charAt(0)?.toUpperCase() + overallStatus?.slice(1)}`}
        >
          <Icon 
            name={getStatusIcon(overallStatus)} 
            size={16} 
            className={`${getStatusColor(overallStatus)} ${overallStatus === 'syncing' ? 'animate-spin' : ''}`}
          />
          {(overallStatus === 'warning' || overallStatus === 'error') && (
            <div className="absolute -top-1 -right-1 w-2 h-2 bg-error rounded-full"></div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className={`space-y-2 ${className}`}>
      {/* Overall Status Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Icon 
            name={getStatusIcon(overallStatus)} 
            size={14} 
            className={`${getStatusColor(overallStatus)} ${overallStatus === 'syncing' ? 'animate-spin' : ''}`}
          />
          <span className="text-xs font-medium text-foreground">
            System Status
          </span>
        </div>
        <span className={`text-xs font-medium ${getStatusColor(overallStatus)}`}>
          {overallStatus?.charAt(0)?.toUpperCase() + overallStatus?.slice(1)}
        </span>
      </div>
      {/* Detailed Status */}
      <div className="space-y-1">
        {/* HRIS Integration */}
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center space-x-2">
            <Icon 
              name={getStatusIcon(syncStatus?.hris?.status)} 
              size={10} 
              className={getStatusColor(syncStatus?.hris?.status)}
            />
            <span className="text-muted-foreground">HRIS</span>
          </div>
          <span className="text-data text-muted-foreground">
            {formatLastSync(syncStatus?.hris?.lastSync)}
          </span>
        </div>

        {/* ERP Integration */}
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center space-x-2">
            <Icon 
              name={getStatusIcon(syncStatus?.erp?.status)} 
              size={10} 
              className={getStatusColor(syncStatus?.erp?.status)}
            />
            <span className="text-muted-foreground">ERP</span>
          </div>
          <span className="text-data text-muted-foreground">
            {formatLastSync(syncStatus?.erp?.lastSync)}
          </span>
        </div>

        {/* Training Provider */}
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center space-x-2">
            <Icon 
              name={getStatusIcon(syncStatus?.training?.status)} 
              size={10} 
              className={getStatusColor(syncStatus?.training?.status)}
            />
            <span className="text-muted-foreground">Training</span>
          </div>
          <span className="text-data text-muted-foreground">
            {formatLastSync(syncStatus?.training?.lastSync)}
          </span>
        </div>
      </div>
      {/* Last Update Time */}
      <div className="pt-1 border-t border-border">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>Last checked</span>
          <span className="text-data">
            {lastUpdateTime?.toLocaleTimeString([], { 
              hour: '2-digit', 
              minute: '2-digit' 
            })}
          </span>
        </div>
      </div>
      {/* Error Messages */}
      {syncStatus?.training?.error && (
        <div className="p-2 bg-warning/10 border border-warning/20 rounded text-xs">
          <div className="flex items-start space-x-2">
            <Icon name="AlertTriangle" size={12} className="text-warning mt-0.5 flex-shrink-0" />
            <span className="text-warning">{syncStatus?.training?.error}</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default SystemSyncStatus;