import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const Header = ({ onMenuToggle, isMenuOpen = false }) => {
  const location = useLocation();
  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);

  const primaryNavItems = [
    {
      label: 'Training Matrix',
      path: '/training-requirements-matrix',
      icon: 'Grid3X3',
      tooltip: 'View and manage training requirements matrix'
    },
    {
      label: 'Employee Dashboard',
      path: '/employee-training-dashboard',
      icon: 'Users',
      tooltip: 'Monitor employee training status and progress'
    },
    {
      label: 'Course Management',
      path: '/training-course-management',
      icon: 'BookOpen',
      tooltip: 'Manage training courses and content'
    },
    {
      label: 'Compliance Reports',
      path: '/compliance-reporting-dashboard',
      icon: 'BarChart3',
      tooltip: 'View compliance reports and analytics'
    }
  ];

  const secondaryNavItems = [
    {
      label: 'Training Calendar',
      path: '/training-calendar-scheduling',
      icon: 'Calendar',
      tooltip: 'Schedule and manage training sessions'
    },
    {
      label: 'Certificates',
      path: '/certificate-management-system',
      icon: 'Award',
      tooltip: 'Manage training certificates and credentials'
    },
    {
      label: 'User Management',
      path: '/user-role-management',
      icon: 'Settings',
      tooltip: 'Manage users and role permissions'
    },
    {
      label: 'Analytics',
      path: '/training-analytics-insights',
      icon: 'TrendingUp',
      tooltip: 'View training analytics and insights'
    }
  ];

  const handleNavClick = (path) => {
    window.location.href = path;
  };

  const handleMoreMenuToggle = () => {
    setIsMoreMenuOpen(!isMoreMenuOpen);
  };

  const isActivePath = (path) => {
    return location?.pathname === path;
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-100 bg-card border-b border-border shadow-industrial">
      <div className="flex items-center justify-between h-16 px-4">
        {/* Left Section - Logo and Mobile Menu */}
        <div className="flex items-center space-x-4">
          {/* Mobile Menu Toggle */}
          <Button
            variant="ghost"
            size="icon"
            onClick={onMenuToggle}
            className="lg:hidden"
            aria-label="Toggle navigation menu"
          >
            <Icon name={isMenuOpen ? 'X' : 'Menu'} size={20} />
          </Button>

          {/* Logo */}
          <div className="flex items-center space-x-3">
            <div className="flex items-center justify-center w-8 h-8 bg-primary rounded-lg">
              <Icon name="GraduationCap" size={20} color="white" />
            </div>
            <div className="hidden sm:block">
              <h1 className="text-lg font-semibold text-foreground">
                Dairy Training Matrix
              </h1>
              <p className="text-xs text-muted-foreground">
                Compliance Management System
              </p>
            </div>
          </div>
        </div>

        {/* Center Section - Primary Navigation (Desktop) */}
        <nav className="hidden lg:flex items-center space-x-1">
          {primaryNavItems?.map((item) => (
            <Button
              key={item?.path}
              variant={isActivePath(item?.path) ? 'default' : 'ghost'}
              size="sm"
              onClick={() => handleNavClick(item?.path)}
              className="nav-item-hover"
              title={item?.tooltip}
            >
              <Icon name={item?.icon} size={16} className="mr-2" />
              {item?.label}
            </Button>
          ))}

          {/* More Menu */}
          <div className="relative">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleMoreMenuToggle}
              className="nav-item-hover"
              iconName="MoreHorizontal"
              iconPosition="right"
            >
              More
            </Button>

            {/* More Menu Dropdown */}
            {isMoreMenuOpen && (
              <div className="absolute top-full right-0 mt-1 w-56 bg-popover border border-border rounded-lg shadow-industrial-strong z-200 animate-fade-in">
                <div className="py-2">
                  {secondaryNavItems?.map((item) => (
                    <button
                      key={item?.path}
                      onClick={() => {
                        handleNavClick(item?.path);
                        setIsMoreMenuOpen(false);
                      }}
                      className={`w-full flex items-center px-4 py-2 text-sm text-left hover:bg-muted transition-colors ${
                        isActivePath(item?.path) ? 'bg-muted text-primary font-medium' : 'text-foreground'
                      }`}
                      title={item?.tooltip}
                    >
                      <Icon name={item?.icon} size={16} className="mr-3" />
                      {item?.label}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </nav>

        {/* Right Section - User Actions */}
        <div className="flex items-center space-x-2">
          {/* Notifications */}
          <Button
            variant="ghost"
            size="icon"
            className="relative"
            title="Notifications"
          >
            <Icon name="Bell" size={18} />
            <span className="absolute -top-1 -right-1 w-2 h-2 bg-error rounded-full"></span>
          </Button>

          {/* User Profile */}
          <Button
            variant="ghost"
            size="sm"
            className="hidden sm:flex"
            iconName="User"
            iconPosition="left"
          >
            Profile
          </Button>
        </div>
      </div>
      {/* Mobile Navigation Overlay */}
      {isMenuOpen && (
        <div className="lg:hidden fixed inset-0 top-16 bg-background z-200 animate-fade-in">
          <nav className="p-4 space-y-2">
            <div className="space-y-1">
              <h3 className="text-sm font-medium text-muted-foreground px-3 py-2">
                Training Operations
              </h3>
              {primaryNavItems?.slice(0, 2)?.map((item) => (
                <Button
                  key={item?.path}
                  variant={isActivePath(item?.path) ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => {
                    handleNavClick(item?.path);
                    onMenuToggle();
                  }}
                  className="w-full justify-start"
                  iconName={item?.icon}
                  iconPosition="left"
                >
                  {item?.label}
                </Button>
              ))}
            </div>

            <div className="space-y-1">
              <h3 className="text-sm font-medium text-muted-foreground px-3 py-2">
                System Administration
              </h3>
              {[...primaryNavItems?.slice(2), ...secondaryNavItems?.slice(0, 2)]?.map((item) => (
                <Button
                  key={item?.path}
                  variant={isActivePath(item?.path) ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => {
                    handleNavClick(item?.path);
                    onMenuToggle();
                  }}
                  className="w-full justify-start"
                  iconName={item?.icon}
                  iconPosition="left"
                >
                  {item?.label}
                </Button>
              ))}
            </div>

            <div className="space-y-1">
              <h3 className="text-sm font-medium text-muted-foreground px-3 py-2">
                Analytics & Planning
              </h3>
              {secondaryNavItems?.slice(2)?.map((item) => (
                <Button
                  key={item?.path}
                  variant={isActivePath(item?.path) ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => {
                    handleNavClick(item?.path);
                    onMenuToggle();
                  }}
                  className="w-full justify-start"
                  iconName={item?.icon}
                  iconPosition="left"
                >
                  {item?.label}
                </Button>
              ))}
            </div>
          </nav>
        </div>
      )}
      {/* Click outside to close more menu */}
      {isMoreMenuOpen && (
        <div
          className="fixed inset-0 z-100"
          onClick={() => setIsMoreMenuOpen(false)}
        />
      )}
    </header>
  );
};

export default Header;