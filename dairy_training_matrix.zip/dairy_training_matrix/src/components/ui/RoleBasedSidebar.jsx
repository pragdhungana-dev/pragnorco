import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';
import ComplianceStatusIndicator from './ComplianceStatusIndicator';
import SystemSyncStatus from './SystemSyncStatus';

const RoleBasedSidebar = ({ 
  isCollapsed = false, 
  onToggleCollapse,
  userRole = 'training_coordinator',
  className = '' 
}) => {
  const location = useLocation();
  const [expandedSections, setExpandedSections] = useState({
    operations: true,
    administration: false,
    analytics: false
  });

  const navigationSections = [
    {
      id: 'operations',
      label: 'Training Operations',
      icon: 'Activity',
      roleAccess: ['training_coordinator', 'production_manager', 'safety_officer', 'supervisor'],
      items: [
        {
          label: 'Training Requirements Matrix',
          path: '/training-requirements-matrix',
          icon: 'Grid3X3',
          roleAccess: ['training_coordinator', 'production_manager', 'safety_officer'],
          tooltip: 'View and manage training requirements matrix',
          hasComplianceStatus: true
        },
        {
          label: 'Employee Training Dashboard',
          path: '/employee-training-dashboard',
          icon: 'Users',
          roleAccess: ['training_coordinator', 'production_manager', 'hr_personnel', 'supervisor'],
          tooltip: 'Monitor employee training status and progress',
          hasComplianceStatus: true
        }
      ]
    },
    {
      id: 'administration',
      label: 'System Administration',
      icon: 'Settings',
      roleAccess: ['training_coordinator', 'hr_personnel', 'admin'],
      items: [
        {
          label: 'Training Course Management',
          path: '/training-course-management',
          icon: 'BookOpen',
          roleAccess: ['training_coordinator', 'hr_personnel', 'admin'],
          tooltip: 'Manage training courses and content'
        },
        {
          label: 'Certificate Management',
          path: '/certificate-management-system',
          icon: 'Award',
          roleAccess: ['training_coordinator', 'hr_personnel'],
          tooltip: 'Manage training certificates and credentials'
        },
        {
          label: 'User & Role Management',
          path: '/user-role-management',
          icon: 'UserCog',
          roleAccess: ['admin', 'hr_personnel'],
          tooltip: 'Manage users and role permissions'
        }
      ]
    },
    {
      id: 'analytics',
      label: 'Analytics & Planning',
      icon: 'BarChart3',
      roleAccess: ['training_coordinator', 'production_manager', 'hr_personnel', 'safety_officer'],
      items: [
        {
          label: 'Compliance Reporting',
          path: '/compliance-reporting-dashboard',
          icon: 'FileText',
          roleAccess: ['training_coordinator', 'production_manager', 'hr_personnel', 'safety_officer'],
          tooltip: 'View compliance reports and analytics'
        },
        {
          label: 'Training Analytics',
          path: '/training-analytics-insights',
          icon: 'TrendingUp',
          roleAccess: ['training_coordinator', 'production_manager', 'hr_personnel'],
          tooltip: 'View training analytics and insights'
        },
        {
          label: 'Training Calendar',
          path: '/training-calendar-scheduling',
          icon: 'Calendar',
          roleAccess: ['training_coordinator', 'hr_personnel'],
          tooltip: 'Schedule and manage training sessions'
        }
      ]
    }
  ];

  const hasRoleAccess = (roleAccess) => {
    return roleAccess?.includes(userRole);
  };

  const isActivePath = (path) => {
    return location?.pathname === path;
  };

  const handleNavClick = (path) => {
    window.location.href = path;
  };

  const toggleSection = (sectionId) => {
    if (!isCollapsed) {
      setExpandedSections(prev => ({
        ...prev,
        [sectionId]: !prev?.[sectionId]
      }));
    }
  };

  // Auto-expand section containing active path
  useEffect(() => {
    navigationSections?.forEach(section => {
      const hasActivePath = section?.items?.some(item => isActivePath(item?.path));
      if (hasActivePath && !expandedSections?.[section?.id]) {
        setExpandedSections(prev => ({
          ...prev,
          [section?.id]: true
        }));
      }
    });
  }, [location?.pathname]);

  const visibleSections = navigationSections?.filter(section => 
    hasRoleAccess(section?.roleAccess)
  );

  return (
    <aside 
      className={`
        fixed left-0 top-16 bottom-0 z-100 bg-card border-r border-border shadow-industrial
        sidebar-transition
        ${isCollapsed ? 'w-16' : 'w-60'}
        ${className}
      `}
    >
      <div className="flex flex-col h-full">
        {/* Sidebar Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          {!isCollapsed && (
            <div className="flex items-center space-x-2">
              <div className="w-6 h-6 bg-primary rounded flex items-center justify-center">
                <Icon name="Shield" size={14} color="white" />
              </div>
              <span className="text-sm font-medium text-foreground">Navigation</span>
            </div>
          )}
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggleCollapse}
            className="h-8 w-8"
            title={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            <Icon name={isCollapsed ? 'ChevronRight' : 'ChevronLeft'} size={16} />
          </Button>
        </div>

        {/* Navigation Content */}
        <nav className="flex-1 overflow-y-auto p-2">
          <div className="space-y-2">
            {visibleSections?.map((section) => (
              <div key={section?.id} className="space-y-1">
                {/* Section Header */}
                <button
                  onClick={() => toggleSection(section?.id)}
                  className={`
                    w-full flex items-center justify-between p-2 rounded-lg
                    hover:bg-muted transition-colors nav-item-hover
                    ${isCollapsed ? 'justify-center' : ''}
                  `}
                  title={isCollapsed ? section?.label : ''}
                >
                  <div className="flex items-center space-x-2">
                    <Icon name={section?.icon} size={16} className="text-muted-foreground" />
                    {!isCollapsed && (
                      <span className="text-sm font-medium text-muted-foreground">
                        {section?.label}
                      </span>
                    )}
                  </div>
                  {!isCollapsed && (
                    <Icon 
                      name={expandedSections?.[section?.id] ? 'ChevronDown' : 'ChevronRight'} 
                      size={14} 
                      className="text-muted-foreground"
                    />
                  )}
                </button>

                {/* Section Items */}
                {(expandedSections?.[section?.id] || isCollapsed) && (
                  <div className={`space-y-1 ${!isCollapsed ? 'ml-2' : ''}`}>
                    {section?.items?.filter(item => hasRoleAccess(item?.roleAccess))?.map((item) => (
                        <div key={item?.path} className="relative">
                          <Button
                            variant={isActivePath(item?.path) ? 'default' : 'ghost'}
                            size="sm"
                            onClick={() => handleNavClick(item?.path)}
                            className={`
                              w-full justify-start nav-item-hover
                              ${isCollapsed ? 'px-2' : 'px-3'}
                              ${isActivePath(item?.path) ? 'bg-primary text-primary-foreground' : ''}
                            `}
                            title={isCollapsed ? item?.tooltip : ''}
                          >
                            <Icon 
                              name={item?.icon} 
                              size={16} 
                              className={isCollapsed ? '' : 'mr-2'} 
                            />
                            {!isCollapsed && (
                              <span className="flex-1 text-left truncate">
                                {item?.label}
                              </span>
                            )}
                            {!isCollapsed && item?.hasComplianceStatus && (
                              <ComplianceStatusIndicator 
                                path={item?.path}
                                size="sm"
                              />
                            )}
                          </Button>
                        </div>
                      ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </nav>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-border">
          <SystemSyncStatus isCollapsed={isCollapsed} />
        </div>
      </div>
    </aside>
  );
};

export default RoleBasedSidebar;